//*******UAT environment ***********
export const environment = {
  production: false,
  apiUrl: "https://docinsights.azurewebsites.net/api",
  dataScienceUrl: "datascience",
  dataScieneLocalUrl: "https://docinsights.azurewebsites.net/api",
  dataScienceUrlPython: "https://docinsights.azurewebsites.net/api/DataScience",
  //docinsights sass key
  urldata:
    "?st=2021-02-04T04%3A52%3A18Z&se=2022-02-05T04%3A52%3A00Z&sp=r&sv=2018-03-28&sr=c&sig=zgopGITZ2CIetVUEldV1Lndy0u4ERIOjd92482OwxAg%3D",
  clientId: "76b29d5f-dc0a-4352-9ec6-a617076066b6",
  authority:
    "https://login.microsoftonline.com/264b9899-fe1b-430b-9509-2154878d5774/",
  redirectUrl: "https://docinsightdev.azurewebsites.net/",
};
