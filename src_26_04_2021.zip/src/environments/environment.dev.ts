//*******Dev environment ***********
export const environment = {
    production: false,
    apiUrl: "https://docinsightdev.azurewebsites.net/api",
    dataScienceUrl: "datascience",
    dataScieneLocalUrl: "https://docinsightdev.azurewebsites.net/api",
    dataScienceUrlPython: "https://docinsightdev.azurewebsites.net/api/DataScience",
    urldata: "?st=2021-01-12T04%3A32%3A51Z&se=2022-01-13T04%3A32%3A00Z&sp=r&sv=2018-03-28&sr=c&sig=81%2Ft6qHcg7AdIivk7AEEPG%2BVytd2KNAAO7%2Flswv%2FL9o%3D",
    clientId: '76b29d5f-dc0a-4352-9ec6-a617076066b6',
    authority: 'https://login.microsoftonline.com/264b9899-fe1b-430b-9509-2154878d5774/',
    redirectUrl: 'https://docinsightdev.azurewebsites.net/'
};