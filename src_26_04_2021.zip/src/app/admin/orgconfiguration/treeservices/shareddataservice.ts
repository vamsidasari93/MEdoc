import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, Subject } from "rxjs";
import { BehaviorSubject } from "rxjs/internal/BehaviorSubject";

@Injectable({
  providedIn: "root",
})
export class SharedDataService {
  private data = {};
  private treedata = new Subject();
  tree$ = this.treedata.asObservable();
  constructor(private http: HttpClient) {}

  treeupdatedData(value: any) {
    this.treedata.next(value);
  }
  setOption(option, value) {
    this.data[option] = value;
  }

  getOption() {
    return this.data;
  }
}
