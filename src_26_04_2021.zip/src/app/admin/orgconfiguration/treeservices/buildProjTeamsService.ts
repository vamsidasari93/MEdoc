import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { map } from "rxjs/operators";
@Injectable({ providedIn: "root" })
export class BuildProjectTeamsService {
  private safetyproducturl = "https://safetysolapp.azurewebsites.net"; // URL to web api

  constructor(private http: HttpClient) {}
  getRoleByOrgHierarchy(orgId: number) {
    // const apiurl = environment.safetyproducturl + '/admin/api/ChecklistAdmin/GetRolesByOrgHierarchyId?OrgHierarchyId=' + orgId;
    // const header = {};
    // return this.restClientService.getData(apiurl, { headers: header });
  }
  saveRoleforHirarchy(roleData) {
    // const apiurl = environment.safetyproducturl + '/admin/api/ChecklistAdmin/SaveOrgHierarchyItemRoles';
    // const header = {};
    // return this.restClientService.postData(apiurl, roleData, { headers: header });
  }

  addOrgHierarchy(savedata) {
    var url = `https://localhost:44338/api/OrgSetup/SaveOrganizationHierarchy`;
    return this.http.post(url, savedata, { responseType: "json" }).pipe(
      map((response: any) => {
        return response;
        console.log(response);
      })
    );
  }
  // createOrganizationHierarchy(createData) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/CreateOrganizationHierarchy";
  //   const header = {};
  //   return this.restClientService.postData(apiurl, createData, {
  //     headers: header,
  //   });
  // }

  saveOrganizationHierarchy(updatedData) {
    // const apiurl =
    //   environment.safetyproducturl +
    //   "/admin/api/ChecklistAdmin/SaveOrganizationHierarchy";
    // const header = {};
    // return this.restClientService.postData(apiurl, updatedData, {
    //   headers: header,
    // });
  }

  // getUserRoleByOrgHierarchyId(orgId: number) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetUserRolesByOrgHierarchyId?OrgHierarchyId=" +
  //     orgId;
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // saftyProcedureAssignment(orgId: number) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetTemplatesByOrgHierarchyId?OrgHierarchyId=" +
  //     orgId;
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // incidentsAssignment(orgId: number) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/IncidentAdmin/GetIncidentsByOrgHierarchyId?OrgHierarchyId=" +
  //     orgId;
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // observationAssignment(orgId: number) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetTemplatesByOrgHierarchyId?OrgHierarchyId=" +
  //     orgId;
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // inspectionsAssignement(orgId: number) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetTemplatesByOrgHierarchyId?OrgHierarchyId=" +
  //     orgId;
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // getAllOrgHierarchyTypes() {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/admin/api/ChecklistAdmin/GetAllOrgHierarchyTypes";
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // getAllTemplates() {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetAllTemplates";
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // getAllIncidentTemplates() {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/IncidentAdmin/GetIncidentTemplates";
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // getAllSaftyTemplates() {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetAllTemplates";
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // getAllObservationTemplates() {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ObservationAdmin/GetObservationTemplates";
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // getUserRolesByOrgHierarchy(orgId: number) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetUserRolesByOrgHierarchyId?OrgHierarchyId=" +
  //     orgId;
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // getAllTemplatesByOrgHierarchyId(orgId: number) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetTemplatesByOrgHierarchyId?OrgHierarchyId=" +
  //     orgId;
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // getProjectInheritedRoles(projectId: number) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetProjectInheritedRoles?ProjectId=" +
  //     projectId;
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // getAppNonWorkflowFeatures() {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetAppNonWorkflowFeatures";
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // getProjectFeatureRoleMapping(projectId: number) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/GetProjectFeatureRoleMapping?ProjectId=" +
  //     projectId;
  //   const header = {};
  //   return this.restClientService.getData(apiurl, { headers: header });
  // }

  // saveRoleforHirarchyTemplateItem(roleData) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/SaveOrgHierarchyItemTemplates";
  //   const header = {};
  //   return this.restClientService.postData(apiurl, roleData, {
  //     headers: header,
  //   });
  // }

  // saveRoleUserMapping(roleUserMapping) {
  //   const apiurl =
  //     environment.safetyproducturl +
  //     "/admin/api/ChecklistAdmin/SaveOrgHierarchyItemUserRoleMapping";
  //   const header = {};
  //   return this.restClientService.postData(apiurl, roleUserMapping, {
  //     headers: header,
  //   });
  // }

  getAllUsers() {
    // const apiurl =
    //   environment.safetyproducturl + "/admin/api/ChecklistAdmin/GetAllUsers";
    // const header = {};
    // return this.restClientService.getData(apiurl, { headers: header });
  }
}
