import { MatSnackBar } from "@angular/material/snack-bar";
import { Component, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { Subject } from "rxjs";
import { take, takeUntil } from "rxjs/operators";
import { SharedDataService } from "../treeservices/shareddataservice";
import { BuildProjectTeamsService } from "../treeservices/buildProjTeamsService";
import { ConfirmRemoveComponent } from "../confirm-remove/confirm-remove.component";

declare var $: any;
@Component({
  selector: "app-role-mapper",
  templateUrl: "./role-mapper.component.html",
  styleUrls: ["./role-mapper.component.scss"],
})
export class RoleMapperComponent implements OnInit {
  private readonly destroyed$ = new Subject<boolean>();
  orgData: any;
  roles: any;
  orgIncrementer: any;
  roleCount = 0;
  userRoleCount = 0;
  formCount = 0;
  userRoleMainArray = [];
  userRoleMainArray2 = [];
  shareddata = [];
  currentNodeName: any;
  shareddata1: any;
  selectedNode: any;
  inputDisabled = true;

  constructor(
    private sds: SharedDataService,
    private snackbar: MatSnackBar,
    private projectService: BuildProjectTeamsService,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this.inputDisabled = true;
    // this.roles.push({ Name: 'BU EHS Personal', id: 1, OrgId: '1' });
    this.orgData = this.sds.getOption()["orgData"];
    if (this.orgData) {
      this.orgData.forEach((element) => {
        element.state.selected = false;
      });
    }

    const roleData = this.sds.getOption()["roleData"];
    this.roleCount = roleData === undefined ? 0 : roleData.length;
    const userRoleData = this.sds.getOption()["userRole"];
    this.userRoleCount = userRoleData === undefined ? 0 : userRoleData.length;
    const formData = this.sds.getOption()["form"];
    this.formCount = formData === undefined ? 0 : formData.length;
    this.roles = roleData === undefined ? [] : [];
  }

  addTable() {
    this.plusEventSelected(this.selectedNode);
  }

  editRow(i, role) {
    this.inputDisabled = false;
  }

  // deleteRow(x, roleId) {
  //   var delBtn = confirm(" Do you want to delete ?");
  //   if (delBtn === true) {
  //     this.shareddata.splice(x, 1);
  //   }
  // }

  plusEventSelected(node: any) {
    this.orgIncrementer =
      this.shareddata && this.shareddata.length
        ? this.shareddata.length + 1
        : 1;
    const saveRole = {
      orgHierarchyRolesId: 0,
      orghierarchyRolesName: "",
      orgHierarchyId: Number(node.id),
      state: "ADDED",
      createdBy: 0,
      updatedBy: 0,
      orgRolesUser: [],
    };
    this.shareddata1.push(saveRole);
    this.shareddata.push(saveRole);
    this.roleCount = this.shareddata1.length;
    this.sds.setOption(this.shareddata1, "roleData");

    // this.shareddata.push({ name: '', id: node.id, OrgId: node.id });
    // this.getUserRoleData(node.id);
  }

  currentNodeSelected(currentnode) {
    if (currentnode.state.selected === true) {
      this.currentNodeName = currentnode.text;
      this.selectedNode = currentnode;
      // this.projectService
      //   .getRoleByOrgHierarchy(currentnode.id)
      //   .pipe(take(1))
      //   .subscribe((teams) => {
      //     if (teams && teams.data && teams.status === "Success") {
      //       this.shareddata1 = teams.data;
      //       // this.userRoleMainArray = this.shareddata ? this.shareddata : [];
      //       this.sds.setOption(this.shareddata1, "roleData");
      //       // this.shareddata1 = this.shareddata;
      //       this.roleCount = this.shareddata1.length;
      //       console.log(this.roleCount, this.roles, "roles");
      //     }
      //   });
    }
    this.shareddata1 = this.sds.getOption()["roleData"];
    if (this.shareddata && this.shareddata.length) {
      this.saveRole();
    }
  }

  // getUserRoleData(getId: any) {
  //   this.projectService.getRoleByOrgHierarchy(getId).pipe(take(1)).subscribe(teams => {
  //     if (teams && teams.data && teams.status === 'Success') {
  //       this.shareddata = teams.data;
  //       this.userRoleMainArray = this.shareddata ? this.shareddata : [];
  //       this.sds.setOption(this.userRoleMainArray, 'roleData');
  //       this.shareddata1 = this.shareddata;
  //       this.roleCount = this.shareddata1.length;
  //       console.log(this.roleCount, this.roles, 'roles');
  //     }
  //   });

  // this.userRoleMainArray = this.shareddata ? this.shareddata : [];
  // this.sds.setOption('roleData', this.userRoleMainArray);
  // if (this.shareddata && this.shareddata.length) {
  // this.roles = this.shareddata;
  // this.roles = this.userRoleMainArray.filter(item => item.id === getId);
  // this.roleCount = this.roles.length;
  // }
  // }

  MakeEditable(event) {
    document.getElementById("roleBadge_" + event).style.display = "none";
    document.getElementById("roleInput_" + event).style.display = "block";
  }

  onBlurRoleMethod(i, item, event) {
    const inputValue = document.getElementById("roleInput_" + event)["value"];
    this.shareddata1[i].orghierarchyRolesName = inputValue;
    // document.getElementById('roleBadge_' + event).style.display = 'block';
    // document.getElementById('roleInput_' + event).style.display = 'none';
    if (
      item &&
      item.orghierarchyRolesName === this.shareddata1[i].orghierarchyRolesName
    ) {
      this.shareddata1[i].state = "MODIFIED";
      this.shareddata.push(this.shareddata1[i]);
    }
    console.log(this.shareddata1, "roleInput");
  }

  deleteRole(i, item, event) {
    item.state = "REMOVED";
    this.shareddata.push(item);
    this.shareddata1.splice(
      this.shareddata1.findIndex((x) => x.id === event),
      1
    );
    this.roleCount =
      this.shareddata1 === undefined ? 0 : this.shareddata1.length;
    this.sds.setOption("roleData", this.shareddata1);
    console.log(this.shareddata1, "deleterole");
  }

  saveRole() {
    // var saveRoleArray = [];
    // this.shareddata = this.sds.getOption()['roleData'];
    // this.shareddata.map(eachRole => {
    //   const saveRole = {
    //     orgHierarchyRolesId: 0,
    //     orghierarchyRolesName: eachRole.Name,
    //     orgHierarchyId: Number(eachRole.OrgId),
    //     state: 'ADDED',
    //     createdBy: 0,
    //     updatedBy: 0,
    //     orgRolesUser: []
    //   };
    //   saveRoleArray.push(saveRole);
    // });
    if (this.shareddata && this.shareddata.length) {
      this.dialog
        .open(ConfirmRemoveComponent, {
          width: "38%",
          closeOnNavigation: true,
          hasBackdrop: true,
          data: "Are you sure want to save the changes ?",
          panelClass: "global-mat-custom-dailog",
        })
        .afterClosed()
        .pipe(takeUntil(this.destroyed$))
        .subscribe((success: any) => {
          if (success === true) {
            // this.projectService
            //   .saveRoleforHirarchy(this.shareddata)
            //   .subscribe((roleSuccess) => {
            //     if (roleSuccess && roleSuccess.data) {
            //       this.snackbar.open(roleSuccess.message, "", {
            //         duration: 3000,
            //         panelClass: ["success-snackbar"],
            //       });
            //       this.shareddata = [];
            //     }
            //   });
          } else {
            this.shareddata = [];
          }
        });
    }
  }
}
