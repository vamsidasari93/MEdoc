import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildprojecttreeComponent } from './buildprojecttree.component';

describe('BuildprojecttreeComponent', () => {
  let component: BuildprojecttreeComponent;
  let fixture: ComponentFixture<BuildprojecttreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuildprojecttreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuildprojecttreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
