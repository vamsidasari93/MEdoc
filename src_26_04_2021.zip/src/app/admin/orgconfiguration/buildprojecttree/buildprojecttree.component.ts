import {
  Component,
  OnInit,
  AfterViewInit,
  Input,
  Output,
  EventEmitter,
  OnChanges,
} from "@angular/core";
import { MatDialog } from "@angular/material";
import { AdminService } from "src/app/Services/admin.service";
import { DeletetreePopupComponent } from "./deletetree-popup/deletetree-popup.component";
declare var $: any;
@Component({
  selector: "buildprojecttree",
  templateUrl: "./buildprojecttree.component.html",
  styleUrls: ["./buildprojecttree.component.scss"],
})
export class BuildprojecttreeComponent implements OnInit, OnChanges {
  @Input() ChecklistName: string;
  @Input() jsonData: Array<object>;
  @Input() showButtons: boolean;
  @Input() treeType: string;
  @Input() EditMode: boolean;
  @Output() nodeSelected = new EventEmitter();
  @Output() loadedData = new EventEmitter();
  @Output() RemovedIds = new EventEmitter();
  @Output() plusEventRaised = new EventEmitter();

  showAddParent = false;
  showCreateChild = false;
  showRemoveNode = false;
  treeData: Array<object> = [];
  lastNodeId = 0;
  curEvent = "";
  treeObject: any;
  parentIterator = 0;
  childIterator = 0;
  RootNode;
  customParentNode: string;
  removeConfirmation: any;
  orgData: Array<any> = [];

  constructor(public dialog: MatDialog, private adminservice: AdminService) { }
  ngOnInit() {
    this.treedata();
    this.getOrgData();
  }

  getOrgData() {
    this.adminservice.getOrgHierarchy().subscribe((orgStructure: any) => {
      this.orgData = orgStructure.result;
    })
  }
  ngOnChanges() {
    // console.log("datain tree", this.jsonData);
    // this.treedata();
  }
  /**
   * @event treedata
   * @description converting data into tree structure
   */
  treedata() {
    if (this.jsonData === undefined && this.ChecklistName !== "") {
      this.treeData.push({
        id: "1",
        parent: "#",
        type: this.treeType,
        text: this.ChecklistName,
      });
      this.showAddParent = true;
      // console.log(this.treeData);
    } else {
      this.treeData = this.jsonData;
      this.lastNodeId = this.treeData.length;
    }
  }
  /**
   * @event ngAfterViewInit()
   * @description Treedata
   */
  ngAfterViewInit() {
    var curObj = this;
    curObj.treeObject = $("#tree");
    $(function () {
      $("#tree").tooltip();
      $("#tree")
        .jstree({
          core: {
            check_callback: true,
            data: curObj.treeData,
          },
          types: {
            default: {
              icon: "fa fa-folder",
            },
            Organisation: {
              icon: "fa fa-folder",
            },
            Others: {
              icon: "fa fa-cube",
            },
            Project: {
              icon: "fa fa-file-text-o",
            },
          },
          plugins: ["types", "search"],
        })
        .bind("loaded.jstree", function (event, data) {
          curObj.treeObject.jstree("open_all");
          curObj.lastNodeId = curObj.getTreeData().length;
          curObj.ShowLoadedData();
        })
        .bind("hover_node.jstree", function (event, data) {
          $("#" + data.node.id).prop("title", data.node.text);
        })
        .bind("refresh.jstree", function (event, data) {
          curObj.treeObject.jstree("open_all");
          if (curObj.curEvent === "addRootNode") {
            var rootNode = curObj.treeObject.jstree(true).get_node("1");
            curObj.treeObject
              .jstree()
              .edit(rootNode, null, function (node, status) {
                curObj.ShowLoadedData();
              });
          } else if (curObj.curEvent === "addCustomParent") {
            curObj.treeObject
              .jstree()
              .edit(curObj.customParentNode, null, function (node, status) {
                node.type = "Organisation";
              });
          }
          curObj.lastNodeId = curObj.getTreeData().length;
          curObj.showCreateChild = false;
          curObj.showAddParent = false;
          curObj.showRemoveNode = false;
        })
        .on("click", ".jstree-anchor", function (e) {
          var selNode = curObj.treeObject.jstree("get_selected");
          var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
        });

      curObj.treeObject.off("dblclick").on("dblclick.jstree", function (e) {
        var instance = $.jstree.reference(this),
          node = instance.get_node(e.target);
        curObj.treeObject.jstree().edit(node, null, function (node, status) {
          curObj.ShowLoadedData();
        });
      });
      curObj.treeObject.on("select_node.jstree", function (e, data) {
        if (data.node.parent === "#") {
          curObj.showCreateChild = true;
          curObj.showAddParent = false;
          curObj.showRemoveNode = true;
        } else if (data.node.parents.length < 3 && data.node.type == "Others") {
          curObj.showCreateChild = true;
          curObj.showAddParent = false;
          curObj.showRemoveNode = true;
        } else {
          curObj.showCreateChild = false;
          curObj.showAddParent = false;
          curObj.showRemoveNode = true;
        }
        curObj.nodeSelectedEvent(data.node);
      });
    });
  }
  /**
   * @event getTreeData
   * @description Treedata format
   */
  getTreeData() {
    var gData = this.treeObject.jstree(true).get_json("#", { flat: true });
    // console.log("trree", gData);
    return gData;
  }
  /**
   * @event getTreeData
   * @description Treedata format
   * @parameter node
   */
  nodeSelectedEvent(node) {
    var curObj = this;
    if (this.EditMode === false) {
      $("#plusAddEvent").remove();
      $("#" + node.a_attr.id).append(
        '<i id="plusAddEvent" class="fa fa-plus-circle" aria-hidden="true"></i>'
      );
      document
        .getElementById("plusAddEvent")
        .addEventListener("click", (event: Event) => {
          curObj.plusEventRaised.emit(node);
        });
    }
    this.nodeSelected.emit(node);
  }
  /**
   * @event ShowLoadedData()
   * @description emit tree data
   */
  ShowLoadedData() {
    this.loadedData.emit(this.getTreeData());
  }
  /**
   * @event AddParent()
   * @description to add parent
   */
  AddParent() {
    // if (this.treeType === "orgTree") {
    //   console.log("parentnodes");
    // this.addParentNode();
    // } else {
    this.addRootNode();
    // }
  }
  /**
   * @event AddChild()
   * @description to add child
   */
  AddChild() {
    // if (this.treeType === "orgTree") {
    this.createChildFree();
    // } else {
    //   this.createChild();
    // }
  }
  /**
   * @event RemoveNode()
   * @description to remove main parent
   */
  RemoveNode() {
    let data = {
      message: 'Are yous sure you want to remove'
    }
    this.dialog.open(DeletetreePopupComponent,
      {
        data: data
      })
      .afterClosed()
      .subscribe((result) => {
        this.removeConfirmation = result.data;
        console.log(this.removeConfirmation);
        if (this.removeConfirmation === "confirmed") {
          this.Removetree();
          // this.showAddParent = true;
        }
      });
  }
  /**
   * @event RemoveNode
   * @description to remove the parent and child nodes
   */
  Removetree() {
    let removedIdsdata = [];
    var curObj = this;
    curObj.curEvent = "removeNode";
    var selNode = curObj.treeObject.jstree("get_selected");
    var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
    var result = this.treeObject.jstree(true).get_children_dom(selNodeAttr.id);

    if (result.length !== 0) {
      curObj.treeData = curObj.getTreeData();
      var objIndex = curObj.treeData.findIndex(
        (obj: any) => obj.id === selNodeAttr.id
      );
      let parentNodeDelete = false;
      this.orgData.forEach(item => {
        if (item.organizationHierarchyId == selNodeAttr.id && !item.isNewRecord) {
          removedIdsdata.push(+selNodeAttr.id);
          parentNodeDelete = true;
        }
      });
      if (!parentNodeDelete) {
        curObj.treeData.splice(objIndex, 1);
      }
      // var curNodeObj: any = curObj.treeData[objIndex];
      for (var i = 0; i < selNodeAttr.children_d.length; i++) {
        var objIndex = curObj.treeData.findIndex(
          (obj: any) => obj.id === selNodeAttr.children_d[i]
        );
        var curNodeObj: any = curObj.treeData[objIndex];
        let multiNodeDelete = false;
        this.orgData.forEach(item => {
          if (item.organizationHierarchyId == selNodeAttr.children_d[i] && !item.isNewRecord) {
            removedIdsdata.push(+selNodeAttr.children_d[i]);
            multiNodeDelete = true;
          }
        })
        if (!multiNodeDelete) {
          curObj.treeData.splice(objIndex, 1);
        }
      }
      curObj.treeObject.jstree(true).settings.core.data = curObj.treeData;
      curObj.treeObject.jstree(true).refresh();
      curObj.ShowLoadedData();
    } else {
      let singleNodeDelete = false;
      this.orgData.forEach(item => {
        if (item.organizationHierarchyId == selNodeAttr.id && !item.isNewRecord) {
          removedIdsdata.push(+selNodeAttr.id);
          singleNodeDelete = true;
        }
      });
      if (!singleNodeDelete) {
        curObj.treeObject.jstree(true).delete_node(selNode);
      }
      curObj.lastNodeId = curObj.getTreeData().length;
      curObj.ShowLoadedData();
    }
    this.loadedData.emit(curObj.treeData);
    this.RemovedIds.emit(removedIdsdata);
    if (selNodeAttr.type === "default" || selNodeAttr.type === "Organisation") {
      curObj.showCreateChild = false;
      curObj.showAddParent = true;
      curObj.showRemoveNode = false;
    }
  }
  /**
   * @event addParentNode()
   * @description to add sub-parent node
   */
  addParentNode() {
    var curObj = this;
    curObj.curEvent = "addCustomParent";
    curObj.parentIterator = curObj.parentIterator + 1;
    var selNode = curObj.treeObject.jstree("get_selected");
    var treedata = curObj.getTreeData();
    var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
    var newTreeData = curObj.getTreeData();
    var currentNodeId = String(Date.now());
    //for current node
    var objIndex = newTreeData.findIndex((obj) => obj.id === selNodeAttr.id);
    delete newTreeData[objIndex].li_attr;
    delete newTreeData[objIndex].a_attr;
    newTreeData[objIndex].parentChange = "true";
    newTreeData[objIndex].parent = currentNodeId;

    //Add current node
    newTreeData.push({
      id: currentNodeId,
      parent: selNodeAttr.parent,
      text: "Parent Name",
      type: "Organisation",
      parentChange: "true",
    });

    curObj.treeObject.jstree(true).settings.core.data = newTreeData;
    curObj.treeObject.jstree(true).refresh();
    curObj.treeObject.jstree(true).deselect_all(true);
    curObj.customParentNode = currentNodeId;
    this.loadedData.emit(newTreeData);
    curObj.showAddParent = false;
  }
  /**
   * @event addRootNode()
   * @description to add parent node
   */
  addRootNode() {
    var curObj = this;
    curObj.curEvent = "addRootNode";
    this.treeData = this.getTreeData();
    var newtreeData = [];
    this.treeData.forEach(function (value: any) {
      var id = String(parseInt(value.id) + 1);
      var parent = value.parent === "#" ? "1" : String(parseInt(value.parent));
      newtreeData.push(
        curObj.generateDataObject(id, parent, value.text, value.type)
      );
    });
    newtreeData.unshift({
      id: "1",
      parent: "#",
      text: "Parent Name",
      type: "Organisation",
    });
    curObj.treeObject.jstree(true).settings.core.data = newtreeData;
    curObj.treeObject.jstree(true).refresh();
    this.loadedData.emit(newtreeData);
    curObj.showAddParent = false;
  }
  /**
   * @event  createChildFree()
   * @description to add main-child node
   */
  createChildFree() {
    var curObj = this;
    curObj.childIterator = curObj.childIterator + 1;
    var selNode = curObj.treeObject.jstree("get_selected");
    var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
    if (selNodeAttr.type === "Organisation" || selNodeAttr.type === "default") {
      var node = curObj.treeObject.jstree().create_node(
        selNode[0],
        {
          id: String(curObj.lastNodeId + 1),
          text: "Child-" + curObj.childIterator,
          type: "Others",
          isnew: true,
        },
        "last",
        function () { }
      );
      curObj.treeObject.jstree().edit(node, null, function (node, status) {
        node.type = "Others";
        curObj.lastNodeId = curObj.getTreeData().length;
        curObj.ShowLoadedData();
      });
    } else {
      var node = curObj.treeObject.jstree().create_node(
        selNode[0],
        {
          id: String(curObj.lastNodeId + 1),
          text: "Child-" + curObj.childIterator,
          type: "Project",
          isnew: true,
        },
        "last",
        function () { }
      );
      curObj.treeObject.jstree().edit(node, null, function (node, status) {
        node.type = "Project";
        curObj.lastNodeId = curObj.getTreeData().length;
        curObj.ShowLoadedData();
      });
    }
  }
  /**
   * @event  createChild()
   * @description to add sub-child node
   */
  createChild() {
    var curObj = this;
    var selNode = curObj.treeObject.jstree("get_selected");
    var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
    if (selNodeAttr.type === "Organisation") {
      var node = curObj.treeObject.jstree().create_node(
        selNode[0],
        {
          id: String(curObj.lastNodeId + 1),
          text: "Child Name",
          type: "Others",
          isnew: true,
        },
        "last",
        function () { }
      );
      curObj.showCreateChild = false;
      curObj.showAddParent = false;
      curObj.showRemoveNode = false;
      curObj.treeObject.jstree().edit(node, null, function (node, status) {
        curObj.lastNodeId = curObj.getTreeData().length;
        curObj.ShowLoadedData();
      });
    }
  }

  RemoveNodeRestricted() {
    var curObj = this;
    curObj.curEvent = "removeNode";
    var selNode = curObj.treeObject.jstree("get_selected");
    var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
    if (selNodeAttr.type !== "Organisation") {
      this.treeData = this.getTreeData();
      this.treeData = this.treeData.filter(function (obj: any) {
        return obj.id !== selNodeAttr.id;
      });
      var newtreeData = [];
      this.treeData.forEach(function (value: any, index: number) {
        var id = "";
        var parent = "";
        if (value.type === "Project") {
          id = String(value.id - 1);
          parent = String(value.parent - 1);
        } else {
          var id = String(index + 1);
          var parent = index === 0 ? "#" : String(index);
        }
        newtreeData.push(
          curObj.generateDataObject(id, parent, value.text, value.type)
        );
      });
      curObj.treeObject.jstree(true).settings.core.data = newtreeData;
      curObj.treeObject.jstree(true).refresh();
    }
  }

  removeNodeFree() {
    var curObj = this;
    curObj.curEvent = "removeNode";
    var selNode = curObj.treeObject.jstree("get_selected");
    var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
    if (selNodeAttr.type !== "orgRoot") {
      curObj.treeObject.jstree(true).delete_node(selNode);
    }
  }

  generateDataObject(id: string, parent: string, text: string, type: string) {
    return {
      id: id,
      parent: parent,
      type: type,
      text: text,
    };
  }

  filterTree(data) {
    this.treeObject.jstree("close_all");
    this.treeObject.jstree(true).search(data);
  }
}
