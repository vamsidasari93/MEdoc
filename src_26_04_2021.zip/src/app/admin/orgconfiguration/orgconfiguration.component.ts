import * as _ from "underscore";
import { ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { AdminService } from "src/app/Services/admin.service";
import { SharedDataService } from "./treeservices/shareddataservice";
import {
  MatDialog,
  MatPaginator,
  MatSnackBar,
  MatTableDataSource,
} from "@angular/material";
import { AdminInfoPopupComponent } from "../admin-info-popup/admin-info-popup.component";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { data } from "jquery";
import { NgxSpinnerService } from "ngx-spinner";
import { Router } from "@angular/router";
import { OrgstructureComponent } from "./orgstructure/orgstructure.component";
import { ViewChild } from "@angular/core";
import { Subscription } from "rxjs";
declare var $: any;
@Component({
  selector: "app-orgconfiguration",
  templateUrl: "./orgconfiguration.component.html",
  styleUrls: ["./orgconfiguration.component.scss"],
})
export class OrgconfigurationComponent implements OnInit {
  buildtemplate: FormGroup;
  treeData: Array<object> = [];
  //table details
  public totalDiffFromParentToChild: any;
  treearray: any[] = [];
  updatedtree: unknown;
  public displayedColumns: any[] = [
    "organizationName",
    "departmentName",
    "subDepartmentName",
  ];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  dynamicRouterURL: any;
  private subscription: Subscription = new Subscription();
  @ViewChild(OrgstructureComponent, { static: true }) orgStructure: OrgstructureComponent;
  constructor(
    private formBuilder: FormBuilder,
    private cdr: ChangeDetectorRef,
    private adminservice: AdminService,
    private router: Router,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private PdfserviceService: PdfserviceService,
    private spinner: NgxSpinnerService
  ) { }

  ngOnInit() {
    this.PdfserviceService.annotation("admin");
    this.GetOrganizationHierarchyTable();
    this.PdfserviceService.getNavigateAdmin.subscribe((resp:any) => {
      this.dynamicRouterURL = resp;
      if (resp && resp.previous == '/Admin/orgconfig') {
        this.savedTreeData('', 'outside');
        // subscription.unsubscribe();
      }
    })
  }
  GetOrganizationHierarchyTable() {
    this.dataSource.data = [];
    this.adminservice.GetOrganizationHierarchyTable().subscribe((data) => {
      this.dataSource.data = data;
      console.log("GetOrganizationHierarchyTable()", this.dataSource.data);
    });
  }
  /**
   * @event treeDatas()
   * @description based on type name update tree
   * @parameter data
   */
  treeDatas(data) {
    this.treearray = [];
    data.map((eachOrg, index) => {
      if (eachOrg.orgHierTypName === "Organisation") {
        eachOrg.levelId = 0;
      }
      if (eachOrg.orgHierTypName === "Project") {
        eachOrg.levelId = 2;
      }
      if (eachOrg.orgHierTypName === "Others") {
        eachOrg.levelId = 1;
      }
    });
    this.updatedtree = data;
    console.log("datas", this.updatedtree);
    this.treearray = _.sortBy(this.updatedtree, "organizationHierarchyId");
    // this.tableinit();
  }

  /**
   * @event savedTreeData()
   * @description saved tree data
   */
  savedTreeData(type, category) {
    this.subscription.unsubscribe();
    this.treearray = _.sortBy(this.updatedtree, "organizationHierarchyId");
    let refTreeArr = [];
    let flagCount = [];
    this.treearray.forEach(item => {
      item.name = this.decodeEntities(item.name);
      if (item.isNewRecord == undefined) {
        item.state = 'ADDED';
        item.isNewRecord = true;
      }
    })
    flagCount = this.treearray.filter(item => item.state !== null);
    // this.treearray.map((x) => {
    //   if (x.state == 'ADDED' || x.state == 'MODIFIED' || x.state == 'REMOVED') {
    //     refTreeArr.push(x);
    //   }
    // });
    if (flagCount.length != 0 && this.treearray.length != 0) {
      if (category == 'inside') {
        this.spinner.show();
      }
      this.adminservice
        .SaveOrganizationHierarchy(this.treearray)
        .subscribe((saveOrg) => {
          if (saveOrg && saveOrg.status === "Success") {
            this.spinner.hide();
            var orgresult = "Organization details saved successfully ";
            this.openSnackBar(orgresult);
            this.orgStructure.getOrgStructure();
            this.GetOrganizationHierarchyTable();
            setTimeout(() => {
              if (category == 'inside') {
                if (type == 'next') {
                  this.router.navigateByUrl('/Admin/projectconfig');
                } else {
                  this.router.navigateByUrl('/Admin');
                }
              } else if (category == 'outside') {
                this.router.navigateByUrl(this.dynamicRouterURL.current);
              }
            }, 1100);
          } else {
            this.spinner.hide();
          }
        });
    } else {
      if (category == 'inside') {
        if (type == 'next') {
          this.router.navigateByUrl('/Admin/projectconfig');
        } else {
          this.router.navigateByUrl('/Admin');
        }
      } else if (category == 'outside') {
        this.router.navigateByUrl(this.dynamicRouterURL.current);
      }
    }
  }

  decodeEntities(str) {
    // this prevents any overhead from creating the object each time
    const element = document.createElement("div");
    if (str && typeof str === "string") {
      // strip script/html tags
      str = str.replace(/<script[^>]*>([\S\s]*?)<\/script>/gim, "");
      str = str.replace(/<\/?\w(?:[^"'>]|"[^"]*"|'[^']*')*>/gim, "");
      element.innerHTML = str;
      str = element.textContent;
      element.textContent = "";
    }
    return str;
  }
  /**
   * @event infopopup
   * @description Shows the details of the brandologo information
   */
  infoPopup() {
    this.dialog
      .open(AdminInfoPopupComponent, {
        backdropClass: "popupBackdropClass",
        width: "349px",
        height: "320px",
        data: {
          type: "Orgtree",
        },
        panelClass: "Admin-info-popup",
      })
      .afterClosed()
      .subscribe((result) => { });
  }
  openSnackBar(message) {
    this._snackBar.open(message, "", {
      panelClass: ["snackBar"],
      duration: 1000,
    });
  }
  ngOnDestroy(){
    this.subscription.unsubscribe();
  }
}
export interface PeriodicElement {
  organizationName: string;
  orgConfirmed: boolean;
  departmentName: string;
  departmentConfirmed: boolean;
  subDepartmentName: string;
  subDepartmentConfirmed: boolean;
}

let ELEMENT_DATA: any[] = [];
