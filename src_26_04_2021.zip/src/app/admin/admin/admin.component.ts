import { Component, Input, OnInit } from "@angular/core";
import { PdfserviceService } from "src/app/Services/pdfservice.service";

@Component({
  selector: "app-admin",
  templateUrl: "./admin.component.html",
  styleUrls: ["./admin.component.scss"],
})
export class AdminComponent implements OnInit {
  constructor(private PdfserviceService: PdfserviceService) {}
  ngOnInit() {
    this.PdfserviceService.annotation("admin");
  }
}
