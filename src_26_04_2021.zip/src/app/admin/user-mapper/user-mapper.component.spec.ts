import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserMapperComponent } from './user-mapper.component';

describe('UserMapperComponent', () => {
  let component: UserMapperComponent;
  let fixture: ComponentFixture<UserMapperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserMapperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserMapperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
