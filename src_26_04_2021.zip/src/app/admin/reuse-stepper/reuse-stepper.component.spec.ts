import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReuseStepperComponent } from './reuse-stepper.component';

describe('ReuseStepperComponent', () => {
  let component: ReuseStepperComponent;
  let fixture: ComponentFixture<ReuseStepperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReuseStepperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReuseStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
