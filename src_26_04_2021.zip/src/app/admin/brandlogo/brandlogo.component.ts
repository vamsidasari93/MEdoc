import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { MatDialog, MatSnackBar } from "@angular/material";
import { Router } from "@angular/router";
import { NgxSpinnerService } from "ngx-spinner";
import { Subscription } from "rxjs";
import { AdminService } from "src/app/Services/admin.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { AdminInfoPopupComponent } from "../admin-info-popup/admin-info-popup.component";

@Component({
  selector: "app-brandlogo",
  templateUrl: "./brandlogo.component.html",
  styleUrls: ["./brandlogo.component.scss"],
})
export class BrandlogoComponent implements OnInit {
  public defaultColors: string[] = [
    "#5c6bc0",
    "#9c27b0",
    "#607d8b",
    "#795548",
    "#00897b",
    "#2196f3"
  ];
  @Input() color: string;
  public imagePath;
  imgURL: any;
  public message: string;
  logodata: any;
  userid: any;
  brandurl: any;
  themecode: any;
  setupid: any;
  backgroundUrl: any;
  colorCode: any;
  refData: any;
  @ViewChild('file', { static: true }) file: any;
  private subscription: Subscription = new Subscription();
  public dynamicRouterURL: any;
  constructor(
    public dialog: MatDialog,
    private adminservice: AdminService,
    private _snackBar: MatSnackBar,
    private PdfserviceService: PdfserviceService,
    private spinner: NgxSpinnerService,
    private router: Router
  ) {
    var userdata = JSON.parse(localStorage.getItem("userinfo"));
    this.userid = userdata.userId;
    console.log(this.userid);
  }

  ngOnInit() {
    this.PdfserviceService.annotation("admin");
    this.getexistingtheme();
    this.PdfserviceService.getNavigateAdmin.subscribe((resp: any) => {
      this.dynamicRouterURL = resp;
      if (resp && resp.previous == '/Admin') {
        this.brandlogosubmit('outside');
        // this.subscription.unsubscribe();
      }
    })
  }

  /**
   * @event getexistingtheme
   * @description get existing theme colror code and blob url, adding sass key
   */
  getexistingtheme() {
    this.adminservice.getBrandlogo().subscribe((data: any) => {
      var addurl =
        "?st=2021-01-12T04%3A32%3A51Z&se=2022-01-13T04%3A32%3A00Z&sp=r&sv=2018-03-28&sr=c&sig=81%2Ft6qHcg7AdIivk7AEEPG%2BVytd2KNAAO7%2Flswv%2FL9o%3D";
      // "?st=2020-10-23T08%3A04%3A52Z&se=2021-10-24T08%3A04%3A00Z&sp=r&sv=2018-03-28&sr=c&sig=cM0RbjyJxl4RikXsxu1ENrqEm27Z4TgkX5KNH9pQeKQ%3D";
      if (data.orgLogoUrl) {
        this.backgroundUrl = data.orgLogoUrl + addurl;
      }
      this.themecode = data.orgThemeCode;
      this.refData = {
        orgLogoUrl: this.backgroundUrl,
        themecode: this.themecode
      }
      this.setupid = data.orgSetupId;
    });
  }
  /**
   * @event preview
   * @description After upload logo preview in UI
   * @parameter files
   */
  preview(files) {
    var FileSize = files[0].size;
    if (FileSize <= 5e6) {
      this.logodata = files[0];
      if (files.length === 0) return;
      var mimeType = files[0].type;
      if (mimeType == 'image/png' || mimeType == 'image/svg') {
        var reader = new FileReader();
        this.imagePath = files;
        reader.readAsDataURL(files[0]);
        reader.onload = (_event) => {
          this.backgroundUrl = reader.result;
        };
      } else {
        this.openSnackBar('Only images are supported');
        // this.message = "Only images are supported.";
        return;
      }
    } else {
      var response = "Image size should be less than 5MB";
      this.openSnackBar(response);
    }
  }
  removeImg() {
    this.imgURL = "";
    this.backgroundUrl = "";
    this.file.nativeElement.value = "";
    this.logodata = '';
  }

  /**
   * @event changeColor
   * @describe color theme change event
   */
  changeColor(paint) {
    this.colorCode = paint;
    this.themecode = this.colorCode;
  }
  /**
   *@event brandologosubmit
     @description Add or update logo and theme submit
   */
  brandlogosubmit(category) {
    const formData: FormData = new FormData();
    formData.append("orgLogo", this.logodata);
    // if (this.logodata) {
    // }
    formData.append("orgThemeCode", this.themecode);
    formData.append("createdBy", this.userid);
    if (this.setupid > 0) {
      formData.append("orgSetupId", this.setupid);
    } else {
      formData.append("orgSetupId", "0");
    }
    if (this.refData.orgLogoUrl != this.backgroundUrl || this.refData.themecode != this.themecode) {
      if (category == 'inside') {
        this.spinner.show(); 
      }
      this.adminservice
        .AddOrUpdateLogoAndTheme(formData)
        .subscribe((res: any) => {
          var result = res;
          this.getexistingtheme();
          if (
            result.responseMessage === "Successfully Updated" ||
            result.responseMessage === "Successfully Added"
          ) {
            this.spinner.hide();
            var response = "Logo/Theme saved successfully";
            this.openSnackBar(response);
            setTimeout(() => {
              if (category == 'inside') {
                this.router.navigateByUrl('/Admin/orgconfig');
              } else if (category == 'outside') {
                this.router.navigateByUrl(this.dynamicRouterURL.current);
              }
            }, 1100)
          } else {
            this.spinner.hide();
          }
        }, error => {
          this.spinner.hide();
        });
    } else {
      if (category == 'inside') {
        this.router.navigateByUrl('/Admin/orgconfig');
      } else if (category == 'outside') {
        this.router.navigateByUrl(this.dynamicRouterURL.current);
      }
    }
  }
  /**
   * @event infopopup
   * @description Shows the details of the brandologo information
   */
  infoPopup() {
    this.dialog
      .open(AdminInfoPopupComponent, {
        backdropClass: "popupBackdropClass",
        width: "349px",
        height: "320px",
        data: {
          type: "Brandlogo",
        },
        panelClass: "Admin-info-popup",
      })
      .afterClosed()
      .subscribe((result) => { });
  }
  openSnackBar(message) {
    this._snackBar.open(message, "", {
      panelClass: ["snackBar"],
      duration: 1000,
    });
  }
  ngOnDestroy(){
    this.subscription.unsubscribe();
  }
}
