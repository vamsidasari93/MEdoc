import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";
import { FlexLayoutModule } from "@angular/flex-layout";
import { BrandlogoComponent } from "./brandlogo/brandlogo.component";
import { OrgconfigurationComponent } from "./orgconfiguration/orgconfiguration.component";
import { ProjectconfigComponent } from "./projectconfig/projectconfig.component";
import { UserboardmappingComponent } from "./userboardmapping/userboardmapping.component";
import { SummerviewComponent } from "./summerview/summerview.component";
import {
  MatButtonModule,
  MatCardModule,
  MatCheckboxModule,
  MatDialogModule,
  MatFormFieldModule,
  MatIconModule,
  MatInputModule,
  MatRadioModule,
  MatSelectModule,
  MatSnackBarModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatTreeModule,
} from "@angular/material";
import { ReuseStepperComponent } from "./reuse-stepper/reuse-stepper.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
  PerfectScrollbarConfigInterface,
  PerfectScrollbarModule,
} from "ngx-perfect-scrollbar";
import { AdminComponent } from "./admin/admin.component";
import { AdminService } from "../Services/admin.service";
import { UserMapperComponent } from "./user-mapper/user-mapper.component";
import { OrgstructureComponent } from "./orgconfiguration/orgstructure/orgstructure.component";
import { RoleMapperComponent } from "./orgconfiguration/role-mapper/role-mapper.component";
import { TreeviewstructureComponent } from "./orgconfiguration/tree/treeviewstructure/treeviewstructure.component";
import { TreeeditstructureComponent } from "./orgconfiguration/tree/treeeditstructure/treeeditstructure.component";
import { BuildprojecttreeComponent } from "./orgconfiguration/buildprojecttree/buildprojecttree.component";
import { SharedDataService } from "./orgconfiguration/treeservices/shareddataservice";
import { DataService } from "./orgconfiguration/treeservices/dataservice";
import { ConfirmRemoveComponent } from "./orgconfiguration/confirm-remove/confirm-remove.component";
import { CdkTableModule } from "@angular/cdk/table";
import { ProjectactionComponent } from "./projectconfig/projectaction/projectaction.component";
import { ColorPickerModule } from "ngx-color-picker";
import { AdminInfoPopupComponent } from "./admin-info-popup/admin-info-popup.component";
import { DeletetreePopupComponent } from "./orgconfiguration/buildprojecttree/deletetree-popup/deletetree-popup.component";
import { AdminAuthGuard } from "../_helpers";

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true,
};
const routes: Routes = [
  {
    path: "",
    component: AdminComponent,
    canActivate: [AdminAuthGuard],
  },
  // {
  //   path: "Brandlogo",
  //   component: BrandlogoComponent,
  //   canActivate: [AdminAuthGuard],
  // },
  {
    path: "orgconfig",
    component: OrgconfigurationComponent,
    canActivate: [AdminAuthGuard],
  },
  {
    path: "projectconfig",
    component: ProjectconfigComponent,
    canActivate: [AdminAuthGuard],
  },
  {
    path: "UserBM",
    component: UserboardmappingComponent,
    canActivate: [AdminAuthGuard],
  },
  {
    path: "Summaryview",
    component: SummerviewComponent,
    canActivate: [AdminAuthGuard],
  },
];

@NgModule({
  declarations: [
    AdminComponent,
    BrandlogoComponent,
    OrgconfigurationComponent,
    ProjectconfigComponent,
    UserboardmappingComponent,
    SummerviewComponent,
    ReuseStepperComponent,
    UserMapperComponent,
    RoleMapperComponent,
    OrgstructureComponent,
    TreeviewstructureComponent,
    TreeeditstructureComponent,
    BuildprojecttreeComponent,
    ConfirmRemoveComponent,
    ProjectactionComponent,
    AdminInfoPopupComponent,
    DeletetreePopupComponent,
  ],
  entryComponents: [
    ProjectactionComponent,
    AdminInfoPopupComponent,
    DeletetreePopupComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FlexLayoutModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule,
    MatStepperModule,
    MatTableModule,
    MatFormFieldModule,
    FormsModule,
    MatInputModule,
    MatTreeModule,
    PerfectScrollbarModule,
    ReactiveFormsModule,
    MatSnackBarModule,
    MatCardModule,
    MatDialogModule,
    CdkTableModule,
    MatSelectModule,
    MatCheckboxModule,
    MatRadioModule,
    ColorPickerModule,
  ],
  providers: [SharedDataService, DataService],
})
export class AdminModule {}
