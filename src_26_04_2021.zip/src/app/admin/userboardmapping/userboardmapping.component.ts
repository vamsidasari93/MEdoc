import { Component, OnInit } from "@angular/core";
import { FormControl } from "@angular/forms";
import { MatDialog, MatSnackBar, MatTableDataSource } from "@angular/material";
import { Router } from "@angular/router";
import { NgxSpinnerService } from "ngx-spinner";
import { AdminService } from "src/app/Services/admin.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { AdminInfoPopupComponent } from "../admin-info-popup/admin-info-popup.component";
import { DeletetreePopupComponent } from "../orgconfiguration/buildprojecttree/deletetree-popup/deletetree-popup.component";
import * as _ from 'underscore';
import { Subscription } from "rxjs";

@Component({
  selector: "app-userboardmapping",
  templateUrl: "./userboardmapping.component.html",
  styleUrls: ["./userboardmapping.component.scss"],
})
export class UserboardmappingComponent implements OnInit {
  toppings = new FormControl();
  users = new FormControl();
  notFocused: boolean = false;
  selected = -1;
  toppingList: string[] = [];
  userList: any = [];
  Projectmappedlist: any[] = [];
  savedD: any[] = [];
  newRow: boolean = false;
  isDisable = true;
  public displayedColumns: string[] = [
    "departmentlistname",
    "roleslist",
    "userName",
    "emailid",
    "projectmapped",
    // "status",
    "action",
  ];
  dataSource = new MatTableDataSource(tabledata);
  projectConfig: any;
  departmentList: any[] = [];
  usermapid: any;
  department: any;
  createdby: any;
  existuserids: any[] = [];
  isBusy = false;
  private subscription: Subscription = new Subscription();
  dynamicRouterURL: any;
  constructor(
    private ads: AdminService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private PdfserviceService: PdfserviceService,
    private spinner: NgxSpinnerService,
    private router: Router
  ) {
    var userid = JSON.parse(localStorage.getItem("userinfo"));
    this.createdby = userid.userId;
  }

  ngOnInit() {
    this.PdfserviceService.annotation("admin");
    this.rolelist();
    this.departmentorgList();
    this.getconfigured();
    this.subscription = this.PdfserviceService.getNavigateAdmin.subscribe((resp: any) => {
      this.dynamicRouterURL = resp;
      if (resp && resp.previous == '/Admin/UserBM') {
        this.savedData('', 'outside');
        // this.subscription.unsubscribe();
      }
    })
  }

  disabledfield(element, indexId) {
    this.dataSource.data.map((table, index) => {
      if (element.userId === table.userId) {
        console.log("element", index, indexId);
        element.isDisable = false;
      }
    });
  }
  /**
   * @event getconfigured()
   * @Description get OnBoard userlists
   */
  getconfigured() {
    this.dataSource.data = [];
    this.ads.GetOnboardedUser().subscribe((data: any) => {
      let refData = _.sortBy(data, 'userId');
      this.projectConfig = refData.reverse();
      if (data.length <= 0) {
        this.addrow();
      }
      for (let i = 0; i < this.projectConfig.length; i++) {
        this.existuserids.push(this.projectConfig[i].userId);
        // this.ads
        //   .GetMappedUseCases(this.projectConfig[i].organizationHierarchyId)
        //   .subscribe((responselist) => {
        // this.Projectmappedlist = responselist;
        var roleids = [];
        for (
          let index = 0;
          index < this.projectConfig[i].roles.length;
          index++
        ) {
          roleids.push(this.projectConfig[i].roles[index].roleID);
        }
        if (this.projectConfig[i].useCases != null && this.projectConfig[i].useCases.length != 0) {
          var usecaseIds = [];
          for (let index = 0; index < this.projectConfig[i].useCases.length; index++) {
            if (this.projectConfig[i].useCases[index] != null) {
              usecaseIds.push(this.projectConfig[i].useCases[index].useCaseID);
            }
          }
        }
        var obj = {
          organizationHierarchyId: this.projectConfig[i]
            .organizationHierarchyId,
          departmentlistname: this.departmentList,
          roleslist: this.userList,
          // projectmapped: this.Projectmappedlist,
          inputopt: false,
          userName: this.projectConfig[i].userName,
          emailid: this.projectConfig[i].emailId,
          isConfirmed: this.projectConfig[i].isconfirmed,
          action: "",
          roles: roleids,
          useCases: usecaseIds,
          createdBy: this.createdby,
          userid: this.projectConfig[i].userId,
          localState: "exist",
          isDisable: true
        };
        this.dataSource.data.push(obj);
        this.dataSource.data = [...this.dataSource.data];
        // });
      }
    });
    console.log('log', this.dataSource.data);
  }
  /**
   * @event departmentorgList()
   *@description get dropdown departmentOrgList
   */
  departmentorgList() {
    this.ads.GetOrganizationList().subscribe((Dlist: any) => {
      this.departmentList = Dlist;
      let organizationHierarchyIdList = [];
      this.departmentList.forEach(item => {
        organizationHierarchyIdList.push(item.organizationHierarchyId)
      })
      this.ads.GetMappedUseCases(organizationHierarchyIdList).subscribe((responselist) => {
        this.Projectmappedlist = responselist;
      });
    });
  }
  /**
   * @event rolelist()
   *@description get dropdownrolelist
   */
  rolelist() {
    this.ads.GetUserRoles().subscribe((role: any) => {
      // this.userList = Rlist;
      role.forEach(item => {
        if (item.roleID == 3 || item.roleID == 4 || item.roleID == 5) {
          this.userList.push(item);
        }
      })
    });
  }
  /**
   * @event addrow()
   *@description add new row in table
   */
  addrow() {
    this.newRow = true;
    if (this.dataSource.data.length == 0) {
      var obj = {
        id: this.dataSource.data.length + 1,
        departmentlistname: this.departmentList,
        roleslist: this.userList,
        userName: "",
        emailid: "",
        projectmapped: this.Projectmappedlist,
        action: "",
        outputopt: "",
        localState: "Added"
      };
      this.dataSource.data.unshift(obj);
      this.dataSource.data = [...this.dataSource.data];
    } else {
      let newRow = this.dataSource.data[0];
      if (newRow.organizationHierarchyId &&
        newRow.userName &&
        newRow.emailid &&
        newRow.useCases.length > 0 &&
        newRow.roles.length > 0) {
        var obj = {
          id: this.dataSource.data.length + 1,
          departmentlistname: this.departmentList,
          roleslist: this.userList,
          userName: "",
          emailid: "",
          projectmapped: this.Projectmappedlist,
          action: "",
          outputopt: "",
          localState: "Added"
        };
        this.dataSource.data.unshift(obj);
        this.dataSource.data = [...this.dataSource.data];
      } else {
        this.openSnackBar('Please Fill all the details in previous row');
      }
    }

  }
  /**
   * @event delete()
   * @parameter index, userid
   *@description confiramation delete
   */
  delete(index, userid) {
    let data = {
      message: 'Are yous sure you want to remove'
    }
    this.dialog.open(DeletetreePopupComponent,
      {
        data: data
      })
      .afterClosed()
      .subscribe((result) => {
        if (result.data === "confirmed") {
          this.deleterow(index, userid);
        }
      });
  }
  /**
   * @event deleterow()
   * @parameter index, userid
   *@description remove entire row in table
   */
  deleterow(index, userid) {
    let deleterow = [];
    const data = this.dataSource.data;
    this.dataSource.data.splice(index, 1);
    this.dataSource.data = data;
    if (userid) {
      var obj = {
        userId: userid,
        state: "Removed",
      };
      deleterow.push(obj);
    } else {
      var resultres = "User mapped details delete successfully";
      this.openSnackBar(resultres);
    }

    if (deleterow.length > 0) {
      this.ads.UserOnboarding(deleterow).subscribe((result) => {
        if (result.status === "Success") {
          var resultres = "User mapped details delete successfully";
          this.openSnackBar(resultres);
        }
      });
    }
  }
  /**
   * @event checkModifiedExistData()
   * @parameter element, type, rowindex
   *@description existed data modifieds
   */
  checkModifiedExistData(element, type, rowindex) {
    this.ads
      .GetMappedUseCases([element.organizationHierarchyId])
      .subscribe((responselist) => {
        element.projectmapped = responselist;
      });
    for (let i = 0; i < this.dataSource.data.length; i++) {
      if (type == 'username' && element.userName != '' && rowindex != i && this.dataSource.data[i].userName.toLowerCase() == element.userName.toLowerCase()) {
        element.userName = "";
        this.openSnackBar("Username already exist");
      } else if (type == 'email' && element.emailid != '' && rowindex != i && this.dataSource.data[i].emailid == element.emailid) {
        element.emailid = "";
        this.openSnackBar("Email id already exist");
      } else {
        // element.userName = element.userName;
        // element.emailid = element.emailid;
      }
      if (
        this.dataSource.data[i].localState &&
        this.dataSource.data[i].localState != "Added" &&
        this.dataSource.data[i].userid === element.userid
      ) {
        this.dataSource.data[i].localState = "Modified";
      }
    }
  }
  /**
   * @event savedData()
   *@description save table data
   */
  savedData(type, category) {
    var savedD = [];
    let validaterow = false;
    let refArr = [];
    let dataRow = [];
    if (this.dataSource.data && this.dataSource.data.length != 0) {
      for (let i = 0; i < this.dataSource.data.length; i++) {
        var obj = {
          userId: this.dataSource.data[i].localState
            ? this.dataSource.data[i].userid
            : 0,
          userName: this.dataSource.data[i].userName,
          organizationHierarchyId: this.dataSource.data[i]
            .organizationHierarchyId,
          emailId: this.dataSource.data[i].emailid,
          createdBy: this.createdby,
          modifiedBy: this.createdby,
          roles: [],
          useCases: [],
          state: this.dataSource.data[i].localState
            ? this.dataSource.data[i].localState
            : "Added",
        };
        if (this.dataSource.data[i].roles) {
          this.dataSource.data[i].roles.forEach((role) => {
            let objRoles = this.userList.filter((x) => x.roleID === role);
            obj.roles.push(objRoles[0]);
          });
        }
        if (this.dataSource.data[i].useCases) {
          this.dataSource.data[i].useCases.forEach((ucase) => {
            let objusecase = this.Projectmappedlist.filter(
              (x) => x.useCaseID === ucase
            );
            obj.useCases.push(objusecase[0]);
          });
        }
        // if (
        //   this.dataSource.data[i].localState == "exist" &&
        //   obj.organizationHierarchyId &&
        //   obj.userName &&
        //   obj.emailId &&
        //   obj.useCases.length > 0 &&
        //   obj.roles.length > 0
        // ) {
        //   savedD.push(obj);
        //   // this.newRow = false;
        // }
        if (this.dataSource.data[i].localState === "Added" || this.dataSource.data[i].localState === "Modified") {
          dataRow.push(obj);
          refArr.push(obj);
        }
      }
    }
    dataRow.forEach(obj => {
      if (
        obj.organizationHierarchyId &&
        obj.userName &&
        obj.emailId &&
        obj.useCases.length > 0 &&
        obj.roles.length > 0
      ) {
        savedD.push(obj);
        // this.newRow = false;
      }
    })
    if (refArr.length == savedD.length) {
      validaterow = true;
    } else {
      validaterow = false;
    }
    if (savedD.length != 0 && validaterow) {
      this.spinner.show();
      this.ads.UserOnboarding(savedD).subscribe((result) => {
        if (result.status === "Success") {
          var resultres = "User mapped details saved successfully";
          this.openSnackBar(resultres);
          this.getconfigured();
          this.spinner.hide();
          setTimeout(() => {
            if (category == 'inside') {
              if (type == 'next') {
                this.router.navigateByUrl('/Admin/Summaryview');
              } else {
                this.router.navigateByUrl('/Admin/projectconfig');
              }
            } else if (category == 'outside') {
              this.router.navigateByUrl(this.dynamicRouterURL.current);
            }
          }, 1100)
        } else {
          this.spinner.hide();
          if (category == 'inside') {
            if (type == 'next') {
              this.router.navigateByUrl('/Admin/Summaryview');
            } else {
              this.router.navigateByUrl('/Admin/projectconfig');
            }
          } else if (category == 'outside') {
            this.router.navigateByUrl(this.dynamicRouterURL.current);
          }
        }
      });
    } else if (!validaterow) {
      this.openSnackBar('Please Fill all the details');
    }
    else {
      this.spinner.hide();
      if (category == 'inside') {
        if (type == 'next') {
          this.router.navigateByUrl('/Admin/Summaryview');
        } else {
          this.router.navigateByUrl('/Admin/projectconfig');
        }
      } else if (category == 'outside') {
        this.router.navigateByUrl(this.dynamicRouterURL.current);
      }
    }
  }
  /**
   * @event infopopup
   * @description Shows the details of the brandologo information
   */
  infoPopup() {
    this.dialog
      .open(AdminInfoPopupComponent, {
        backdropClass: "popupBackdropClass",
        width: "349px",
        height: "320px",
        data: {
          type: "userBoarding",
        },
        panelClass: "Admin-info-popup",
      })
      .afterClosed()
      .subscribe((result) => { });
  }

  openSnackBar(message) {
    this._snackBar.open(message, "", {
      panelClass: ["snackBar"],
      duration: 1000,
    });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}

export interface PeriodicElement {
  id: number;
  departmentlistname: [];
  roleslist: [];
  userName: string;
  userlist: string;
  projectmapped: [];
  action: string;
  outputopt: string;
}
let tabledata = [];
