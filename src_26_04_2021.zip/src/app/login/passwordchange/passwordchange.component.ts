import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passwordchange',
  templateUrl: './passwordchange.component.html',
  styleUrls: ['./passwordchange.component.scss']
})
export class PasswordchangeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
