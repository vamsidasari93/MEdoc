import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { ImageCroppedEvent, ImageTransform, Dimensions } from 'ngx-image-cropper';
@Component({
  selector: 'app-profile-pic',
  templateUrl: './profile-pic.component.html',
  styleUrls: ['./profile-pic.component.scss']
})
export class ProfilePicComponent implements OnInit {
  imageChangedEvent: any = '';
  croppedImage: any = '';
  scale = 1;
  showCropper = false;
  containWithinAspectRatio = false;
  transform: ImageTransform = {};
  picData: any = {
    src: "",
    fileType: ""
  };
  constructor(private _snackBar: MatSnackBar, public dialogRef: MatDialogRef<ProfilePicComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
  }

  convertBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file)
      fileReader.onload = () => {
        resolve(fileReader.result);
      }
      fileReader.onerror = (error) => {
        reject(error);
      }
    })
  }
  fileChangeEvent(event: any): void {
    this.picData.fileType = event.target.files[0].type.split("/")[1];
    let files = event.target.files;
    let f = files[0];
    const base64 = this.convertBase64(f);
    this.picData.src = base64;
    this.imageChangedEvent = event;
  }
  imageCropped(event: ImageCroppedEvent) {
    this.picData.src = event.base64;
    this.croppedImage = event.base64;

  }
  imageLoaded(image: HTMLImageElement) {
    // show cropper
  }
  cropperReady() {
    // cropper ready
  }
  loadImageFailed() {
    // show message
  }

  zoomOut() {
    this.scale -= .1;
    this.transform = {
      ...this.transform,
      scale: this.scale
    };
  }

  zoomIn() {
    this.scale += .1;
    this.transform = {
      ...this.transform,
      scale: this.scale
    };
  }

  saveProfilePic() {
    if (this.picData.src == '' || this.picData.fileType == '') {
      this.openSnackBar('Please Upload a Profile Picture');
      return;
    } else {
      this.dialogRef.close(this.picData);
    }
  }


  /**
  * @event - openSnackBar
  * @param data 
  */
  openSnackBar(message) {
    this._snackBar.open(message, "", {
      duration: 3000,
      panelClass: ["snackBar"],
    });
  }
}
