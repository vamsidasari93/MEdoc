import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ImageCropperModule } from "ngx-image-cropper";
import { RouterModule, Routes } from "@angular/router";
import { LoginComponent } from "./login.component";
import { ReactiveFormsModule } from "@angular/forms";
import { PasswordregisterComponent } from "./passwordregister/passwordregister.component";
import { PasswordresultComponent } from "./passwordresult/passwordresult.component";
import { PasswordeditComponent } from "./passwordedit/passwordedit.component";
import { MatIconModule, MatSelectModule } from "@angular/material";
import { ChangePasswordComponent } from "./change-password/change-password.component";
import { ProfileComponent } from "./profile/profile.component";
import { PasswordchangeComponent } from "./passwordchange/passwordchange.component";
import { MatSidenavModule } from "@angular/material/sidenav";
import { FormsModule } from "@angular/forms";
import { ProfilePicComponent } from "./profile-pic/profile-pic.component";
import { MatDialogModule } from "@angular/material/dialog";
import { MatButtonModule } from "@angular/material/button";
import { MsalGuard } from "@azure/msal-angular";
const routes: Routes = [
  {
    path: "register",
    component: PasswordregisterComponent,
  },
  {
    path: "passwordresult",
    component: PasswordresultComponent,
  },
  {
    path: "passwordedit",
    component: PasswordeditComponent,
  },
  {
    path: "passwordChange",
    component: ChangePasswordComponent,
  },
  {
    path: "profile",
    component: ProfileComponent,
  },
  {
    path: "",
    component: LoginComponent,
    canActivate: [MsalGuard]
  },
];
@NgModule({
  declarations: [
    LoginComponent,
    PasswordregisterComponent,
    PasswordresultComponent,
    PasswordeditComponent,
    ChangePasswordComponent,
    ProfileComponent,
    PasswordchangeComponent,
    ProfilePicComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ImageCropperModule,
    MatDialogModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    MatIconModule,
    MatSelectModule,
    MatSidenavModule,
    MatButtonModule,
  ],
  entryComponents: [ProfilePicComponent],
})
export class LoginModule {}
