import { Component, OnInit } from "@angular/core";
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators,
} from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { first } from "rxjs/operators";
import { AuthenticationService, UserService } from "src/app/_services";
import { NgxSpinnerService } from "ngx-spinner";
import {
  MatInput,
  MatDatepicker,
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from "@angular/material";

@Component({
  selector: "app-change-password",
  templateUrl: "./change-password.component.html",
  styleUrls: ["./change-password.component.scss"],
})
export class ChangePasswordComponent implements OnInit {
  changePassword: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error = "";
  errormsg = false;
  Success = "";
  hide: boolean = true;
  hideOld: boolean = true;
  confirmHide: boolean = true;
  email: string = "";
  horizontalPosition: MatSnackBarHorizontalPosition = "center";
  verticalPosition: MatSnackBarVerticalPosition = "top";
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private pdflogins: UserService,
    private _snackBar: MatSnackBar,
    private authenticationService: AuthenticationService,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe((queryParams) => {
      this.email = queryParams.email;
    });

    this.changePassword = this.formBuilder.group(
      {
        username: [
          this.email,
          Validators.compose([Validators.required, Validators.email]),
        ],
        oldPassword: ["", Validators.compose([Validators.required])],
        password: [
          "",
          [
            Validators.required,
            Validators.pattern(
              /^(?=\D*\d)(?=[^a-z]*[a-z])(?=[^A-Z]*[A-Z]).{8,28}$/
            ),
          ],
        ],
        confirmPassword: ["", [Validators.required]],
      },
      { validator: this.passwordConfirming }
    );
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.changePassword.controls;
  }

  passwordConfirming(f: AbstractControl): { invalid: boolean } {
    if (f.get("password").value !== f.get("confirmPassword").value) {
      return { invalid: true };
    }
  }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.changePassword.invalid) {
      return;
    }
    var obj = {
      emailId: this.f.username.value,
      // Password: this.f.password.value,
      password: this.f.confirmPassword.value,
      // remember: this.f.rememberMe.value,
      oldPassword: this.f.oldPassword.value,
      isAdActive: false,
    };
    this.spinner.show();
    this.pdflogins.ChangePassword(obj).subscribe(
      (data: any) => {
        this.spinner.hide();
        if (data.message == "Success.") {
          this.openSnackBar("Password updated successfully.");
          this.authenticationService.afterChangePassword();
          this.navigation();
        } else {
          this.openSnackBar("Please check your old password.");
        }
      },
      (error: any) => {
        console.log(error);
        this.spinner.hide();
      }
    );
  }

  navigation() {
    let userInfo = JSON.parse(localStorage.getItem("userinfo"));
    let roleId = userInfo.roles[0].roleID;
    if (roleId === 1 || roleId === 6) {
      //super admin //Admin
      this.router.navigate(["../Admin"]);
    } else if (roleId === 2) {
      // QC
      this.router.navigate(["../dashboard"]);
    } else if (roleId === 3 || roleId === 4 || roleId === 5) {
      //trainee & live & Datascience
      this.router.navigate(["../datascience"]);
    }
  }

  /**
   * @event - openSnackBar
   * @param data
   */
  openSnackBar(message) {
    message = message.charAt(0).toUpperCase() + message.slice(1);
    this._snackBar.open(message, "", {
      duration: 2 * 1000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }
}
