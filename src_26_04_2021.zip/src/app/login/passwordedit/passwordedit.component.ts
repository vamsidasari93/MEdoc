import { Component, OnInit } from "@angular/core";
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators,
} from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { first } from "rxjs/operators";
import { AuthenticationService, UserService } from "src/app/_services";
import { NgxSpinnerService } from "ngx-spinner";
import {
  MatInput,
  MatDatepicker,
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from "@angular/material";

@Component({
  selector: "app-passwordedit",
  templateUrl: "./passwordedit.component.html",
  styleUrls: ["./passwordedit.component.scss"],
})
export class PasswordeditComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error = "";
  errormsg = false;
  Success = "";
  hide: boolean;
  confirmHide: boolean;
  email: string = "";
  horizontalPosition: MatSnackBarHorizontalPosition = "center";
  verticalPosition: MatSnackBarVerticalPosition = "top";
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private pdflogins: UserService,
    private authenticationService: AuthenticationService,
    private _snackBar: MatSnackBar,
    private spinner: NgxSpinnerService
  ) {
    // redirect to home if already logged in
    if (this.authenticationService.currentUserValue) {
      this.router.navigate(["/Documents"]);
    }
  }
  ngOnInit() {
    this.route.queryParams.subscribe((queryParams) => {
      this.email = queryParams.email;
    });
    this.loginForm = this.formBuilder.group(
      {
        username: [
          this.email,
          Validators.compose([Validators.required, Validators.email]),
        ],
        password: [
          "",
          [
            Validators.required,
            Validators.pattern(
              /^(?=\D*\d)(?=[^a-z]*[a-z])(?=[^A-Z]*[A-Z]).{8,28}$/
            ),
          ],
        ],
        confirmPassword: ["", [Validators.required]],
      },
      { validator: this.passwordConfirming }
    );
    this.hide = true;
    this.confirmHide = true;
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }
  passwordConfirming(f: AbstractControl): { invalid: boolean } {
    if (f.get("password").value !== f.get("confirmPassword").value) {
      return { invalid: true };
    }
  }
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }
    var obj = {
      EmailId: this.f.username.value,
      // Password: this.f.password.value,
      Password: this.f.confirmPassword.value,
      // remember: this.f.rememberMe.value,
    };
    this.spinner.show();

    this.pdflogins.Updatepassword(obj).subscribe(
      (data: any) => {
        this.spinner.hide();
        var response = data;
        if (response.message == null) {
          this.Success = "Mail id not register";
          this.openSnackBar(this.Success);
          this.errormsg = true;
          setTimeout(() => (this.errormsg = false), 3000);
        } else {
          this.Success = " Password Updated SuccessFully";
          this.openSnackBar(this.Success);
          this.router.navigate(["/login"], {
            queryParams: { email: data.emailId },
          });
        }
      },
      (error) => {
        this.spinner.hide();
        this.error = error;
        this.loading = false;
      }
    );
  }

  /**
   * @event - openSnackBar
   * @param data
   */
  openSnackBar(message) {
    message = message.charAt(0).toUpperCase() + message.slice(1);
    this._snackBar.open(message, "", {
      duration: 2 * 1000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }
}
