import { BrowserModule } from "@angular/platform-browser";
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
// ----> Import PdfJsViewerModule here
import { PdfJsViewerModule } from "ng2-pdfjs-viewer";
import { MatToolbarModule } from "@angular/material/toolbar";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MatButtonModule } from "@angular/material/button";
import { MatGridListModule } from "@angular/material/grid-list";
import { MatTableModule } from "@angular/material/table";
import { FlexLayoutModule } from "@angular/flex-layout";
import { MatButtonToggleModule } from "@angular/material/button-toggle";
import { MatIconModule } from "@angular/material/icon";
import { MatSelectModule } from "@angular/material/select";
import { MatMenuModule } from "@angular/material/menu";
import { MatInputModule } from "@angular/material/input";
import { SharedModule } from "./SharedComponents/shared.module";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatFormFieldModule } from "@angular/material/form-field";
import { PdfserviceService } from "./Services/pdfservice.service";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { MatPaginatorModule } from "@angular/material/paginator";
import { MatCheckboxModule } from "@angular/material/checkbox";
import {
  JwtInterceptor,
  ErrorInterceptor,
  fakeBackendProvider,
} from "./_helpers";
import { HeadersComponent } from "./Common/headers/headers.component";
import { AdddocumentsdialogComponent } from "./Common/headers/adddocumentsdialog/adddocumentsdialog.component";
import {
  MatDialogModule,
  MatProgressSpinnerModule,
  MatSnackBarModule,
  MatTabsModule,
  MatTooltipModule,
} from "@angular/material";
import { PdffilesService } from "./Services/pdffiles.service";
import { DragDropDirective } from "./Services/dragDrop.directives";
import { NgxSpinnerModule, NgxSpinnerService } from "ngx-spinner";
import { RolemodulesComponent } from "./Common/rolemodules/rolemodules.component";
import { AdminService } from "./Services/admin.service";
import { DatascienceService } from "./Services/datascience.service";
import { NotificationPanelComponent } from "./Common/notification-panel/notification-panel.component";
import { DatePipe } from "@angular/common";
import { Configuration } from "msal";
import { environment } from "src/environments/environment";
import {
  MsalAngularConfiguration,
  MSAL_CONFIG,
  MSAL_CONFIG_ANGULAR,
  MsalService,
  MsalInterceptor,
  MsalModule,
} from "@azure/msal-angular";
import { NgIdleKeepaliveModule } from "@ng-idle/keepalive";
import { HelpPopupComponent } from "./Common/headers/help-popup/help-popup.component";
import { IdleComponent } from "./Common/idle/idle.component";
// import { FileSelectDirective } from "ng2-file-upload";
const MATERIAL_IMPORTS = [
  BrowserAnimationsModule,
  MatToolbarModule,
  MatButtonModule,
];

export const protectedResourceMap: [string, string[]][] = [
  [
    "https://docinsightdev.azurewebsites.net/api/Login",
    ["api://a88bb933-319c-41b5-9f04-eff36d985612/access_as_user"],
  ],
  ["https://graph.microsoft.com/v1.0/me", ["user.read"]],
];

function MSALConfigFactory(): Configuration {
  return {
    auth: {
      clientId: environment.clientId,
      authority: environment.authority,
      validateAuthority: true,
      redirectUri: environment.redirectUrl,
      postLogoutRedirectUri: environment.redirectUrl,
      navigateToLoginRequestUrl: true,
    },
    cache: {
      cacheLocation: "localStorage",
      storeAuthStateInCookie: true,
    },
  };
}

function MSALAngularConfigFactory(): MsalAngularConfiguration {
  return {
    popUp: false,
  };
}

@NgModule({
  declarations: [
    AppComponent,
    HeadersComponent,
    AdddocumentsdialogComponent,
    DragDropDirective,
    RolemodulesComponent,
    NotificationPanelComponent,
    HelpPopupComponent,
    IdleComponent,
    // FileSelectDirective,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgIdleKeepaliveModule.forRoot(),
    MsalModule,
    ...MATERIAL_IMPORTS,
    // ----> Import PdfJsViewerModule here
    PdfJsViewerModule,
    MatTabsModule,
    MatGridListModule,
    MatTableModule,
    FlexLayoutModule,
    MatButtonToggleModule,
    MatIconModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatInputModule,
    SharedModule,
    MatFormFieldModule,
    FormsModule,
    HttpClientModule,
    MatSlideToggleModule,
    MatPaginatorModule,
    MatCheckboxModule,
    ReactiveFormsModule,
    MatDialogModule,
    NgxSpinnerModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [NgxSpinnerModule],
  entryComponents: [
    AdddocumentsdialogComponent,
    HelpPopupComponent,
    IdleComponent,
  ],
  providers: [
    AdddocumentsdialogComponent,
    PdfserviceService,
    NgxSpinnerService,
    PdffilesService,
    AdminService,
    DatascienceService,
    DatePipe,
    // LivemoduleService,
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    // provider used to create fake backend
    fakeBackendProvider,
    // {
    //   provide: HTTP_INTERCEPTORS,
    //   useClass: MsalInterceptor,
    //   multi: true
    // },
    {
      provide: MSAL_CONFIG,
      useFactory: MSALConfigFactory,
    },
    {
      provide: MSAL_CONFIG_ANGULAR,
      useFactory: MSALAngularConfigFactory,
    },
    MsalService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
