import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable, Subject, throwError } from "rxjs";
import { map } from "rxjs/operators";
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from "@angular/common/http";
import { environment } from "src/environments/environment";
import { UserService } from "../_services";
@Injectable({
  providedIn: "root",
})
export class PdffilesService {
  moduleName: any;
  headers: any;
  // private role = new Subject();
  // Roles$ = this.role.asObservable();

  constructor(private http: HttpClient, private userservice: UserService) {}

  // rolename(value: any) {
  //   this.role.next(value);
  // }
  setuserdetails() {
    // var modules = this.userservice.getroleobj();
    // console.log(modules);
    // let userID = localStorage.getItem("userID");
    // console.log("userID", userID);
    // let roleID = localStorage.getItem("roleID");
    // this.headers = {
    //   userId: userID,
    //   roleId: roleID,
    // };
    let roleID = localStorage.getItem("roleID");

    if (roleID && roleID.length > 0) {
      if (roleID === "4") {
        this.moduleName = "Live";
      } else if (roleID === "3") {
        this.moduleName = "Training";
      }
    }
    // var module = localStorage.getItem("rolname");
    // if (module === "Live Module") {
    //   this.moduleName = "Live";
    // } else if (module === "Training Module") {
    //   this.moduleName = "Training";
    // }
  }
  getMaterialPdf() {
    return this.http.post(`${environment.apiUrl}`, { responseType: "json" });
    // return this.http.get('../assets/Data/data.Json');
  }
  // getreviewAnnotation() {
  //   return this.http.get("../assets/Data/segment.json");
  // }
  getAnnotationDetails(requestId, score) {
    this.setuserdetails();
    var url = `${environment.apiUrl}/${this.moduleName}/GetAnnotationDetails`;
    return this.http
      .post(`${url}?documentId=${requestId}&predictionPercentage=${score}`, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  getSegmentDetails(sliderPercent) {
    this.setuserdetails();
    let requestId = localStorage.getItem("documentId");
    var url = `${environment.apiUrl}/${this.moduleName}/GetSegmentDetails`;
    return this.http
      .post(
        `${url}?documentId=${requestId}&predictionPercentage=${sliderPercent}`,
        { responseType: "json" }
      )
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  DeleteDocument(requestId) {
    // console.log(requestId);
    this.setuserdetails();
    var url = `${environment.apiUrl}/${this.moduleName}/DeleteDocument`;
    return this.http
      .post(`${url}?documentId=${requestId}`, { responseType: "text" })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  // downloadCsv(requestId) {
  //   // console.log(requestId);
  //   this.setuserdetails();
  //   var url = `${environment.apiUrl}/${this.moduleName}/DownloadAnatationDetails`;
  //   // window.href = `${url}?documentId=${requestId}`
  //   return this.http.get(`${url}?documentId=${requestId}`).pipe(
  //     map((response: any) => {
  //       return response;
  //     })
  //   );
  // }

  getNavigtionlist(requestId) {
    this.setuserdetails();
    var url = `${environment.apiUrl}/${this.moduleName}/GetSegmentDetails`;
    return this.http
      .post(`${url}?documentId=${requestId}`, { responseType: "json" })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  searchNavigtionlist(body) {
    this.setuserdetails();
    var url = `${environment.apiUrl}/${this.moduleName}/SearchCroppedSegments`;
    return this.http.post(`${url}`, body).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  UpdateReassignvalue(savedata): Observable<boolean> {
    this.setuserdetails();
    const url = `${environment.apiUrl}/${this.moduleName}/UpdateReassignvalue`;
    var data = savedata;
    return this.http.post(url, savedata, { responseType: "text" }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  postFile(
    fileToUpload: File[],
    selectedUseCaseId,
    useCaseType
  ): Observable<boolean> {
    this.setuserdetails();
    console.log(fileToUpload);
    const formData: FormData = new FormData();
    for (let i = 0; i < fileToUpload.length; i++) {
      var file = fileToUpload[i];
      var filename = fileToUpload[i].name;
      formData.append("fileKey", file, filename);
    }
    const endpoint = `${environment.apiUrl}/${this.moduleName}/UploadPDF?usecaseId=${selectedUseCaseId}&type=${useCaseType}`;
    console.log(formData.get("fileKey"));
    // let userID = localStorage.getItem("userID");
    return this.http
      .post(endpoint, formData, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  updateUserConformation(updatedata): Observable<boolean> {
    this.setuserdetails();
    const url = `${environment.apiUrl}/${this.moduleName}/UpdateUserConfirmation`;
    var data = updatedata;
    return this.http
      .post(url, data, {
        responseType: "text",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  UpdateAttributeConfirmation(updatedata): Observable<boolean> {
    this.setuserdetails();
    const url = `${environment.apiUrl}/${this.moduleName}/UpdateAttributeConfirmation`;
    var data = updatedata;
    return this.http.post(url, data, { responseType: "text" }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  // getLabels() {
  //   this.setuserdetails();
  //   return this.http.get(`${environment.apiUrl}/Org/GetLabels`);
  // }
  getCategories(usecaseId) {
    this.setuserdetails();
    return this.http.post(
      `${environment.apiUrl}/Org/getCategories?usecaseId=${usecaseId}`,
      { responseType: "json" }
    );
  }
  getAttributeExtraction(docId) {
    console.log("services", docId);
    docId = localStorage.getItem("documentId");
    this.setuserdetails();
    return this.http.post(
      `${environment.apiUrl}/${this.moduleName}/getAttribute?documentId=${docId}`,
      { responseType: "json" }
    );
  }
  getAttributes(usecaseId) {
    this.setuserdetails();
    return this.http.post(
      `${environment.apiUrl}/Org/getAttributes?usecaseId=${usecaseId}`,
      { responseType: "json" }
    );
  }
  getDoumentslist(usecaseId) {
    this.setuserdetails();
    console.log("check", this.headers);
    return this.http.post(
      `${environment.apiUrl}/${this.moduleName}/GetAllDocumentBriefById?usecaseId=${usecaseId}`,
      { responseType: "json" }
    );
  }
  GetNotificationData(usecaseId) {
    this.setuserdetails();
    if (this.moduleName) {
      var lowercase = this.moduleName.toLowerCase();
    }
    return this.http.post(
      `${environment.apiUrl}/Org/GetNotificationData?notificationType=` +
        lowercase,
      { responseType: "json" }
    );
  }
  UpdateReadNotification(docId) {
    this.setuserdetails();
    return this.http.post(
      `${environment.apiUrl}/Org/UpdateReadNotification?documentId=` + docId,
      { responseType: "json" }
    );
  }
  //login api's
  Forgetpassword(requestId) {
    console.log(requestId);
    var url = `${environment.apiUrl}/Login/ForgotPassword`;
    return this.http
      .post(`${url}?emailId=${requestId}`, { responseType: "json" })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  // getMaterialPdf(): Observable<any> {
  //   let API_URL = `${this.apiUrl}`;
  //   return this.http
  //     .get(API_URL, {
  //       responseType: "arraybuffer",
  //     })
  //     .pipe(catchError(this.error));
  //   // return this.http.get(API_URL, data).pipe(catchError(this.error));
  // }
  // Handle Errors
  updateAttribute(savedata, id): Observable<boolean> {
    this.setuserdetails();
    const url = `${environment.apiUrl}/${this.moduleName}/Attribute?id=${id}`;
    return this.http.put(url, savedata, { responseType: "text" }).pipe(
      map((response: any) => {
        return response;
        console.log(response);
      })
    );
  }

  updateExtractionAttribute(savedata, id): Observable<boolean> {
    this.setuserdetails();
    const url = `${environment.apiUrl}/${this.moduleName}/attributeExtraction?id=${id}`;
    return this.http.put(url, savedata, { responseType: "text" }).pipe(
      map((response: any) => {
        return response;
        console.log(response);
      })
    );
  }

  error(error: HttpErrorResponse) {
    let errorMessage = "";
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log("gettingerror", errorMessage);
    return throwError(errorMessage);
  }
}
