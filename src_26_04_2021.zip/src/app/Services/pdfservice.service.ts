import { Injectable } from "@angular/core";
import { Observable, throwError, Subject } from "rxjs";

import {
  HttpHeaders,
  HttpClient,
  HttpErrorResponse,
} from "@angular/common/http";
import { BehaviorSubject } from "rxjs/internal/BehaviorSubject";

@Injectable({
  providedIn: "root",
})
export class PdfserviceService {
  headers = new HttpHeaders().set("Content-Type", "application/json");
  public displayCards = new BehaviorSubject(false);
  public uploadDocument = new BehaviorSubject(false);
  public activetabs = new BehaviorSubject(false);
  // public adminNavigateValidation = new BehaviorSubject(false);
  public isgrid = false;
  setgrid(grid: boolean) {
    this.isgrid = grid;
  }
  getgrid() {
    return this.isgrid;
  }
  private error = new Subject();
  errors$ = this.error.asObservable();

  private sub = new Subject();
  subj$ = this.sub.asObservable();

  private checkmodule = new Subject();
  checkmodules$ = this.checkmodule.asObservable();

  private croppedcheck = new Subject();
  croppedChecks$ = this.croppedcheck.asObservable();

  private resultResponse = new Subject();
  resultResponses$ = this.resultResponse.asObservable();

  private link = new Subject();
  links$ = this.link.asObservable();

  private searchValue = new Subject();
  searchValue$ = this.searchValue.asObservable();

  private annotations = new Subject();
  annatation$ = this.annotations.asObservable();

  private reviewannatations = new Subject();
  reviewannatation$ = this.reviewannatations.asObservable();

  private annatationscount = new Subject();
  countannatation$ = this.annatationscount.asObservable();

  private condensedscore = new Subject();
  condensedscores$ = this.condensedscore.asObservable();

  private loginstates = new Subject();
  loginstate$ = this.loginstates.asObservable();

  private refreshModalList = new Subject();
  refreshModalList$ = this.refreshModalList.asObservable();

  checked = new Observable((observer) => {
    let value = "checked";
  });
  private useCaseName = new Subject();
  useCaseName$ = this.useCaseName.asObservable();

//notifiaction
  private notify = new Subject();
  notification$ = this.notify.asObservable();
  //adminNotification
  private adminNavigateValidation = new Subject();
  getNavigateAdmin = this.adminNavigateValidation.asObservable();
  constructor(private http: HttpClient) {}

  send(value: any) {
    this.sub.next(value);
  }
  notification(value: any) {
    this.notify.next(value);
  }
  loginalert(value: any) {
    this.loginstates.next(value);
  }
  checkedmodules(value: any) {
    this.checkmodule.next(value);
  }
  croppedSegmentCheck(value: any) {
    this.croppedcheck.next(value);
  }
  updateResultresponse(value: any) {
    this.resultResponse.next(value);
  }

  geterrors(value: any) {
    this.error.next(value);
  }
  sendlink(value: any) {
    this.link.next(value);
  }
  searchvalue(value: any) {
    this.searchValue.next(value);
  }
  annotation(value: any) {
    this.annotations.next(value);
  }
  conndensedScore(value: any) {
    this.condensedscore.next(value);
  }
  reviewannatation(value: any) {
    this.reviewannatations.next(value);
  }
  annatationCount(value: any) {
    this.annatationscount.next(value);
  }
  setUseCaseName(value: any) {
    this.useCaseName.next(value);
  }
  refreshModalListM(data: any) {
    this.refreshModalList.next(data);
  }

  setNavigateAdmin(data: any) {
    this.adminNavigateValidation.next(data);
  }
}
