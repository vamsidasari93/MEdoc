import {
  AfterViewInit,
  Component,
  OnDestroy,
  OnInit,
  ViewChild,
} from "@angular/core";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { ActivatedRoute, Router } from "@angular/router";
import { MatTableDataSource } from "@angular/material/table";
import { SelectionModel } from "@angular/cdk/collections";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
// import { SimpleChanges } from "@angular/core";

import { PdffilesService } from "src/app/Services/pdffiles.service";
import { HttpClient } from "@angular/common/http";
import { map } from "rxjs/operators";
import { MatDialog, MatSnackBar } from "@angular/material";
import { interval, Subscription } from "rxjs";
import { DeletedocumentComponent } from "./deletedocument/deletedocument.component";
import { environment } from "src/environments/environment";
import { SharedHelpPopupComponent } from "../shared-help-popup/shared-help-popup.component";
import { AddDocumentComponent } from "./add-document/add-document.component";
import { NgxSpinnerService } from "ngx-spinner";
let TABLE_DATA: [{ documentName: string }];

@Component({
  selector: "app-documents",
  templateUrl: "./documents.component.html",
  styleUrls: ["./documents.component.scss"],
})
export class DocumentsComponent implements OnInit, AfterViewInit, OnDestroy {
  pdfFiles: any;
  pdfData: any;
  checked: any;
  selection: any;
  searchValue: any;
  updatedfiles: any;
  updatenewfile: any;
  documentId: any;
  download: any;
  documentimg: any;
  documentName: any;
  response: any;
  subscription: Subscription;
  intervalId: any;
  resultfileList = [];
  isadded: boolean = false;
  predefinedSeg: boolean = false;
  displayedColumns = [
    "client",
    "Business Unit",
    "Tender Description",
    "Pages",
    "Uploaded on",
    "Uploaded by",
    "Annotations",
    "Action",
  ];
  dataSource = new MatTableDataSource(TABLE_DATA);

  activetabSubcribe: Subscription;
  userName: any;
  useCaseId: any;
  nodocumentsMsg: boolean = false;
  @ViewChild(MatPaginator, { static: false }) set content(
    paginator: MatPaginator
  ) {
    this.dataSource.paginator = paginator;
  }

  // @ViewChild(MatSort, { static: false }) set contentValue(sort: MatSort) {
  //   this.dataSource.sort = sort;
  // }
  // @ViewChild(MatSort, { static: true }) sort: MatSort;
  constructor(
    private PdfserviceService: PdfserviceService,
    private PdffilesService: PdffilesService,
    private http: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private spinner: NgxSpinnerService
  ) {
    var userName = JSON.parse(localStorage.getItem("userinfo"));
    this.userName = userName.userName;
    this.checked = this.PdfserviceService.getgrid();
    this.PdfserviceService.subj$.subscribe((val) => {
      var checked = val;
      // this.checked = false;
      if (checked === "listview" || checked === true) {
        this.checked = true;
      } else {
        this.checked = false;
      }
    });
    this.PdffilesService.setuserdetails();
    this.PdfserviceService.croppedChecks$.subscribe((val: boolean) => {
      console.log("document view", val);
      this.predefinedSeg = val;
    });
    this.PdfserviceService.errors$.subscribe((val: any) => {
      this.openSnackBar(val);
    });
    this.PdfserviceService.resultResponses$.subscribe((val: any) => {
      console.log("response-value", val);
      // if (val === "File uploaded successfully") {
      // this.spinner.show();
      if (val.length > 0) {
        for (let i = 0; i < val.length; i++) {
          let response = val[i];
          // this.spinner.hide();
          this.openSnackBar(response);
        }
      } else {
        this.openSnackBar(val);
      }
      this.getDocuments();
      this.getresponse();
      // }
      //  else {
      //   this.openSnackBar(val);
      // }
    });
  }

  ngOnInit() {
    this.PdfserviceService.annotation("Documentlist");
    this.useCaseId = atob(this.activatedRoute.snapshot.paramMap.get("id"));
    this.getDocuments();
    // this.PdfserviceService.searchValue$.subscribe((val) => {
    //   this.searchValue = val;
    if (this.searchValue) {
      console.log(this.searchValue);
      const filterValue = this.searchValue;
      this.dataSource.filter = filterValue.trim().toLowerCase().includes();
    }
    // });
  }
  keyPressAlphaNumeric(event) {
    var inp = String.fromCharCode(event.keyCode);
    if (/[a-zA-Z0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  getresponse() {
    this.isadded = true;
    clearInterval(this.intervalId);
    this.intervalId = setInterval(() => {
      this.getAddDocumentslist();
    }, 300000);
  }
  /***
   * @event-getDocuments
   * @parameters empty
   * @description getting all documents
   */
  getDocuments() {
    // let documentParam = {
    //   usecaseId: this.useCaseId,
    // };
    let useCaseId = localStorage.getItem("useCaseId");
    if (
      this.useCaseId !== null &&
      this.useCaseId !== undefined &&
      this.useCaseId > 0
    ) {
      this.PdffilesService.getDoumentslist(useCaseId).subscribe(
        (tabledata: any) => {
          this.pdfFiles = tabledata.reverse();
          if (this.pdfFiles && this.pdfFiles.length > 0) {
            var urldata = environment.urldata;
            for (var i in this.pdfFiles) {
              this.documentId = this.pdfFiles[i].documentId;
              if (this.pdfFiles[i].blobURL) {
                this.pdfFiles[i].blobURL = this.pdfFiles[i].blobURL + urldata;
                this.download = this.pdfFiles[i].blobURL + urldata;
              }
              if (this.pdfFiles[i].thumbnails) {
                this.pdfFiles[i].thumbnails =
                  this.pdfFiles[i].thumbnails + urldata;
              }
              if (this.pdfFiles[i].status === "InProgress") {
                // this.PdfserviceService.uploadDocument.next(true);
                this.resultfileList.push(this.pdfFiles[i].documentId);
                if (this.isadded == false) {
                  clearInterval(this.intervalId);
                  // console.log("hello checking");
                  this.getresponse();
                }
              }
            }
            TABLE_DATA = this.pdfFiles;

            this.dataSource = new MatTableDataSource(TABLE_DATA);
            console.log(this.dataSource);

            // this.dataSource.sort = this.sort;
            this.selection = new SelectionModel(true, []);
          } else {
            this.nodocumentsMsg = true;
          }
        }
      );
    }
  }
  getAddDocumentslist() {
    // let documentParam = {
    //   usecaseId: this.useCaseId,
    // };
    this.nodocumentsMsg = false;
    let useCaseId = localStorage.getItem("useCaseId");
    if (
      this.useCaseId !== null &&
      this.useCaseId !== undefined &&
      this.useCaseId > 0
    ) {
      this.PdffilesService.getDoumentslist(useCaseId).subscribe(
        (response: any) => {
          console.log(response, this.resultfileList);
          let z = 0;
          for (var i = 0; i < this.resultfileList.length; i++) {
            var dataresult = this.resultfileList[i];
            var mapresult = response.find((o) => o.documentId === dataresult);
            // console.log(mapresult);
            if (
              mapresult.status === "Completed" ||
              mapresult.status === "Success"
            ) {
              z++;
            }
            if (
              i == this.resultfileList.length &&
              z == this.resultfileList.length
            ) {
              this.getDocuments();
              this.PdfserviceService.uploadDocument.next(false);
              clearInterval(this.intervalId);
            } else if (z > 0) {
              this.getDocuments();
            }
          }
        }
      );
    }
  }

  downloadpdf(documentId, downloadurl, documentname) {
    console.log(documentname);
    const link = document.createElement("a");
    link.setAttribute("href", downloadurl);
    // link.setAttribute("download", documentname);
    // link.download = documentname;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => {
      this.response = "Document downloaded successfully";
      this.openSnackBar(this.response);
    }, 1000);
  }
  deletedocument(id, i) {
    var index = this.pdfFiles.findIndex((x) => x.documentId === id);
    let deleteConfirmation;
    this.dialog
      .open(DeletedocumentComponent, {})
      .afterClosed()
      .subscribe((val) => {
        // console.log("data", val.data);
        deleteConfirmation = val.data;
        if (i > -1 && deleteConfirmation === "confirmed") {
          console.log("delete res", deleteConfirmation);
          this.PdffilesService.DeleteDocument(id).subscribe((val: any) => {
            console.log("delete res", val);
            var deleteresponse = val;
            if (deleteresponse === "success") {
              this.response = "Document deleted Successfully";
              const data = this.dataSource.data;
              this.dataSource.data.splice(index, 1);
              this.dataSource.data = data;
              this.getDocuments();
              this.openSnackBar(this.response);
            } else {
              this.response = "Document deleted Unsuccessfully";
              this.openSnackBar(this.response);
            }
          });
        }
      });
  }
  DocumentClick(e, id, filename, segmentedPDFURL) {
    this.PdfserviceService.activetabs.next(true);
    this.PdfserviceService.croppedSegmentCheck(this.predefinedSeg);
    //docinsigts sass key
    var addurl = environment.urldata;
    var downloadurl = segmentedPDFURL + addurl;
    console.log(downloadurl);
    if (segmentedPDFURL !== null) {
      localStorage.setItem("segmentedPDFURL", downloadurl);
      localStorage.setItem("documentName", filename);
    }
    this.router.navigate([
      "Documentslist/AnnotationDocument",
      { id: btoa(id) },
    ]);
  }

  // ngOnChanges(changes: SimpleChanges) {
  //   // changes.prop contains the old and the new value...
  //   this.checkToggle();
  // }

  ngAfterViewInit() {}
  // checkToggle() {
  //   this.PdfserviceService.subj$.subscribe((val) => {
  //     var checked = val;
  //     if (checked === "listview" || checked === true) {
  //       this.checked = true;
  //     } else {
  //       this.checked = false;
  //     }
  //   });
  // }

  ngOnDestroy() {
    clearInterval(this.intervalId);
  }
  openSnackBar(message) {
    message = message.charAt(0).toUpperCase() + message.slice(1);
    this._snackBar.open(message, "", {
      duration: 3000,
      panelClass: ["snackBar"],
      // horizontalPosition: this.horizontalPosition,
      // verticalPosition: this.verticalPosition,
    });
  }

  // /**
  //  * @event infopopup
  //  * @description Shows the details of the brandologo information
  //  */
  // infoPopup() {
  //   let roleId = localStorage.getItem("roleID");
  //   if (roleId === "4") {
  //     this.dialog
  //       .open(SharedHelpPopupComponent, {
  //         backdropClass: "popupBackdropClass",
  //         width: "349px",
  //         height: "320px",
  //         data: {
  //           type: "documentsView-live",
  //         },
  //         panelClass: "Admin-info-popup",
  //       })
  //       .afterClosed()
  //       .subscribe((result) => {});
  //   } else {
  //     this.dialog
  //       .open(SharedHelpPopupComponent, {
  //         backdropClass: "popupBackdropClass",
  //         width: "349px",
  //         height: "320px",
  //         data: {
  //           type: "documentsView-training",
  //         },
  //         panelClass: "Admin-info-popup",
  //       })
  //       .afterClosed()
  //       .subscribe((result) => {});
  //   }
  // }

  // applyFilter(filterValue: string) {
  //   filterValue = filterValue.trim(); // Remove whitespace
  //   filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
  //   this.dataSource.filter = filterValue;
  // }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  addDocuments() {
    const dialogRef = this.dialog.open(AddDocumentComponent, {});
    dialogRef.afterClosed().subscribe((val) => {
      console.log("aftercloseing", val);
      // this.spinner.show();
    });
  }
}
