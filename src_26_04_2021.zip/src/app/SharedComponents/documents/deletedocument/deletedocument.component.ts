import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: "app-deletedocument",
  templateUrl: "./deletedocument.component.html",
  styleUrls: ["./deletedocument.component.scss"],
})
export class DeletedocumentComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<DeletedocumentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}
  onNoClick(): void {
    this.dialogRef.close();
  }
  confirm() {
    this.dialogRef.close({ data: "confirmed" });
  }
}
