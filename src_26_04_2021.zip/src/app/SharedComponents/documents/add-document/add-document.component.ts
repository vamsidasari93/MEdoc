import { Component, Inject, OnInit, ViewChild } from "@angular/core";
import { MatDialogRef, MatSnackBar, MAT_DIALOG_DATA } from "@angular/material";
import { NgxSpinnerService } from "ngx-spinner";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";

@Component({
  selector: "app-add-document",
  templateUrl: "./add-document.component.html",
  styleUrls: ["./add-document.component.scss"],
})
export class AddDocumentComponent implements OnInit {
  fileName: any;
  file: File;
  url: any;
  a: any;
  clicked = false;
  show = false;
  apiResponse: any;
  fileList: File[] = [];
  listOfFiles: any[] = [];
  @ViewChild("file", { static: true }) attachment: any;
  // files: FileHandle[] = [];
  resultfileList = [];
  constructor(
    public dialogRef: MatDialogRef<AddDocumentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private PdfserviceService: PdfserviceService,
    private PdffilesService: PdffilesService,
    private _snackBar: MatSnackBar,
    private spinner: NgxSpinnerService
  ) {}

  ngOnInit() {}
  onNoClick(): void {
    this.dialogRef.close();
  }
  trigger() {
    let element = document.getElementById("upload_file") as HTMLInputElement;
    element.click();
  }

  onChange(file, event) {
    this.clicked = false;
    console.log(file, event);
    for (var i = 0; i <= event.target.files.length - 1; i++) {
      var selectedFile = event.target.files[i];
      this.file = selectedFile;
      this.fileList.push(selectedFile);
      this.listOfFiles.push(selectedFile.name);
    }
    this.attachment.nativeElement.value = "";
  }

  removeFile(index) {
    // Delete the item from fileNames list
    this.listOfFiles.splice(index, 1);
    // delete file from FileList
    this.fileList.splice(index, 1);
    this.clicked = false;
  }
  handleDrop(event, files) {
    console.log(event, files);
    for (var i = 0; i <= files.length - 1; i++) {
      var selectedFile = files[i];
      this.file = selectedFile;
      this.fileList.push(selectedFile);
      this.listOfFiles.push(selectedFile.name);
    }
    this.attachment.nativeElement.value = "";
  }
  submitFile() {
    this.dialogRef.close();
    this.spinner.show();
    this.resultfileList = [];
    this.PdfserviceService.uploadDocument.next(true);
    let selectedUseCaseId = localStorage.getItem("useCaseId");
    let useCaseType = localStorage.getItem("useCaseType");
    this.PdffilesService.postFile(this.fileList, selectedUseCaseId, useCaseType)
      .pipe()
      .subscribe((response: any) => {
        this.spinner.hide();
        var resStatus = [];
        console.log("statusbefore", response);
        for (let i = 0; i < response.length; i++) {
          resStatus.push(response[i].responseMessage);
          this.PdfserviceService.updateResultresponse(resStatus);
          if (response[i].status === "Failed") {
            this.openSnackBar(response[i].responseMessage);
          }
        }

        // if ((statusmsg.status = "Success")) {
        //   this.dialogRef.close();
        //   // var response = statusmsg.status;
        //   // this.resultfileList = response;
        //   setTimeout(() => {
        //     this.PdfserviceService.updateResultresponse(
        //       statusmsg.responseMessage
        //     );
        //   }, 1000);
        //   this.PdfserviceService.uploadDocument.next(true);
        // } else {
        //   this.PdfserviceService.updateResultresponse(
        //     statusmsg.responseMessage
        //   );
        // }
      });
  }
  openSnackBar(message) {
    this._snackBar.open(message, "", {
      duration: 1000,
      panelClass: ["snackBar"],
      // horizontalPosition: this.horizontalPosition,
      // verticalPosition: this.verticalPosition,
    });
  }
}
