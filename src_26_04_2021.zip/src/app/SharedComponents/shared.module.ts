import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Routes, RouterModule } from "@angular/router";
import { DocumentsComponent } from "./documents/documents.component";
import { MatCardModule } from "@angular/material/card";
import { FlexLayoutModule } from "@angular/flex-layout";
import { SearchComponent } from "./search/search.component";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatIconModule } from "@angular/material/icon";
import { FormsModule } from "@angular/forms";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { MatTableModule } from "@angular/material/table";
import { MatCheckboxModule } from "@angular/material/checkbox";

import { MatSortModule } from "@angular/material/sort";
import { MatSelectModule } from "@angular/material/select";
import { MatPaginatorModule } from "@angular/material/paginator";
import {
  MatButtonModule,
  MatDialogModule,
  MatProgressBarModule,
  MatSnackBarModule,
  MatTooltipModule,
} from "@angular/material";
import { SearchpipemoduleModule } from "../pipe/searchpipemodule/searchpipemodule.module";
import { OrderModule } from "ngx-order-pipe";
import { DeletedocumentComponent } from "./documents/deletedocument/deletedocument.component";
import { DashboardAuthGuard } from "../_helpers";
import { SharedHelpPopupComponent } from "./shared-help-popup/shared-help-popup.component";
import { AddDocumentComponent } from "./documents/add-document/add-document.component";
import { NgxPaginationModule } from "ngx-pagination";

const routes: Routes = [
  {
    path: "AnnotationDocument",
    loadChildren: () =>
      import("../components/doc-pdf/doc-pdf.module").then(
        (m) => m.DocPDfModule
      ),
    canActivate: [DashboardAuthGuard],
  },
  {
    path: "Documentslistlive/:id",
    component: DocumentsComponent,
    canActivate: [DashboardAuthGuard],
  },
  {
    path: "Documents/:id",
    component: DocumentsComponent,
    canActivate: [DashboardAuthGuard],
  },
  {
    path: "",
    component: DocumentsComponent,
    canActivate: [DashboardAuthGuard],
  },
];

@NgModule({
  declarations: [
    DocumentsComponent,
    SearchComponent,
    DeletedocumentComponent,
    SharedHelpPopupComponent,
    AddDocumentComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MatCardModule,
    FlexLayoutModule,
    MatFormFieldModule,
    MatIconModule,
    FormsModule,
    Ng2SearchPipeModule,
    MatTableModule,
    MatCheckboxModule,
    MatSelectModule,
    MatPaginatorModule,
    MatCheckboxModule,
    MatSortModule,
    MatSnackBarModule,
    SearchpipemoduleModule,
    MatProgressBarModule,
    OrderModule,
    MatTooltipModule,
    MatDialogModule,
    MatButtonModule,
    NgxPaginationModule,
  ],
  entryComponents: [
    DeletedocumentComponent,
    SharedHelpPopupComponent,
    AddDocumentComponent,
  ],
  exports: [SearchComponent, MatSortModule],
})
export class SharedModule {}
