﻿import { Location } from "@angular/common";
import { Injectable } from "@angular/core";
import {
  Router,
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  ActivatedRoute,
  NavigationCancel,
} from "@angular/router";

import { AuthenticationService } from "../_services";

@Injectable({ providedIn: "root" })
export class AuthGuard implements CanActivate {
  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    // console.log("testing ", route);
    const currentUser = this.authenticationService.currentUserValue;
    if (currentUser) {
      // check if route is restricted by role
      if (
        currentUser.role &&
        currentUser.role.indexOf(currentUser.role) === -1
      ) {
        // role not authorised so redirect to home page
        this.router.navigate(["/"]);
        return false;
      }

      // authorised so return true
      return true;
    }

    // not logged in so redirect to login page with the return url
    this.router.navigate(["/login"], { queryParams: { returnUrl: state.url } });
    return false;
  }
}

/**
 * Dashboard Authguard rolesid -1,2,3,4,5
 */
@Injectable({ providedIn: "root" })
export class DashboardAuthGuard implements CanActivate {
  public roleIds = [];
  constructor(
    private router: Router,
    private _location: Location,
    private _activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService
  ) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationCancel) {
        console.log("eventurl", event.url);
      }
    });

    let userInfo = JSON.parse(localStorage.getItem("userinfo"));
    userInfo.roles.forEach((role) => {
      this.roleIds.push(role.roleID);
    });
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    let flag = true;
    this.roleIds.forEach((roleID) => {
      if (
        roleID === 6 ||
        roleID === 2 ||
        roleID === 3 ||
        roleID === 4 ||
        roleID === 5
      ) {
        flag = true;
      } else {
        this._location.back();
        flag = false;
      }
    });
    return flag;
  }
}
/**
 * Datascience Authguard rolesid -1,5
 */
@Injectable({ providedIn: "root" })
export class DatascienceAuthGuard implements CanActivate {
  public roleIds = [];
  constructor(
    private router: Router,
    private _location: Location,
    private _activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService
  ) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationCancel) {
        console.log("eventurl", event.url);
      }
    });

    let userInfo = JSON.parse(localStorage.getItem("userinfo"));
    userInfo.roles.forEach((role) => {
      this.roleIds.push(role.roleID);
    });
  }
  checkRoleId(id) {
    var roleList = JSON.parse(localStorage.getItem("usersrole"));
    console.log("dataact", roleList, id);
    let CroleID = roleList.findIndex((x) => x.role_id == id);
    if (CroleID >= 0) {
      return true;
    } else {
      return false;
    }
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    let flag = true;
    this.roleIds.forEach((roleID) => {
      if (this.checkRoleId(5)) {
        flag = true;
      } else {
        this._location.back();
        flag = false;
      }
    });
    return flag;
  }
}
/**
 * admin Authguard rolesid -1,6
 */
@Injectable({ providedIn: "root" })
export class AdminAuthGuard implements CanActivate {
  public roleIds = [];
  constructor(
    private router: Router,
    private _location: Location,
    private _activatedRoute: ActivatedRoute,
    private authenticationService: AuthenticationService
  ) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationCancel) {
        console.log("eventurl", event.url);
      }
    });

    let userInfo = JSON.parse(localStorage.getItem("userinfo"));
    userInfo.roles.forEach((role) => {
      this.roleIds.push(role.roleID);
    });
  }
  checkRoleId(id) {
    var roleList = JSON.parse(localStorage.getItem("usersrole"));
    console.log("dataact", roleList, id);
    let CroleID = roleList.findIndex((x) => x.role_id == id);
    if (CroleID >= 0) {
      return true;
    } else {
      return false;
    }
  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    let flag = true;
    this.roleIds.forEach((roleID) => {
      if (this.checkRoleId(6)) {
        flag = true;
      } else {
        this._location.back();
        flag = false;
      }
    });
    return flag;
  }
}
