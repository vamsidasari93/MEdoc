import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modelling-extraction',
  templateUrl: './modelling-extraction.component.html',
  styleUrls: ['./modelling-extraction.component.scss']
})
export class ModellingExtractionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
