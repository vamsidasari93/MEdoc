import { Component, OnInit, ViewChild } from "@angular/core";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { ChartDataSets, ChartOptions, ChartType } from "chart.js";
import * as pluginDataLabels from "chartjs-plugin-datalabels";
import ChartDataLabels from "chartjs-plugin-datalabels";
import { MatInput, MatDatepicker } from "@angular/material";
import { DashboardService } from "src/app/Services/dashboard.service";
import { BaseChartDirective } from "ng2-charts";
import * as _moment from "moment";
import { Moment } from "moment";
import { Data } from "@angular/router";
import * as moment from "moment";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.scss"],
})
export class DashboardComponent implements OnInit {
  public usecaseName: string = "";
  public usecaseId: any = 0;
  public userInfo: object = {};
  public fromDate: Date;
  public toDate: Date;
  public fromDateExtraction: Date;
  public toDateExtraction: Date;
  public fromDateLive: Date;
  public toDateLive: Date;
  public fromDateExtractionLive: Date;
  public toDateExtractionLive: Date;
  public categoryIds: any[] = [];
  public attributeIds: any[] = [];
  public categoryIdsLive: any[] = [];
  public attributeIdsLive: any[] = [];
  public documentList: any[] = [];
  public documentListLive: any[] = [];
  public documentOneIds: any[] = [];
  public documentTwoIds: any[] = [];
  public documentOneIdsLive: any[] = [];
  public documentTwoIdsLive: any[] = [];
  public documentCounts: any[] = [];
  public documentCountLive: any[] = [];
  public categoryList: Array<any> = [];
  public totalCategoryAnnotations: number = 0;
  public bgColor: string = "#006ca8";
  public widthOfReviewAnnotation: string = "600px";
  public widthOfReviewAnnotationLive: string = "600px";
  public widthOfReviewAnnotationDocs: string = "600px";
  public totalClassification: number = 0;
  public totalExtraction: number = 0;
  public totalExtractionLive: number = 0;
  public attributeList: any[] = [];
  public annAndReviewAnnBody: any = {};
  public annAndReviewAnnBodyLive: any = {};
  public attrAnnAndReviewAnnBody: any = {};
  public attrAnnAndReviewAnnBodyLive: any = {};
  public usecaseType: string = "";
  public isLive: boolean = false;
  public isTraining: boolean = false;
  public isClassificationTrian: boolean = false;
  public isExtractionTrain: boolean = false;
  public isClassificationLive: boolean = false;
  public isExtractionLive: boolean = false;
  // public barChartPlugins = [pluginDataLabels];
  public barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      xAxes: [
        {
          barPercentage: 0.2,
          ticks: {
            fontColor: "black",
            callback: function (label, index, labels) {
              if (/\s/.test(label)) {
                return label.split(" ");
              } else {
                return label;
              }
            },
          },
          gridLines: {
            lineWidth: 0,
            zeroLineWidth: 1,
          },
        },
      ],
      yAxes: [
        {
          ticks: {
            fontColor: "black",
            min: 0,
            max: 100,

            // forces step size to be 5 units
            stepSize: 10, // <----- This prop sets the stepSize
          },
          gridLines: {
            lineWidth: 0,
            zeroLineWidth: 1,
          },
          // gridLines: {
          //   display:false
          // }
        },
      ],
    },
    plugins: {
      datalabels: {
        display: false,
        anchor: "end",
        align: "end",
      },
    },
    legend: {
      position: "bottom",
      display: false,
      labels: {
        fontSize: 10,
        usePointStyle: true,
      },
    },
  };
  public defaultAnnotationbarChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    scales: {
      xAxes: [
        {
          barPercentage: 0.2,
          ticks: {
            fontColor: "black",
            callback: function (label, index, labels) {
              if (/\s/.test(label)) {
                return label.split(" ");
              } else {
                return label;
              }
            },
          },
          gridLines: {
            lineWidth: 0,
            zeroLineWidth: 1,
          },
        },
      ],
      yAxes: [
        {
          ticks: {
            min: 0,
            max: 100,

            // forces step size to be 5 units
            stepSize: 10, // <----- This prop sets the stepSize
          },
          gridLines: {
            lineWidth: 0,
            zeroLineWidth: 1,
          },
        },
      ],
    },
    plugins: {
      datalabels: {
        display: false,
        anchor: "end",
        align: "end",
      },
    },
    legend: {
      position: "bottom",
      display: false,
      labels: {
        fontSize: 10,
        usePointStyle: true,
      },
    },
  };

  public barChartLiveOptions = {
    responsive: true,
    maintainAspectRatio: false,

    scales: {
      xAxes: [
        {
          barPercentage: 0.2,
          ticks: {
            min: 0,
            max: 100,

            // forces step size to be 5 units
            stepSize: 10, // <----- This prop sets the stepSize
          },
          gridLines: {
            lineWidth: 0,
            zeroLineWidth: 1,
          },
        },
      ],
      yAxes: [
        // {
        //   ticks: {
        //     min: 0,
        //     max: 100,

        //     // forces step size to be 5 units
        //     stepSize: 10 // <----- This prop sets the stepSize
        //   }
        // },
        {
          barPercentage: 0.2,
          stacked: false,
          gridLines: {
            lineWidth: 0,
            zeroLineWidth: 1,
          },
        },
      ],
    },

    plugins: {
      datalabels: {
        display: false,
        anchor: "end",
        align: "end",
      },
    },
    legend: {
      position: "bottom",
      display: false,
      labels: {
        fontSize: 10,
        usePointStyle: true,
      },
    },
  };
  public barChartType: ChartType = "horizontalBar";
  public deafaultbarChartType: ChartType = "bar";
  public chartColors: Array<any> = [
    {
      // first color
      backgroundColor: "#002060",
      borderColor: "#002060",
      pointBackgroundColor: "#002060",
      pointBorderColor: "#fff",
      pointHoverBackgroundColor: "#fff",
      pointHoverBorderColor: "#002060",
    },
    {
      // second color
      backgroundColor: "#c2ddd2",
      borderColor: "#c2ddd2",
      pointBackgroundColor: "#c2ddd2",
      pointBorderColor: "#fff",
      pointHoverBackgroundColor: "#fff",
      pointHoverBorderColor: "#c2ddd2",
    },
  ];
  public barChartLabels = [];
  public barChartLabelsDocsExtraction = [];
  public barChartLabelsDocsExtractionLive = [];
  public barChartLegend = true;
  public stackedbarChartDataExtraction: ChartDataSets[] = [
    { data: [], label: "Total Annotations" },
    { data: [], label: "Reviewed Annotations" },
  ];
  public stackedbarChartDataExtractionLive: ChartDataSets[] = [
    { data: [], label: "Total Annotations" },
    // { data: [], label: "Reviewed Annotations" },
  ];
  public stackedbarChartData: ChartDataSets[] = [
    { data: [], label: "Total Annotations", stack: "a" },
    { data: [], label: "Reviewed Annotations", stack: "a" },
  ];

  public plugin = ChartDataLabels;
  public pieChartOptions = {
    responsive: true,
    plugins: {
      datalabels: {
        formatter: (value, ctx) => {
          const label = ctx.chart.data.labels[ctx.dataIndex];
          return value;
        },
        color: "#fff",
      },
    },

    legend: {
      position: "bottom",
      display: false,
      labels: {
        fontSize: 10,
        usePointStyle: true,
      },
    },
  };

  public pieChartLabels = [];
  public pieChartData: number[] = [];
  public totalPieAnnotations: number = 0;
  public pieChartType: ChartType = "pie";
  public pieChartLegend = true;
  public backgroundColor = [
    "#002060",
    "#c2ddd2",
    "#6aac91",
    "#becd90",
    "#cc2568",
    "#2530cc",
    "#17d443",
    "#eaf207",
    "#fa0f02",
    "#edaf05",
    "#03fff7",
    "#32e6e0",
    "#eb09dc",
    "#f50505",
  ];
  public pieChartColors = [
    {
      backgroundColor: this.backgroundColor,
    },
  ];

  @ViewChild("picker1", { static: false }) fromInput: MatDatepicker<Moment>;
  @ViewChild("picker2", { static: false }) toInput: MatDatepicker<Moment>;
  @ViewChild(BaseChartDirective, { static: false }) chart: BaseChartDirective;
  @ViewChild("myChart", { static: false }) myChart: BaseChartDirective;

  constructor(
    private PdfserviceService: PdfserviceService,
    private dashboardService: DashboardService
  ) {
    this.PdfserviceService.annotation("Dashboard");
    this.isLive = this.isRoleExist(4);
    this.isTraining = this.isRoleExist(3);
  }
  /**
   * Intial load all methods
   */
  ngOnInit() {
    this.usecaseName = localStorage.getItem("useCaseName");
    // this.usecaseId = parseInt(localStorage.getItem("useCaseId"));
    this.usecaseId =
      localStorage.getItem("useCaseId") == null
        ? 1
        : parseInt(localStorage.getItem("useCaseId"));
    this.usecaseType = localStorage.getItem("useCaseType");
    this.userInfo = JSON.parse(localStorage.getItem("userinfo"))
      ? JSON.parse(localStorage.getItem("userinfo"))
      : {};
    this.getCategory();
    this.getAttributes();
    if (this.isTraining) {
      this.getDocumentList();
      this.getDocumentsCount();
      if (this.usecaseType == "both") {
        this.getAnnotationAndReviewAnnotation();
        this.getAttributeWiseAnnotations();
      } else if (this.usecaseType == "classic") {
        this.getAnnotationAndReviewAnnotation();
      } else {
        this.getAttributeWiseAnnotations();
      }
    } else if (this.isLive) {
      this.getDocumentListLive();
      this.getDocumentsCountLive();
      if (this.usecaseType == "both") {
        this.classificationPredictions();
        this.extractionPrediction();
      } else if (this.usecaseType == "classic") {
        this.classificationPredictions();
      } else {
        this.extractionPrediction();
      }
    }
  }

  // /**
  //  * Reset the filter
  //  */
  // reset = () => {
  //   this.fromDate = undefined;
  //   this.toDate = undefined;
  //   this.fromInput.select(undefined);
  //   this.toInput.select(undefined);
  //   this.documentOneIds = [];
  //   this.documentTwoIds = [];
  //   this.getDocumentList();
  //   this.getCategory();
  //   this.getDocumentsCount();
  //   this.getAnnotationAndReviewAnnotation();
  //   this.getDocumentWiseAnnotationDetails();

  //   //this.getDocumentWiseAnnotationFullDetails();
  // };
  // /**
  //  * find button for filter
  //  */
  // find = () => {
  //   this.getDocumentList();
  //   this.getCategory();
  //   this.getAttributes();
  //   this.getDocumentsCount();
  //   this.getAnnotationAndReviewAnnotation();
  //   this.getDocumentWiseAnnotationDetails();
  //   //this.getDocumentWiseAnnotationFullDetails();
  // };
  /**
   * Get Attribute List
   */

  getAttributes = () => {
    this.dashboardService.getAttributes(this.usecaseId).subscribe(
      (res: any) => {
        console.log(res);
        if (res.statusCode == 200) {
          this.attributeList = res.listAttributes;
        } else {
        }
      },
      (err: any) => {
        console.log(err);
      }
    );
  };

  /**
   * get categories list
   */
  getCategory = () => {
    this.dashboardService.getCategories(this.usecaseId).subscribe(
      (res: any) => {
        if (res.listCategories.length > 0) {
          this.categoryList = res.listCategories.map((s) => {
            return {
              ...s,
              id: s.categoryId,
              name: s.categoryName,
              predictionShortName: s.abbrevation,
              count: 0,
            };
          });
        }
      },
      (err) => {}
    );
  };
  /**
   * get documents list based on date - training
   */
  getDocumentList = () => {
    let fromDate = 0; //this.fromDate ? moment(this.fromDate).format("x") : 0;
    let toDate = 0; //this.toDate ? moment(this.toDate).format("x") : 0;
    this.dashboardService
      .getDocumentList(fromDate, toDate, this.usecaseId)
      .subscribe(
        (res: any) => {
          if (res.statusCode == 200) {
            this.documentList = res.documents;
            this.totalCategoryAnnotations = res.totalAnnotations;
          }
        },
        (err) => {}
      );
  };
  /**
   * get documents list based on date - live
   */
  getDocumentListLive = () => {
    let fromDate = 0;
    let toDate = 0;
    this.dashboardService
      .getDocumentListLive(fromDate, toDate, this.usecaseId)
      .subscribe(
        (res: any) => {
          console.log(res);
          if (res.statusCode == 200) {
            this.documentListLive = res.listOfDocs;
          }
        },
        (err) => {}
      );
  };

  /**
   * get documents count
   */
  getDocumentsCount = () => {
    let fromDate = 0; //this.fromDate ? moment(this.fromDate).format("x") : 0;
    let toDate = 0; //this.toDate ? moment(this.toDate).format("x") : 0;
    this.dashboardService
      .getDocumentsCount(this.usecaseId, fromDate, toDate)
      .subscribe(
        (res: any) => {
          if (res.statusCode == 200) {
            this.documentCounts = res.annotationCountDes;
          }
        },
        (err) => {}
      );
  };

  /**
   * get Documents Count Live
   */
  getDocumentsCountLive = () => {
    let fromDate = 0; //this.fromDate ? moment(this.fromDate).format("x") : 0;
    let toDate = 0; //this.toDate ? moment(this.toDate).format("x") : 0;
    this.dashboardService
      .getDocumentsCountLive(this.usecaseId, fromDate, toDate)
      .subscribe(
        (res: any) => {
          if (res.statusCode == 200) {
            this.documentCountLive = res.liveAnnotation;
          }
        },
        (err) => {}
      );
  };

  /**
   * getAnnotationAndReviewAnnotation
   */

  getAnnotationAndReviewAnnotation = () => {
    let body = {
      fromDate: this.fromDate ? moment(this.fromDate).format("x") : 0,
      toDate: this.toDate ? moment(this.toDate).format("x") : 0,
      usecaseId: this.usecaseId,
      documents: this.documentOneIds,
      categories:
        this.categoryIds.length > 0
          ? this.categoryIds
          : this.categoryList.map((x) => x.id),
    };
    if (
      this.annAndReviewAnnBody.fromDate != body.fromDate ||
      this.annAndReviewAnnBody.toDate != body.toDate ||
      this.annAndReviewAnnBody.documents.join(",") !=
        body.documents.join(",") ||
      this.annAndReviewAnnBody.categories.join(",") != body.categories.join(",")
    ) {
      this.annAndReviewAnnBody = body;
    } else {
      return "";
    }
    this.dashboardService.getAnnotationAndReviewAnnotation(body).subscribe(
      (res: any) => {
        if (res.statusCode == 200) {
          this.isClassificationTrian = res.categories.length > 0 ? true : false;
          this.totalClassification = res.totalAnnotations;
          this.stackedbarChartData[0].data = res.categories.map(
            (r) => r.totalCount
          );
          this.stackedbarChartData[1].data = res.categories.map(
            (r) => r.totalReviewCount
          );
          this.barChartLabels = res.categories.map((r) => r.categoryName);
          if (this.stackedbarChartData[0].data.length < 4) {
            let lengthDef = 5 - this.stackedbarChartData[0].data.length;
            for (var i = 0; i < lengthDef; i++) {
              this.stackedbarChartData[0].data.push(0);
              this.stackedbarChartData[1].data.push(0);
              this.barChartLabels.push("");
              if (lengthDef - 1 == i && this.isClassificationTrian) {
                this.widthOfReviewAnnotation =
                  this.stackedbarChartData[0].data.length * 100 + 100 + "px";
                this.totalCategoryAnnotations = res.totalAnnotations;
                this.chart.chart.update();
              }
            }
          } else {
            this.widthOfReviewAnnotation =
              res.categories.length * 100 + 100 + "px";
            this.totalCategoryAnnotations = res.totalAnnotations;
            if (this.isClassificationTrian) {
              this.chart.chart.update();
            }
          }
        }
      },
      (err) => {}
    );
  };
  /**
   * getDocumentWiseAnnotationDetails()
   */
  getDocumentWiseAnnotationDetails = () => {
    // let body = {
    //   fromDate: this.fromDate ? moment(this.fromDate).format("x") : 0,
    //   toDate: this.toDate ? moment(this.toDate).format("x") : 0,
    //   usecaseId: this.usecaseId,
    //   documentIds: this.documentOneIds,
    // };
    // this.dashboardService.getDocumentWiseAnnotationDetails(body).subscribe(
    //   (res: any) => {
    //     if (res.statusCode == 200) {
    //       this.barChartData[0].data = res.documents.map(
    //         (r) => r.totalAnnotations
    //       );
    //       this.barChartData[1].data = res.documents.map(
    //         (r) => r.reviewAnnotations
    //       );
    //       this.barChartLabelsDocs = res.documents.map((r) => {
    //         if (r.documentName.length <= 16) {
    //           return r.documentName;
    //         } else {
    //           return r.documentName.slice(0, 13) + "...";
    //         }
    //       });
    //       this.widthOfReviewAnnotationDocs = res.documents.length * 83 + 83;
    //       this.myChart.ngOnInit();
    //     }
    //   },
    //   (err) => { }
    // );
  };
  /**
   * getDocumentWiseAnnotationFullDetails
   */
  getDocumentWiseAnnotationFullDetails = () => {
    // let body = {
    //   fromDate: this.fromDate ? moment(this.fromDate).format("x") : 0,
    //   toDate: this.toDate ? moment(this.toDate).format("x") : 0,
    //   usecaseId: this.usecaseId,
    //   documentIds: this.documentTwoIds,
    // };
    // this.dashboardService.getDocumentWiseAnnotationFullDetails(body).subscribe(
    //   (res: any) => {
    //     this.pieChartData = [];
    //     if (res.statusCode == 200) {
    //       this.pieChartData.push(res.pieChart.reviewCount);
    //       this.pieChartData.push(res.pieChart.deletedCount);
    //       this.pieChartData.push(res.pieChart.reAssignedCount);
    //       this.pieChartData.push(res.pieChart.pendingCount);
    //       this.totalPieAnnotations = res.pieChart.totalAnnotations;
    //     }
    //   },
    //   (err) => { }
    // );
  };

  getAttributeWiseAnnotations = () => {
    let body = {
      usecaseId: this.usecaseId,
      fromDate: this.fromDateExtraction
        ? moment(this.fromDateExtraction).format("x")
        : 0,
      toDate: this.toDateExtraction
        ? moment(this.toDateExtraction).format("x")
        : 0,
      documentIds: this.documentTwoIds,
      attributeId: this.attributeIds,
    };

    if (
      this.attrAnnAndReviewAnnBody.fromDate != body.fromDate ||
      this.attrAnnAndReviewAnnBody.toDate != body.toDate ||
      this.attrAnnAndReviewAnnBody.documentIds.join(",") !=
        body.documentIds.join(",") ||
      this.attrAnnAndReviewAnnBody.attributeId.join(",") !=
        body.attributeId.join(",")
    ) {
      this.attrAnnAndReviewAnnBody = body;
    } else {
      return "";
    }

    this.dashboardService.getAttributeWiseAnnotation(body).subscribe(
      (res: any) => {
        if (res.statusCode == 200) {
          this.totalExtraction = res.total;
          this.isExtractionTrain = res.attributeList.length > 0 ? true : false;
          this.stackedbarChartDataExtraction[0].data = res.attributeList.map(
            (r) => r.totalCount
          );
          this.stackedbarChartDataExtraction[1].data = res.attributeList.map(
            (r) => r.totalReviewCount
          );
          this.barChartLabelsDocsExtraction = res.attributeList.map(
            (r) => r.attributeName
          );
          console.log(this.stackedbarChartDataExtraction[0].data);
          if (this.stackedbarChartDataExtraction[0].data.length < 5) {
            let lengthDef =
              5 - this.stackedbarChartDataExtraction[0].data.length;
            for (var i = 0; i < lengthDef; i++) {
              console.log(i);
              this.stackedbarChartDataExtraction[0].data.push(0);
              this.stackedbarChartDataExtraction[1].data.push(0);
              this.barChartLabelsDocsExtraction.push("");
              if (lengthDef - 1 == i && this.isExtractionTrain == true) {
                this.widthOfReviewAnnotationDocs =
                  this.stackedbarChartDataExtraction[0].data.length * 100 +
                  100 +
                  "px";
                // this.totalCategoryAnnotations = res.totalAnnotations;
                console.log("asdfasdfsadfasd");
                this.chart.chart.update();
              }
            }
          } else {
            this.widthOfReviewAnnotationDocs =
              this.stackedbarChartDataExtraction[0].data.length * 100 +
              100 +
              "px";
            // this.totalCategoryAnnotations = res.totalAnnotations;
            if (this.isExtractionTrain == true) {
              this.chart.chart.update();
            }
          }
          //  this.widthOfReviewAnnotationDocs =
          //    res.attributeList.length * 100 +"px";
          // this.chart.chart.update();
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  };

  changeExtraction(event: any) {
    this.getAttributeWiseAnnotations();
  }

  /**
   * live clasification
   */

  classificationPredictions = () => {
    let body = {
      fromDate: this.fromDateLive ? moment(this.fromDateLive).format("x") : 0,
      toDate: this.toDateLive ? moment(this.toDateLive).format("x") : 0,
      usecaseId: this.usecaseId,
      documents: this.documentOneIdsLive,
      categories:
        this.categoryIdsLive.length > 0
          ? this.categoryIdsLive
          : this.categoryList.map((x) => x.id),
    };
    if (
      this.annAndReviewAnnBodyLive.fromDate != body.fromDate ||
      this.annAndReviewAnnBodyLive.toDate != body.toDate ||
      this.annAndReviewAnnBodyLive.documents.join(",") !=
        body.documents.join(",") ||
      this.annAndReviewAnnBodyLive.categories.join(",") !=
        body.categories.join(",")
    ) {
      this.annAndReviewAnnBodyLive = body;
    } else {
      return "";
    }
    this.dashboardService.getAnnotationAndReviewAnnotationLive(body).subscribe(
      (res: any) => {
        if (res.statusCode == 200) {
          this.isClassificationLive = res.categories.length > 0 ? true : false;
          this.totalPieAnnotations = res.totalAnnotations;
          this.pieChartData = res.categories.map((r) => r.totalCount);

          this.pieChartLabels = res.categories.map((r) => r.categoryName);

          // this.widthOfReviewAnnotation = res.categories.length * 83 + 83 + "px";
          // this.totalCategoryAnnotations = res.totalAnnotations;
          if (this.isClassificationLive) {
            this.chart.chart.update();
          }
        }
      },
      (err) => {}
    );
  };

  extractionPrediction = () => {
    let body = {
      usecaseId: this.usecaseId,
      fromDate: this.fromDateExtractionLive
        ? moment(this.fromDateExtractionLive).format("x")
        : 0,
      toDate: this.toDateExtractionLive
        ? moment(this.toDateExtractionLive).format("x")
        : 0,
      documentIds: this.documentTwoIdsLive,
      attributeId: this.attributeIdsLive,
    };

    if (
      this.attrAnnAndReviewAnnBodyLive.fromDate != body.fromDate ||
      this.attrAnnAndReviewAnnBodyLive.toDate != body.toDate ||
      this.attrAnnAndReviewAnnBodyLive.documentIds.join(",") !=
        body.documentIds.join(",") ||
      this.attrAnnAndReviewAnnBodyLive.attributeId.join(",") !=
        body.attributeId.join(",")
    ) {
      this.attrAnnAndReviewAnnBodyLive = body;
    } else {
      return "";
    }

    this.dashboardService.getAttributeWiseAnnotationLive(body).subscribe(
      (res: any) => {
        if (res.statusCode == 200) {
          this.totalExtractionLive = res.total;
          this.isExtractionLive = res.attributeList.length > 0 ? true : false;
          this.stackedbarChartDataExtractionLive[0].data = res.attributeList.map(
            (r) => r.totalCount
          );
          // this.stackedbarChartDataExtractionLive[1].data = res.attributeList.map(
          //   (r) => r.totalReviewCount
          // );
          this.barChartLabelsDocsExtractionLive = res.attributeList.map(
            (r) => r.attributeName
          );
          this.widthOfReviewAnnotationLive =
            res.attributeList.length * 100 + 100 + "px";
          if (this.isExtractionLive) {
            this.chart.chart.update();
          }
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  };

  isRoleExist = (roleId) => {
    // 3 - train, 4 - live
    let userInfo = JSON.parse(localStorage.getItem("userinfo"));
    let roleid = localStorage.getItem("roleID");
    let roleList = userInfo.roles;
    return roleList.find((x) => x.roleID === roleId) != undefined &&
      roleid == roleId
      ? true
      : false;
  };
}
