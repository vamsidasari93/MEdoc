import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { DashboardComponent } from "./dashboard.component";
import { Routes, RouterModule } from "@angular/router";
import { MatCardModule } from "@angular/material/card";
import { FlexLayoutModule } from "@angular/flex-layout";
import { ChartsModule, ThemeService } from "ng2-charts";
import { InsightCardComponent } from "./insight-card/insight-card.component";
import {
  MatButtonModule,
  MatDatepickerModule,
  MatFormFieldModule,
  MatInputModule,
  MatNativeDateModule,
  MatSelectModule,
} from "@angular/material";
import { FormsModule } from "@angular/forms";

const routes: Routes = [
  {
    path: "",
    component: DashboardComponent,
  },
];

@NgModule({
  declarations: [DashboardComponent, InsightCardComponent],
  imports: [
    CommonModule,
    MatCardModule,
    FlexLayoutModule,
    ChartsModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    FormsModule,
    RouterModule.forChild(routes),
  ],
  providers: [ThemeService],
})
export class DashboardModule {}
