import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AuthGuard } from "./_helpers";
// import { Role } from "./_models";

const routes: Routes = [
  {
    path: "dashboard",
    loadChildren: () =>
      import("./dashboard/dashboard.module").then((m) => m.DashboardModule),
    canActivate: [AuthGuard],
  },
  {
    path: "Documentslist",
    loadChildren: () =>
      import("./SharedComponents/shared.module").then((m) => m.SharedModule),
    canActivate: [AuthGuard],
  },
  {
    path: "Admin",
    loadChildren: () =>
      import("./admin/admin.module").then((m) => m.AdminModule),
    canActivate: [AuthGuard],
  },
  {
    path: "datascience",
    loadChildren: () =>
      import("./datascience/datascience.module").then(
        (m) => m.DatascienceModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: "workspace",
    loadChildren: () =>
      import("./datascience/datascience.module").then(
        (m) => m.DatascienceModule
      ),
    canActivate: [AuthGuard],
  },
  {
    path: "login",
    loadChildren: () =>
      import("./login/login.module").then((m) => m.LoginModule),
  },
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full",
  },
  { path: "**", redirectTo: "login" },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
