import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { DocInsPdfComponent } from "./doc-ins-pdf.component";
import { PdfJsViewerModule } from "ng2-pdfjs-viewer";
import { MatGridListModule } from "@angular/material/grid-list";
import { MatTableModule } from "@angular/material/table";
import { FlexLayoutModule } from "@angular/flex-layout";
import { Routes, RouterModule } from "@angular/router";
import { HttpClientModule } from "@angular/common/http";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { MatInputModule } from "@angular/material/input";
import { MatFormFieldModule } from "@angular/material/form-field";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatIconModule } from "@angular/material/icon";
import { MatExpansionModule } from "@angular/material/expansion";
import { MatSidenavModule } from "@angular/material/sidenav";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatTabsModule } from "@angular/material/tabs";
import { MatDialogModule } from "@angular/material/dialog";
import { MatCardModule } from "@angular/material/card";
import { MatAutocompleteModule, MatTooltipModule } from "@angular/material";
import { reviewModule } from "./review-annotation/review.module";
import { NgxSpinnerModule, NgxSpinnerService } from "ngx-spinner";
import { OrderModule } from "ngx-order-pipe";
import { SearchpipemoduleModule } from "src/app/pipe/searchpipemodule/searchpipemodule.module";
import { EditreviewDialogComponent } from "./review-annotation/editreview-dialog/editreview-dialog.component";
import { SilderComponentComponent } from "./silder-component/silder-component.component";
import { NgxSliderModule } from "@angular-slider/ngx-slider";
import { DashboardAuthGuard } from "src/app/_helpers";
import { DebounceModule } from "ngx-debounce";
import { DocInfoHelpPopupComponent } from "./doc-info-help-popup/doc-info-help-popup.component";

const routes: Routes = [
  {
    path: "",
    component: DocInsPdfComponent,
    canActivate: [DashboardAuthGuard],
  },
];

@NgModule({
  declarations: [
    DocInsPdfComponent,
    SilderComponentComponent,
    DocInfoHelpPopupComponent,
  ],
  entryComponents: [SilderComponentComponent, DocInfoHelpPopupComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    PdfJsViewerModule,
    MatGridListModule,
    MatTableModule,
    FlexLayoutModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    MatInputModule,
    MatFormFieldModule,
    FormsModule,
    MatIconModule,
    MatExpansionModule,
    MatSidenavModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatTabsModule,
    MatDialogModule,
    MatCardModule,
    MatAutocompleteModule,
    ReactiveFormsModule,
    reviewModule,
    NgxSpinnerModule,
    OrderModule,
    SearchpipemoduleModule,
    NgxSliderModule,
    MatTooltipModule,
    DebounceModule,
  ],
  providers: [NgxSpinnerService, EditreviewDialogComponent],
  exports: [SilderComponentComponent],
})
export class DocPDfModule {}
