import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: 'app-doc-info-help-popup',
  templateUrl: './doc-info-help-popup.component.html',
  styleUrls: ['./doc-info-help-popup.component.scss']
})
export class DocInfoHelpPopupComponent implements OnInit {

  infoType: any;

  constructor(
    public dialogRef: MatDialogRef<DocInfoHelpPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.infoType = data.type;
  }
  ngOnInit() {}
}
