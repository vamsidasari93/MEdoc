import {
  Component,
  Inject,
  OnInit,
  Optional,
  ElementRef,
  EventEmitter,
  Output,
} from "@angular/core";
import { Options } from "@angular-slider/ngx-slider";
import { PdfserviceService } from "src/app/Services/pdfservice.service";

@Component({
  selector: "app-silder-component",
  templateUrl: "./silder-component.component.html",
  styleUrls: ["./silder-component.component.scss"],
  host: {
    "(document:click)": "onClick($event)",
  },
})
export class SilderComponentComponent implements OnInit {
  value: number = 0;
  slidopt: Options = {
    floor: 0,
    ceil: 100,
    step: 25,
    showTicksValues: true,
    vertical: true,
    translate: (value: any): string => {
      return value + "%";
    },
  };
  @Output()
  closeEvent = new EventEmitter<string>();
  constructor(
    public PdfserviceService: PdfserviceService,
    private _eref: ElementRef
  ) {}

  ngOnInit() {
    this.value = parseInt(localStorage.getItem("confidencescore"));
  }
  confidenceScore(e) {
    console.log("e", e);
    this.PdfserviceService.conndensedScore(e);
    localStorage.setItem("confidencescore", e);
  }

  onClick(event) {
    if (!this._eref.nativeElement.contains(event.target))
      // or some similar check
      this.doSomething();
  }
  doSomething() {
    this.closeEvent.emit("close");
  }
}
