import { Component, Input, OnChanges, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { Output, EventEmitter } from "@angular/core";
import { EditreviewDialogComponent } from "./editreview-dialog/editreview-dialog.component";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { SimpleChanges } from "@angular/core";
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from "@angular/material";
import { EditExtractionComponent } from "./edit-extraction/edit-extraction.component";

@Component({
  selector: "app-review-annotation",
  templateUrl: "./review-annotation.component.html",
  styleUrls: ["./review-annotation.component.scss"],
})
export class ReviewAnnotationComponent implements OnInit, OnChanges {
  searchSegment: any;
  id: any;
  icon: boolean = false;
  allComplete: boolean = false;
  clasuesObject = [];
  pageCoordinates: any;
  segementCount: any;
  segments: any;
  categories = [];
  extractionList = [];
  allupdatedata = [];
  allchecked = [];
  checkboxchecked: any;
  listcheckboxchecked: any;
  apiResponse: any;
  show = false;
  public allSelected: boolean = false;
  public indeterminate: boolean = false;
  @Input() TotalcategoryCount: number;
  @Input() TotalextractionCount: number;
  @Input() item: string;
  @Input() extractionitem: string;
  @Input() documentId: string;
  @Input() totalCount: number;
  @Input() spaceholder: string;
  @Output() Navpages = new EventEmitter();

  horizontalPosition: MatSnackBarHorizontalPosition = "right";
  verticalPosition: MatSnackBarVerticalPosition = "bottom";
  getlabelname: any;
  isallchecked: any[] = [];
  totalCheckbox: any;
  useCaseType: string;
  constructor(
    public dialog: MatDialog,
    private PdffilesService: PdffilesService,
    private PdfserviceService: PdfserviceService,
    private _snackBar: MatSnackBar
  ) {
    this.PdfserviceService.reviewannatation$.subscribe((response) => {
      this.openSnackBar(response);
    });
  }

  ngOnInit() {
    this.popupdata();
    console.log("catogies", this.item);
    console.log("Extraction", this.extractionitem);
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("added them", this.item);
    this.useCaseType = localStorage.getItem("useCaseType");
    if (this.useCaseType == "extraction") {
      this.segments = [...this.extractionitem];
    } else if (this.useCaseType == "classic") {
      this.segments = [...this.item];
    } else {
      this.segments = [...this.item, ...this.extractionitem];
    }
    this.flagCountdata();
  }
  popupdata() {
    this.checkboxchecked = this.segments[0];
    for (let i = 0; i < this.segments.length; i++) {
      if (!this.segments[i].isExtraction) {
        var obj = {
          categoriesname: this.segments[i].categoryName,
          categoriesId: this.segments[i].categoryId,
        };
        this.categories.push(obj);
      }
    }
  }

  openDialog(clasuses, card, i, type): void {
    if (card.isFlagConfirmed === "Y") {
      return;
    }
    if (type === "editpopup") {
      this.dialog
        .open(EditreviewDialogComponent, {
          backdropClass: "popupBackdropClass",
          position: { top: "15%" },
          data: {
            documentId: this.documentId,
            name: clasuses.categoryName,
            labelId: clasuses.categoryId,
            segmentid: card.segmentId,
            pageindex: i,
            pageNo: card.pageNo,
            edit: "editpopup",
            segmenttext: card.segmentTextURL,
          },
          panelClass: "custom-dialog-container",
        })
        .afterClosed()
        .subscribe((result) => {
          console.log("The dialog was closed");
        });
    } else if (type === "reassignpopup") {
      this.dialog
        .open(EditreviewDialogComponent, {
          backdropClass: "popupBackdropClass",
          position: { top: "15%" },
          data: {
            name: this.categories,
            clasuse: clasuses,
            documentId: this.documentId,
            segmentid: card.segmentId,
            pageNo: card.pageNo,
            pageindex: i,
            reassign: type,
            segmenttext: card.segmentTextURL,
          },
          panelClass: "custom-dialog-container-w-40",
        })
        .afterClosed()
        .subscribe((result) => {
          console.log("The dialog was closed");
        });
    }
  }

  openExtraction(clasuses, card, type, category): void {
    console.log("actions", clasuses, card, type, category);
    if (card.isFlagConfirmed === "Y") {
      return;
    }
    if (type === "edit") {
      this.dialog
        .open(EditExtractionComponent, {
          backdropClass: "popupBackdropClass",
          position: { top: "15%" },
          data: {
            category: category,
            docId: this.documentId,
            pageNo: category == "inside" ? clasuses.pageNo : card.pageNo,
            methodType: "UPDATE",
            segmentId:
              category == "inside" ? clasuses.segmentId : card.segmentId,
            type: type,
            name: category == "inside" ? clasuses.labelName : card.label,
            attribute: {
              id: category == "inside" ? card.id : card.attributeId,
              attributeText: card.attributeText,
              attributeLabel:
                category == "inside" ? card.attributeLabel : card.label,
              attributeLabelId: card.labelId,
              attributeCoordinates: card.attributeCoordinates,
              attributeCode: clasuses.abbrevation,
            },
          },
          panelClass: "custom-dialog-container",
        })
        .afterClosed()
        .subscribe((result) => {
          console.log("The dialog was closed");
        });
    } else if (type === "reassign") {
      this.dialog
        .open(EditExtractionComponent, {
          backdropClass: "popupBackdropClass",
          position: { top: "15%" },
          data: {
            category: category,
            docId: this.documentId,
            pageNo: category == "inside" ? clasuses.pageNo : card.pageNo,
            methodType: "UPDATE",
            segmentId:
              category == "inside" ? clasuses.segmentId : card.segmentId,
            type: type,
            name: category == "inside" ? clasuses.labelName : card.label,
            attribute: {
              id: category == "inside" ? card.id : card.attributeId,
              attributeText: card.attributeText,
              attributeLabel:
                category == "inside" ? card.attributeLabel : card.label,
              attributeLabelId: card.labelId,
              attributeCoordinates: card.attributeCoordinates,
              attributeCode: clasuses.abbrevation,
            },
          },
          panelClass: "custom-dialog-container-w-40",
          // panelClass: "custom-dialog-container-w-resassign-40",
        })
        .afterClosed()
        .subscribe((result) => {
          console.log("The dialog was closed");
        });
    } else {
      this.dialog
        .open(EditExtractionComponent, {
          backdropClass: "popupBackdropClass",
          position: { top: "15%" },
          panelClass: "custom-dialog-container-deletepopup",
          data: {
            category: category,
            docId: this.documentId,
            pageNo: category == "inside" ? clasuses.pageNo : card.pageNo,
            methodType: "DELETE",
            segmentId:
              category == "inside" ? clasuses.segmentId : card.segmentId,
            type: type,
            name: category == "inside" ? clasuses.labelName : card.label,
            attribute: {
              id: category == "inside" ? card.id : card.attributeId,
              attributeText: card.attributeText,
              attributeLabel:
                category == "inside" ? card.attributeLabel : card.label,
              attributeLabelId: card.labelId,
              attributeCoordinates: card.attributeCoordinates,
              attributeCode: clasuses.abbrevation,
            },
          },
        })
        .afterClosed()
        .subscribe((result) => {
          console.log("The dialog was closed");
        });
    }
  }
  click() {
    this.icon = !this.icon;
  }

  goToPage(desiredPage, coordnates) {
    var pages = desiredPage;
    var obj = {
      pages: desiredPage,
      coords: coordnates,
    };
    this.Navpages.emit(obj);
  }
  flagCountdata() {
    this.isallchecked = [];
    this.segments.map((each) => {
      // if (!each.isExtraction) {
      each.segment = each.segment == 0 ? [] : each.segment;
      let totalflagcounts = each.segment.filter(
        (obj) => obj.isFlagConfirmed === "Y"
      ).length;
      each.totalflagcounts = totalflagcounts;
      this.isallchecked.push(totalflagcounts);
      return each;
      // }
    });
    const reducer = (accumulator, currentValue) => accumulator + currentValue;
    this.totalCheckbox = this.isallchecked.reduce(reducer);

    console.log(this.totalCheckbox);
  }
  itemChanged(card, item, event, id, index, pageno, labelname, labelId, j) {
    this.getlabelname = card.labelName;
    let cIndex = 0;
    var labelName = card.labelName ? card.labelName : card.label;
    if (item.attributeId) {
      this.segments.forEach(function (x, index) {
        if (x.attributeId === item.attributeId) {
          cIndex = index;
        }
      });
      this.segments[cIndex].segment[index].isFlagConfirmed =
        this.segments[cIndex].segment[index].isFlagConfirmed == "Y" ? "N" : "Y";
    } else {
      this.segments.forEach(function (x, index) {
        if (x.categoryId === item.categoryId) {
          cIndex = index;
        }
      });
      this.segments[cIndex].segment[index].isFlagConfirmed =
        this.segments[cIndex].segment[index].isFlagConfirmed == "Y" ? "N" : "Y";
    }

    this.flagCountdata();
    item.segment[index].completed = event.checked;
    const sampleArray = [];
    item.segment.map((each) => {
      if (each.completed === true) {
        sampleArray.push(each);
        if (sampleArray.length === item.segment.length) {
          this.toggleSelectAll(true, item, j);
          // this.allComplete = true;
        }
      }
    });
    if (item.isExtraction == false) {
      if (item.segment[index].completed === true) {
        var obj = {
          documentId: this.documentId,
          pageNo: pageno,
          segmentId: id,
          isUserConfirmed: "Y",
        };
        var updatedata = obj;
        this.allupdatedata.push(obj);
      } else if (item.segment[index].completed === false) {
        var obj = {
          documentId: this.documentId,
          pageNo: pageno,
          segmentId: id,
          isUserConfirmed: "N",
        };
        var updatedata = obj;
        this.allupdatedata.push(obj);
      }
      this.updateSegmentData(
        this.allupdatedata,
        labelName,
        item.isExtraction,
        "single"
      );
    } else {
      this.extractionSingleCheck(card, item, labelName, index, pageno);
    }
  }
  toggleSelectAll(event, eachitem, j) {
    let cIndex = 0;
    if (eachitem.attributeId) {
      this.segments.forEach(function (x, index) {
        if (x.attributeId && x.attributeId === eachitem.attributeId) {
          cIndex = index;
        }
      });
      this.segments[cIndex].segment.map((obj) => {
        obj.isFlagConfirmed = event ? "Y" : "N";
        return obj;
      });
    } else {
      this.segments.forEach(function (x, index) {
        if (x.categoryId === eachitem.categoryId) {
          cIndex = index;
        }
      });
      this.segments[cIndex].segment.map((obj) => {
        obj.isFlagConfirmed = event ? "Y" : "N";
        return obj;
      });
    }
    // this.segments[j].segment.map((obj) => {
    //   obj.isFlagConfirmed = event ? "Y" : "N";
    //   return obj;
    // });
    let labelName = "";
    eachitem.completed = event;
    eachitem.segment.map((eachsegmentItem) => {
      eachsegmentItem.completed = event;
      // this.itemChanged(eachitem, event, id, index, pageno, labelname, labelId);
      if (eachitem.isExtraction) {
        labelName = eachitem.attributeName;
        if (eachitem.completed === true) {
          var obj1 = {
            docId: this.documentId,
            pageNo: eachsegmentItem.pageNo,
            segmentId: 0,
            attributeId: eachsegmentItem.attributeId,
            isUserConfirmed: true,
          };
          this.allchecked.push(obj1);
          // return eachsegmentItem;
        }
        if (eachitem.completed === false) {
          var obj1 = {
            docId: this.documentId,
            pageNo: eachsegmentItem.pageNo,
            segmentId: 0,
            attributeId: eachsegmentItem.attributeId,
            isUserConfirmed: true,
          };
          this.allchecked.push(obj1);
          // return eachsegmentItem;
        }
      } else {
        labelName = eachitem.categoryName;
        if (eachitem.completed === true) {
          var obj = {
            documentId: this.documentId,
            pageNo: eachsegmentItem.pageNo,
            segmentId: eachsegmentItem.segmentId,
            isUserConfirmed: "Y",
          };
          this.allchecked.push(obj);
          // return eachsegmentItem;
        }
        if (eachitem.completed === false) {
          var obj = {
            documentId: this.documentId,
            pageNo: eachsegmentItem.pageNo,
            segmentId: eachsegmentItem.segmentId,
            isUserConfirmed: "N",
          };
          this.allchecked.push(obj);
          // return eachsegmentItem;
        }
      }
    });
    this.updateSegmentData(
      this.allchecked,
      labelName,
      eachitem.isExtraction,
      "multiple"
    );
    this.flagCountdata();
  }
  togglesdisabled(segments) {
    if (segments.length === 0 || segments.count === 0) {
      return false;
    }
    let count = segments.length;
    segments.forEach((item) => {
      if (item.attributeList == undefined || item.attributeList.length == 0) {
        item["isAttribute"] = true;
      } else {
        let attrCount = 0;
        item.attributeList.forEach((key) => {
          if (key.isUserConfirmed) {
            attrCount += 1;
          }
        });
        if (item.attributeList.length == attrCount) {
          item["isAttribute"] = true;
        } else {
          item["isAttribute"] = false;
        }
      }
    });
    let selectedAttrCount = segments.filter((obj) => obj.isAttribute === true)
      .length;
    let selectedcount = segments.filter((obj) => obj.isFlagConfirmed === "Y")
      .length;
    return count === selectedcount && count === selectedAttrCount;
  }
  extractionSingleCheck(card, item, labelName, index, pageno) {
    if (item.segment[index].completed === true) {
      var obj1 = {
        docId: this.documentId,
        pageNo: pageno,
        segmentId: 0,
        attributeId: card.attributeId,
        isUserConfirmed: true,
      };
      // var updatedata = obj1;
      this.allupdatedata.push(obj1);
      console.log(this.allupdatedata);
    } else if (item.segment[index].completed === false) {
      var obj1 = {
        docId: this.documentId,
        pageNo: pageno,
        segmentId: 0,
        attributeId: card.attributeId,
        isUserConfirmed: false,
      };
      // var updatedata = obj;
      this.allupdatedata.push(obj1);
    }
    this.updateSegmentData(
      this.allupdatedata,
      labelName,
      item.isExtraction,
      "single"
    );
  }
  updateSegmentData(allchecked: any, eachlabelName, isExtraction, type) {
    if (isExtraction) {
      this.PdffilesService.UpdateAttributeConfirmation(allchecked).subscribe(
        (response: any) => {
          var res = JSON.parse(response);
          console.log(res.statusMsg);
          if (res.statusMsg === "Success") {
            var mofifedresponse;
            if (type === "multiple") {
              mofifedresponse = eachlabelName + " " + "reviewed successfully";
            } else {
              mofifedresponse = " Entity reviewed successfully";
            }
            this.openSnackBar(mofifedresponse);
            if (
              this.totalCheckbox ===
              this.TotalcategoryCount + this.TotalextractionCount
            ) {
              var reviewddoc = "Document reviewed successfully";
              setTimeout(() => {
                this.openSnackBar(reviewddoc);
              }, 6000);
            }
          }
          // console.log(this.totalCheckbox, this.TotalcategoryCount);
          this.allchecked = [];
          this.allupdatedata = [];
        }
      );
      // if (
      //   this.totalCheckbox ===
      //   this.TotalcategoryCount + this.TotalextractionCount
      // ) {
      //   var reviewddoc = "Document reviewed successfully";
      //   setTimeout(() => {
      //     this.openSnackBar(reviewddoc);
      //   }, 5100);
      // }
    } else {
      this.PdffilesService.updateUserConformation(allchecked).subscribe(
        (response: any) => {
          if (
            response === "Data updated Successfully" ||
            response === "Update Successfully."
          ) {
            var mofifedresponse;
            if (type === "multiple") {
              mofifedresponse = eachlabelName + " " + "reviewed successfully";
            } else {
              mofifedresponse = "Segment reviewed successfully";
            }

            this.openSnackBar(mofifedresponse);
            if (
              this.totalCheckbox ===
              this.TotalcategoryCount + this.TotalextractionCount
            ) {
              var reviewddoc = "Document reviewed successfully";
              setTimeout(() => {
                this.openSnackBar(reviewddoc);
              }, 6000);
            }
          }
          this.allchecked = [];
          this.allupdatedata = [];
        }
      );

      // if (
      //   this.totalCheckbox ===
      //   this.TotalcategoryCount + this.TotalextractionCount
      // ) {
      //   var reviewddoc = "Document reviewed successfully";
      //   setTimeout(() => {
      //     this.openSnackBar(reviewddoc);
      //   }, 5100);
      // }
    }
  }

  selectClassificationExtraction(flag, segment, item, index) {
    let classificationExtractionParam = [
      {
        docId: this.documentId,
        pageNo: segment.pageNo,
        segmentId: segment.segmentId,
        attributeId: item.id,
        isUserConfirmed: flag,
      },
    ];
    this.PdffilesService.UpdateAttributeConfirmation(
      classificationExtractionParam
    ).subscribe((response: any) => {
      if (response === "Update Successfully.") {
        var mofifedresponse =
          item.attributeLabel + " " + " reviewed successfully";
        this.openSnackBar(mofifedresponse);
      }

      if (response === "Data updated Successfully") {
      }
      if (
        this.totalCheckbox ===
        this.TotalcategoryCount + this.TotalextractionCount
      ) {
        var reviewddoc = "Document reviewed successfully";
        setTimeout(() => {
          this.openSnackBar(reviewddoc);
        }, 6000);
      }
    });
  }

  segmentDelete(clasues, card, i, type) {
    if (card.isFlagConfirmed === "Y") {
      return;
    }
    var deletedata = [];
    var obj = {
      documentId: this.documentId,
      pageNo: parseInt(card.pageNo),
      segementId: card.segmentId,
      labelId: clasues.categoryId,
      labelName: clasues.categoryName,
      segementText: card.segmentTextURL,
      actionType: "Delete",
    };
    deletedata.push(obj);
    if (type === "deletepopup") {
      const dialogRef = this.dialog.open(EditreviewDialogComponent, {
        // width: "350px",
        backdropClass: "popupBackdropClass",
        position: { top: "15%" },
        data: { delete: "deletepopup" },
        panelClass: "custom-dialog-container-deletepopup",
      });
      dialogRef.afterClosed().subscribe((result) => {
        console.log(result);
        if (result.data === "confirmed") {
          this.PdffilesService.UpdateReassignvalue(obj).subscribe(
            (response) => {
              console.log("res", response);
              this.apiResponse = response;
              if (this.apiResponse) {
                this.show = true;
                var data = {
                  pageNo: parseInt(card.pageNo),
                  segementId: card.segmentId,
                  response: response,
                };
                this.PdfserviceService.reviewannatation(data);
              }
            }
          );
        }
      });
    }
  }
  closeresponse() {
    this.show = false;
  }
  openSnackBar(message) {
    console.log(message);
    message = message.charAt(0).toUpperCase() + message.slice(1);
    if (message.response) {
      this._snackBar.open(message.response, "", {
        duration: 3000,
        panelClass: ["snackBar"],
        // horizontalPosition: this.horizontalPosition,
        // verticalPosition: this.verticalPosition,
      });
    } else {
      this._snackBar.open(message, "", {
        duration: 3000,
        panelClass: ["snackBar"],
        // horizontalPosition: this.horizontalPosition,
        // verticalPosition: this.verticalPosition,
      });
    }
  }
  keyPressAlphaNumeric(event) {
    var inp = String.fromCharCode(event.keyCode);
    if (/[a-zA-Z0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
}
