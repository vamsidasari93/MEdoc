import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";

@Component({
  selector: "app-edit-extraction",
  templateUrl: "./edit-extraction.component.html",
  styleUrls: ["./edit-extraction.component.scss"],
})
export class EditExtractionComponent implements OnInit {
  selected = -1;
  attributeName: any;
  searchSegment: any;
  showdialog: boolean;
  reassigndialog: boolean;
  deleteconfirm: boolean;
  afterchangeSegmenttext: any;
  itemchecked: any;
  checkedvalue: number;
  show = false;
  apiResponse: any;
  extractionList = [];
  attributeid: any;
  constructor(
    private PdffilesService: PdffilesService,
    private PdfserviceService: PdfserviceService,
    public dialogRef: MatDialogRef<EditExtractionComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    console.log("dataaa review", this.data);
    this.attributeName = this.data.name;
    this.attributeid = this.data.attribute.attributeLabelId;

    this.dialogshow();
  }

  getExtraction() {
    let UseCaseId = localStorage.getItem("useCaseId");
    this.PdffilesService.getAttributes(UseCaseId).subscribe((data: any) => {
      this.extractionList = data.listAttributes;
      console.log(this.extractionList);
    });
  }
  segmenttextChange(val) {
    this.afterchangeSegmenttext = val.replace(/&nbsp;/g, " ");
  }
  onSave() {
    if (this.afterchangeSegmenttext) {
      this.data.attribute.attributeText = this.afterchangeSegmenttext;
      var obj = {
        docId: this.data.docId,
        pageNo: this.data.pageNo,
        methodType: this.data.methodType,
        segmentId: this.data.segmentId,
        attribute: {
          id: this.data.attribute.id,
          attributeText: this.data.attribute.attributeText,
          attributeLabel: this.data.attribute.attributeLabel,
          attributeLabelId: this.data.attribute.attributeLabelId,
          attributeCoordinates: this.data.attribute.attributeCoordinates,
          attributeCode: this.data.attribute.attributeCode,
        },
      };

      if (this.data.category == "inside") {
        this.PdffilesService.updateAttribute(
          obj,
          this.data.attribute.id
        ).subscribe((resp: any) => {
          let response = JSON.parse(resp);
          this.apiResponse = response.statusMessage;
          if (response.statusCode == 200) {
            var reassignres = "Entity updated Successfully";
            this.PdfserviceService.annatationCount(reassignres);
            this.dialogRef.close();
          }
        });
      } else if (this.data.category == "outside") {
        this.PdffilesService.updateExtractionAttribute(
          obj,
          this.data.attribute.id
        ).subscribe((resp: any) => {
          let response = JSON.parse(resp);
          if (response.statusCode == 200) {
            var reassignres = "Entity updated Successfully";
            this.PdfserviceService.annatationCount(reassignres);
            this.dialogRef.close();
          }
        });
      }
    }
  }

  reassignsegment(checkedclasuses, i) {
    this.selected = i;
    this.itemchecked = checkedclasuses;
    var obj = {
      docId: this.data.docId,
      pageNo: this.data.pageNo,
      methodType: this.data.methodType,
      segmentId: this.data.segmentId,
      attribute: {
        id: this.data.attribute.id,
        attributeText: this.data.attribute.attributeText,
        attributeLabel: checkedclasuses.attributeName,
        attributeLabelId: checkedclasuses.attributeId,
        attributeCoordinates: this.data.attribute.attributeCoordinates,
        attributeCode: checkedclasuses.abbrevation,
      },
    };

    if (this.data.category == "inside") {
      this.PdffilesService.updateAttribute(
        obj,
        this.data.attribute.id
      ).subscribe((resp: any) => {
        let response = JSON.parse(resp);
        this.apiResponse = response.statusMessage;
        if (response.statusCode == 200) {
          var reassignres = "Entity reassigned successfully";
          this.PdfserviceService.annatationCount(reassignres);
          // this.PdfserviceService.reviewannatation(reassignres);
          this.dialogRef.close();
        }
      });
    } else if (this.data.category == "outside") {
      this.PdffilesService.updateExtractionAttribute(
        obj,
        this.data.attribute.id
      ).subscribe((resp: any) => {
        let response = JSON.parse(resp);
        this.apiResponse = response.statusMessage;
        console.log("reassignoutside", this.apiResponse);
        if (response.statusCode == 200) {
          var reassignres = "Entity reassigned successfully";
          this.PdfserviceService.annatationCount(reassignres);
          // this.PdfserviceService.reviewannatation(reassignres);
          this.dialogRef.close();
        }
      });
    }
  }
  closeresponse() {
    this.show = false;
  }
  dialogshow() {
    if (this.data.type === "edit") {
      this.showdialog = true;
      this.deleteconfirm = false;
      this.reassigndialog = false;
    } else if (this.data.type === "delete") {
      this.deleteconfirm = true;
      this.reassigndialog = false;
      this.showdialog = false;
    } else {
      this.reassigndialog = true;
      this.deleteconfirm = false;
      this.showdialog = false;
      this.getExtraction();
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  cancel() {
    this.dialogRef.close();
  }
  confirm() {
    var obj = {
      docId: this.data.docId,
      pageNo: this.data.pageNo,
      methodType: this.data.methodType,
      segmentId: this.data.segmentId,
      attribute: {
        id: this.data.attribute.id,
        attributeText: this.data.attribute.attributeText,
        attributeLabel: this.data.attribute.attributeLabel,
        attributeLabelId: this.data.attribute.labelId,
        attributeCoordinates: this.data.attribute.attributeCoordinates,
        attributeCode: this.data.attribute.attributeCode,
        isUserConfirmed: false,
      },
    };
    if (this.data.category == "inside") {
      this.PdffilesService.updateAttribute(
        obj,
        this.data.attribute.id
      ).subscribe((resp: any) => {
        let response = JSON.parse(resp);
        this.apiResponse = response.statusMessage;
        if (response.statusCode === 200) {
          var res = "Entity deleted successfully";
          if (this.data.typedelete === "livemodule") {
            this.PdfserviceService.annatationCount(res);
          } else {
            var data = {
              pageNo: parseInt(this.data.pageNo),
              segementId: this.data.attribute.id,
              response: res,
            };
            this.PdfserviceService.reviewannatation(data);
          }
          this.dialogRef.close();
        }
      });
    } else if (this.data.category === "outside") {
      this.PdffilesService.updateExtractionAttribute(
        obj,
        this.data.attribute.id
      ).subscribe((resp: any) => {
        let response = JSON.parse(resp);
        this.apiResponse = response.statusMessage;
        // if (response.statusMessage === "Deleted Successfully.") {
        //   this.PdfserviceService.reviewannatation(this.apiResponse);
        // }
        if (response.statusCode === 200) {
          var res = "Entity deleted successfully";
          if (this.data.typedelete === "livemodule") {
            this.PdfserviceService.annatationCount(res);
          } else {
            var data = {
              pageNo: parseInt(this.data.pageNo),
              segementId: this.data.attribute.id,
              response: res,
            };
            this.PdfserviceService.reviewannatation(data);
          }
          this.dialogRef.close();
        }
      });
    }
  }
}
