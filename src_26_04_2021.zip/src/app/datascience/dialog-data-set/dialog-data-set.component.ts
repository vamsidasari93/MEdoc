import { Component, OnInit, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {TooltipPosition} from '@angular/material/tooltip';
export interface DialogData {
  name: string;
  value: string;
  categories: any[];
  isCategories: boolean;
  annotationData: any[];
}
@Component({
  selector: 'app-dialog-data-set',
  templateUrl: './dialog-data-set.component.html',
  styleUrls: ['./dialog-data-set.component.scss']
})
export class DialogDataSetComponent implements OnInit {
  categoryList: any[] = [];
  positionOptions: TooltipPosition[] = ['below', 'above', 'left', 'right'];
  constructor(
    public dialogRef: MatDialogRef<DialogDataSetComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {}
    ngOnInit() {
      if(this.data.isCategories){
        this.categoryList = this.data.categories
        .map(obj => {
          var data = this.data.annotationData.filter(c => c.labelId == obj.id);
          return {...obj,
            countTwo :data? data.length : 0,
            tooltip: `Old ${obj.count} \n Present ${data.length}`
          }
        });
      }
      
    }
    onNoClick(): void {
      this.dialogRef.close();
    }

    setPositionTooltip(i){
     
      if(i%2 == 0){
       return this.positionOptions[2]
      }
      else{
       return this.positionOptions[3]
      }
    }

}
