import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { DocInfoHelpPopupComponent } from "src/app/components/doc-pdf/doc-info-help-popup/doc-info-help-popup.component";

@Component({
  selector: "app-help-popup",
  templateUrl: "./help-popup.component.html",
  styleUrls: ["./help-popup.component.scss"],
})
export class HelpPopupComponent implements OnInit {
  infoType: any;

  constructor(
    public dialogRef: MatDialogRef<DocInfoHelpPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.infoType = data.type;
    console.log(data.type);
  }
  ngOnInit() {}
}
