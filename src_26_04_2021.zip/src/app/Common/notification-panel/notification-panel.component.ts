import { Component, Input, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";

@Component({
  selector: "app-notification-panel",
  templateUrl: "./notification-panel.component.html",
  styleUrls: ["./notification-panel.component.scss"],
})
export class NotificationPanelComponent implements OnInit {
  // @Input() notifyList: Array<any> = [];
  notifyList = [];
  today: number = Date.now();
  userId: number;
  showall: boolean = true;
  end: number = 3;
  empty: boolean = false;
  constructor(
    private PdfS: PdffilesService,
    private router: Router,
    private pdfService: PdfserviceService
  ) {}

  ngOnInit() {
    this.userId = JSON.parse(localStorage.getItem("userID"));
    this.GetNotification();
  }
  GetNotification() {
    this.notifyList = [];
    this.PdfS.GetNotificationData(this.userId).subscribe((data: any) => {
      this.notifyList = data.result;
      if (data && data.result && data.result.length) {
        this.empty = true;
      }
      // localStorage.setItem("Notificationscount", count);
      // console.log("Notifications", data.result);
    });
  }
  gotoChat(DocId, type) {
    this.PdfS.UpdateReadNotification(DocId).subscribe((data: any) => {
      console.log("Notifications", data);
      this.GetNotification();
    });
    this.pdfService.reviewannatation("notification");
    this.pdfService.notification("notification");
    if (type === "card") {
      this.router.navigate(["Documentslist/AnnotationDocument", { id: DocId }]);
    }
  }
  showAll() {
    if (this.notifyList) {
      this.end = this.notifyList.length;
    }
    this.showall = false;
  }
  lessAll() {
    if (this.notifyList) {
      this.end = 3;
      this.showall = true;
    }
  }
}
