﻿import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";

import { environment } from "../../environments/environment";
import { User } from "../_models";

@Injectable({ providedIn: "root" })
export class AuthenticationService {
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;
  public response: any;
  /**
   * Application roles list
   */
  array = [
    {
      role_id: 1,
      tab_label: "SuperAdmin Module",
      url: "/datascience",
    },
    {
      role_id: 2,
      tab_label: "QC Module",
      url: "/Documentslist/Documents",
    },
    {
      role_id: 3,
      tab_label: "Training Module",
      url: "/Documentslist/Documents",
    },
    {
      role_id: 4,
      tab_label: "Live Module",
      url: "/Documentslist/Documentslistlive",
    },
    {
      role_id: 5,
      tab_label: "DataScience Module",
      url: "/datascience/usecases",
    },
    {
      role_id: 6,
      tab_label: "Admin Module",
      url: "/Admin",
    },
  ];
  showConfig = [];
  role: any;
  user: any[];
  isLoggedIn: any;
  constructor(private http: HttpClient) {
    this.currentUserSubject = new BehaviorSubject<User>(
      JSON.parse(localStorage.getItem("userinfo"))
    );
    this.currentUser = this.currentUserSubject.asObservable();
  }
  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }
  /**
   * Login validations
   */
  login() {
    var rolesids = [];
    this.showConfig = [];
    const apiUrl = `${environment.apiUrl}/Login/ValidateADUser`;
    return this.http.post(apiUrl, {}, { responseType: "json" }).pipe(
      map((response: any) => {
        var roleID = response.roles;
        for (let i = 0; i < roleID.length; i++) {
          this.role = roleID[i];
          if (roleID[i].roleID === 6) {
            console.log("treu");
            localStorage.setItem("IsAdmin", "true");
          }
          rolesids.push(this.role);
        }
        rolesids.map((x) => {
          let configObj = this.array.find((y) => y.role_id === x.roleID);

          if (configObj) {
            this.showConfig.push(configObj);
          }
        });
        var res = roleID.length ? "Success" : "Failure";
        if (res === "Success") {
          this.user = this.showConfig;
          localStorage.setItem("userinfo", JSON.stringify(response));
          localStorage.setItem("currentUser", "Success");
          localStorage.setItem("usersrole", JSON.stringify(this.user));
          localStorage.setItem("data", res);
          if (response.isADActive) {
            this.currentUserSubject.next(response);
          } else {
            this.response = response;
          }
        }
        return res;
      })
    );
  }
  afterChangePassword() {
    this.currentUserSubject.next(this.response);
  }

  logout() {
    // remove user from local storage to log user out
    // localStorage.removeItem("currentUser");
    localStorage.clear();
    this.currentUserSubject.next(null);
  }
}
