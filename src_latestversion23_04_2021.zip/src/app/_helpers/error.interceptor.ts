import { Injectable } from "@angular/core";
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpHeaders,
} from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";
import { PdfserviceService } from "../Services/pdfservice.service";
import { AuthenticationService } from "../_services";
import { BroadcastService } from "@azure/msal-angular";

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  userInfo: any;
  accessToken = "";
  roleID: string;
  constructor(
    private authenticationService: AuthenticationService,
    private PdfserviceService: PdfserviceService,
    private broadcastService: BroadcastService
  ) {
    this.userInfo = JSON.parse(localStorage.getItem("userinfo"));
    this.broadcastService.subscribe("msal:acquireTokenSuccess", (payload) => {
      // do something here
    });
    let localStorageArr = Object.keys(localStorage);
    for (let index = 0; index < localStorageArr.length; index++) {
      if (localStorageArr[index].split(",").length > 1) {
        let tokenObj = JSON.parse(localStorage.getItem(localStorageArr[index]));
        this.accessToken = "Bearer " + tokenObj.accessToken;
      }
    }
  }

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    this.userInfo = JSON.parse(localStorage.getItem("userinfo"));

    let userID = localStorage.getItem("userID");
    this.roleID = localStorage.getItem("roleID");
    let isAdmin = localStorage.getItem("IsAdmin");

    if (isAdmin == "true") {
      this.roleID = "6";
    }

    let refHeader: any;
    if (this.userInfo) {
      request = request.clone({
        headers: new HttpHeaders({
          Authorization: this.accessToken,
          userId: userID,
          roleId: this.roleID,
          // Ocp-Apim-Subscription-Key : "952df1b14d7c4d1884291eabb3d747ad"
        }),
      });
    } else {
      request = request.clone({
        headers: new HttpHeaders({ Authorization: this.accessToken }),
      });
    }

    if (this.accessToken) {
      return next.handle(request).pipe(
        catchError((err) => {
          if ([401, 403].indexOf(err.status) !== -1) {
            // auto logout if 401 Unauthorized or 403 Forbidden response returned from api
            this.authenticationService.logout();
            location.reload(true);
          }
          // if (500) {
          //   this.PdfserviceService.geterrors(" 500 Internal Server Error");
          // }
          // if (400) {
          //   this.PdfserviceService.geterrors(" 400 Bad request");
          // }
          if (err && err.error) {
            var error = err.error.message || err.statusText;
          }

          // console.log(error);
          return throwError(error);
        })
      );
    }
  }
}
