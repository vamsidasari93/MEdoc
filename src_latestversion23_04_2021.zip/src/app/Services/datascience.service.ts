import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable, Subject, throwError } from "rxjs";
import { catchError, map } from "rxjs/operators";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { environment } from "src/environments/environment";
@Injectable({
  providedIn: "root",
})
export class DatascienceService {
  testValue: boolean = false;
  apiUrl: string;
  dataScienceUrl: string;
  dataScienceUrlPython: string;

  constructor(private http: HttpClient) {
    this.apiUrl = environment.apiUrl;
    this.dataScienceUrl = environment.dataScienceUrl;
    this.dataScienceUrlPython = environment.dataScienceUrlPython;
  }

  getTestValue() {
    return this.testValue;
  }

  getCategory(usecaseId) {
    return this.http.post(`${environment.apiUrl}/Org/GetLabels`, {
      responseType: "json",
    });
  }
  getCategories(usecaseId) {
    return this.http.post(
      `${environment.apiUrl}/Org/getCategories?usecaseId=${usecaseId}`,
      { responseType: "json" }
    );
  }
  getDocument(useCase = 0) {
    return this.http.post(
      `${environment.dataScieneLocalUrl}/DataScience/getDocumentList?useCase=${useCase}`,
      { responseType: "json" }
    );
  }

  getUseCases(userId) {
    return this.http.post(
      `${environment.dataScieneLocalUrl}/DataScience/useCases?userId=${userId} `,
      { responseType: "json" }
    );
  }
  getDataSets(id) {
    return this.http.post(
      `${environment.dataScieneLocalUrl}/DataScience/dataSetList?useCase=${id}`,
      { responseType: "json" }
    );
  }
  getAnnotation(body) {
    return this.http
      .post(
        `${environment.dataScieneLocalUrl}/DataScience/getAnnotations`,
        body,
        { responseType: "json" }
      )
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  getAttributeAnnotation(body) {
    return this.http
      .post(
        `${environment.dataScieneLocalUrl}/DataScience/getAttributeAnnotations`,
        body,
        { responseType: "json" }
      )
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  getAnnotations(body) {
    return this.http
      .post(
        `${environment.dataScieneLocalUrl}/DataScience/getAnnotationDatascience`,
        body,
        { responseType: "json" }
      )
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  saveAnnotation(body) {
    return this.http
      .post(
        `${environment.dataScieneLocalUrl}/DataScience/saveAnnotations`,
        body,
        { responseType: "json" }
      )
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  saveAttributeAnnotation(body) {
    return this.http
      .post(
        `${environment.dataScieneLocalUrl}/DataScience/saveAttributeAnnotations`,
        body,
        { responseType: "json" }
      )
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  download(body) {
    return this.http
      .post(
        `${environment.dataScieneLocalUrl}/DataScience/downloadExcel`,
        body,
        { responseType: "blob" }
      )
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  downloadAttribute(body) {
    return this.http
      .post(
        `${environment.dataScieneLocalUrl}/DataScience/downloadExcelAttribute`,
        body,
        { responseType: "blob" }
      )
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  getWord(body) {
    return this.http
      .post(`${environment.dataScienceUrlPython}/word_cloud`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  getUniqueCategoriesDataCount(body) {
    return this.http
      .post(`${environment.dataScienceUrlPython}/unique_categories`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  getNGrams(body) {
    return this.http
      .post(`${environment.dataScienceUrlPython}/n_grams`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  getTsneAnalysis(body) {
    return this.http
      .post(`${environment.dataScienceUrlPython}/tsne`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  getAnalyzeText(body) {
    return this.http
      .post(`${environment.dataScienceUrlPython}/ner`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  getAnalyzeTextDepedencyParse(body) {
    return this.http
      .post(`${environment.dataScienceUrlPython}/dependency_parse`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  getCustomPreprocessing(body) {
    return this.http
      .post(`${environment.dataScienceUrlPython}/custom_preprocessing`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  getPreTrainedModelW2V(body) {
    console.log(1, body);
    let url = "";
    if (body.model_type == "word2vec") {
      url = `word2vec_pretrain`;
    } else {
      url = `doc2vec_pretrain`;
    }
    return this.http
      .post(`${environment.dataScienceUrlPython}/${url}`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  getTrainedNewModelW2V(body) {
    console.log(1, body);
    let url = "";
    if (body.model_type == "word2vec") {
      url = `word2vec_train_new`;
    } else {
      url = `doc2vec_train_new`;
    }
    return this.http
      .post(`${environment.dataScienceUrlPython}/${url}`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  getPreTrainedModelLogistic(body) {
    return this.http
      .post(`${environment.dataScienceUrlPython}/lr_pretrain`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  getTrainedNewModelLogistic(body, url) {
    // environment.dataScienceUrlPython
    return this.http
      .post(`${environment.dataScienceUrlPython}/${url}`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  getModalList(id, datasetName, type) {
    let url =
      environment.dataScieneLocalUrl +
      "/DataScience/getModels?useCaseId=" +
      id +
      "&datasetName=" +
      datasetName +
      "&type=" +
      type;
    return this.http.post(url, { responseType: "json" }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  saveModel(body, isNew) {
    let url =
      environment.dataScieneLocalUrl +
      "/DataScience/createModel?isNew=" +
      isNew;
    return this.http.post(url, body, { responseType: "json" }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  testModel(body) {
    let url = environment.dataScieneLocalUrl + "/DataScience/testing_model_ner";

    return this.http.post(url, body, { responseType: "json" }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
