import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable, Subject, throwError } from "rxjs";
import { catchError, map } from "rxjs/operators";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { environment } from "src/environments/environment";
@Injectable({
  providedIn: "root",
})
export class DashboardService {
  apiUrl: string;
  constructor(private http: HttpClient) {
    this.apiUrl = environment.apiUrl;
    // this.apiUrl = "https://localhost:44338/" + "api"
  }

  getCategory() {
    let urlOrigin = this.apiUrl + "/Org/GetLabels"; //`${this.apiUrl}/Org/GetLabels`;
    return this.http.post(urlOrigin, { responseType: "json" });
  }

  getDocumentList(fromDate, toDate, usecaseId) {
    // this.apiUrl = `https://localhost:44338/api`
    fromDate = fromDate ? fromDate : 0;
    toDate = toDate ? toDate : 0;
    let urlOrigin =
      this.apiUrl +
      "/Dashboard/documentsList?fromDate=" +
      fromDate +
      "&toDate=" +
      toDate +
      "&usecaseId=" +
      usecaseId;

    //`${this.apiUrl}/Dashboard/documentsList?fromDate=${fromDate}&toDate=${toDate}&usecaseId=${usecaseId}`
    return this.http.post(urlOrigin, { responseType: "json" });
  }

  getDocumentsCount(useCaseId, fromDate, toDate) {
    let urlOrigin =
      this.apiUrl +
      "/Dashboard/documentsCount?fromDate=" +
      fromDate +
      "&toDate=" +
      toDate +
      "&usecaseId=" +
      useCaseId;
    //`${this.apiUrl}/Dashboard/documentsCount?fromDate=${fromDate}&toDate=${toDate}&usecaseId=${useCaseId}`
    return this.http.post(urlOrigin, { responseType: "json" });
  }

  getAnnotationAndReviewAnnotation(body) {
    let urlOrigin = this.apiUrl + "/Dashboard/annotationAndReviewAnnotation";
    //`${this.apiUrl}/Dashboard/annotationAndReviewAnnotation`
    return this.http
      .post(urlOrigin, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  getDocumentWiseAnnotationDetails(body) {
    let urlOrigin = this.apiUrl + "/Dashboard/documentWiseAnnotationDetails";
    //`${this.apiUrl}/Dashboard/documentWiseAnnotationDetails`
    return this.http
      .post(urlOrigin, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  getDocumentWiseAnnotationFullDetails(body) {
    let urlOrigin =
      this.apiUrl + "/Dashboard/documentWiseAnnotationFullDetails"; //`${this.apiUrl}/Dashboard/documentWiseAnnotationFullDetails`;
    return this.http.post(urlOrigin, body, { responseType: "json" }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  getAttributeWiseAnnotation(body) {
    let urlOrigin = this.apiUrl + "/Dashboard/AttrWirseTotalAnnVsReviewAnn"; //`${this.apiUrl}/Dashboard/AttrWirseTotalAnnVsReviewAnn`;
    return this.http
      .post(`${this.apiUrl}/Dashboard/AttrWirseTotalAnnVsReviewAnn`, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  getCategories(usecaseId) {
    let urlOrigin =
      environment.apiUrl + "/Org/getCategories?usecaseId=" + usecaseId; //`${environment.apiUrl}/Org/getCategories?usecaseId=${usecaseId}`
    return this.http.post(urlOrigin, { responseType: "json" });
  }

  getAttributes(usecaseId) {
    let urlOrigin =
      environment.apiUrl + "/Org/getAttributes?usecaseId=" + usecaseId;
    //`${environment.apiUrl}/Org/getAttributes?usecaseId=${usecaseId}`
    return this.http.post(urlOrigin, { responseType: "json" });
  }

  getDocumentListLive(fromDate, toDate, usecaseId) {
    fromDate = fromDate ? fromDate : 0;
    toDate = toDate ? toDate : 0;
    let urlOrigin =
      this.apiUrl +
      "/Dashboard/liveDocumentsList?fromDate=" +
      fromDate +
      "&toDate=" +
      toDate +
      "&usecaseId=" +
      usecaseId;
    //`${this.apiUrl}/Dashboard/liveDocumentsList?fromDate=${fromDate}&toDate=${toDate}&usecaseId=${usecaseId}`
    return this.http.post(urlOrigin, { responseType: "json" });
  }

  getDocumentsCountLive(useCaseId, fromDate, toDate) {
    let urlOrigin =
      this.apiUrl +
      "/Dashboard/liveDocsInfo?fromDate=" +
      fromDate +
      "&toDate=" +
      toDate +
      "&usecaseId=" +
      useCaseId;
    // `${this.apiUrl}/Dashboard/liveDocsInfo?fromDate=${fromDate}&toDate=${toDate}&usecaseId=${useCaseId}`
    return this.http.post(urlOrigin, { responseType: "json" });
  }
  getAnnotationAndReviewAnnotationLive(body) {
    let urlOrigin = this.apiUrl + "/Dashboard/liveCategorywiseCount";
    //`${this.apiUrl}/Dashboard/liveCategorywiseCount`
    return this.http
      .post(urlOrigin, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  getAttributeWiseAnnotationLive(body) {
    let urlOrigin = this.apiUrl + "/Dashboard/liveAttributewiseCount";
    //`${this.apiUrl}/Dashboard/liveAttributewiseCount`
    return this.http
      .post(urlOrigin, body, {
        responseType: "json",
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
}
