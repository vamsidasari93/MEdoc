import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import "rxjs/add/operator/map";
import { environment } from "src/environments/environment";
@Injectable({
  providedIn: "root",
})
export class AdminService {
  userInfo: any;
  header: any;
  constructor(private http: HttpClient) {
    this.userInfo = JSON.parse(localStorage.getItem("userinfo"));
    let userID = localStorage.getItem("userID");
    console.log("userID", userID);
    let roleID = localStorage.getItem("roleID");
    this.header = {
      userId: userID,
      roleId: roleID,
    };
  }

  getTreedata() {
    // var header = new HttpHeaders();
    // header = header.set("Content-Type", "application/json; charset=utf-8");
    return this.http.get("src/assets/Data/Data.Json", { headers: this.header });
    // return this.http.get(apiUrl).map((response: Response) => {
    //   const data = response.json();
    //   return data;
    // });
  }

  AddOrUpdateLogoAndTheme(brandlogo: any): Observable<boolean> {
    // const endpoint = `${environment.apiUrl}/${this.moduleName}/UploadPDF`;
    // var header = new HttpHeaders();
    // header = header.set("Content-Type", "application/json; charset=utf-8");
    const endpoint = `${environment.apiUrl}/OrgSetup/AddOrUpdateLogoAndTheme`;
    return this.http.post(endpoint, brandlogo, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  getBrandlogo() {
    // var brandId = brandId;
    // console.log(brandId);
    // const endpoint = `${environment.apiUrl}/${this.moduleName}/UploadPDF`;
    // var header = new HttpHeaders();
    // header = header.set("userId", this.userInfo.userId);
    const endpoint = `${environment.apiUrl}/OrgSetup/GetLogoAndTheme`;
    return this.http.post(endpoint, { responseType: "json" });
  }
  SaveOrganizationHierarchy(data) {
    var url = `${environment.apiUrl}/OrgSetup/SaveOrganizationHierarchy`;
    var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(`${url}`, data, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  GetOrganizationHierarchyTable() {
    var url = `${environment.apiUrl}/OrgSetup/GetOrganizationHierarchyTable`;
    // var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(url, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  GetOrganizationList() {
    var url = `${environment.apiUrl}/OrgSetup/GetOrganizationList`;
    // var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(url, { headers: this.header });
  }
  GetUserRoles() {
    var url = `${environment.apiUrl}/OrgSetup/GetUserRoles`;
    // var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(url, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  GetConfiguredUseCases() {
    var url = `${environment.apiUrl}/OrgSetup/GetConfiguredUseCases`;
    // var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(url, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  GetOnboardedUser() {
    var url = `${environment.apiUrl}/OrgSetup/GetOnboardedUser`;
    // var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(url, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  projectNamelist(requestId) {
    var url = `${environment.apiUrl}/OrgSetup/GetUseCaseList`;
    var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(`${url}`, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  GetMappedUseCases(requestId) {
    var url = `${environment.apiUrl}/OrgSetup/GetMappedUseCasesbyHierarchyIds`;
    var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http
      .post(`${url}`, requestId, {
        headers: this.header,
      })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  GetOrganizationInputOptions() {
    var url = `${environment.apiUrl}/OrgSetup/GetOrganizationInputOptions`;
    var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(`${url}`, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  ConfigureUseCases(data) {
    var url = `${environment.apiUrl}/OrgSetup/ConfigureUseCases`;
    var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(`${url}`, data, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  UserOnboarding(data) {
    var url = `${environment.apiUrl}/OrgSetup/UserOnboarding`;
    var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(`${url}`, data, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  getOrgHierarchy() {
    var url = `${environment.apiUrl}/OrgSetup/GetOrganizationHierarchy`;
    var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(url, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
        console.log(response);
      })
    );
  }
  GetSummary(usecaseid) {
    var url = `${environment.apiUrl}/OrgSetup/GetSummary`;
    var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http
      .post(`${url}?usecaseid=${usecaseid}`, { headers: this.header })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }
  FinalSubmit(requestId) {
    var url = `${environment.apiUrl}/OrgSetup/FinalSubmit`;
    var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http
      .post(`${url}?submittedby=${requestId}`, { headers: this.header })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  deleteOrganisationHierarchy(data) {
    var url = `${environment.apiUrl}/OrgSetup//DeleteOrganizationHierarchy`;
    var headers = new HttpHeaders({ userId: this.userInfo.userId });
    return this.http.post(`${url}`, data, { headers: this.header }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
