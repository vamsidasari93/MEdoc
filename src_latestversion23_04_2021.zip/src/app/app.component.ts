import {
  Component,
  TemplateRef,
  ViewChild,
  ViewContainerRef,
  ViewEncapsulation,
} from "@angular/core";
// import { PdfserviceService } from "./Services/pdfservice.service";
import { User, Role } from "./_models";
import { AuthenticationService } from "./_services";
import { Router } from "@angular/router";
import { Subscription } from "rxjs";
import { MatButton, MatDialog, MatSnackBar } from "@angular/material";
import { PdfserviceService } from "./Services/pdfservice.service";
import { Overlay, OverlayRef } from "@angular/cdk/overlay";
import { TemplatePortal } from "@angular/cdk/portal";
import { DatePipe } from "@angular/common";
import { Idle, DEFAULT_INTERRUPTSOURCES } from "@ng-idle/core";
import { Keepalive } from "@ng-idle/keepalive";
import { BroadcastService, MsalService } from "@azure/msal-angular";
import { PdffilesService } from "./Services/pdffiles.service";
import { IdleComponent } from "./Common/idle/idle.component";

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
  // encapsulation: ViewEncapsulation.None,
})
export class AppComponent {
  title = "app";
  currentUser: any;
  module = false;
  isAdmin = false;
  moduleName: any;
  subscription: Subscription;
  role: any;
  tabh: boolean = false;
  count = 0;
  notificationList = [];
  myDate: any;
  private _overlayRef: OverlayRef;
  @ViewChild("notifyOrigin", { static: false }) private _themeOrigin: MatButton;
  @ViewChild("notifyPanel", { static: false })
  private _themePanel: TemplateRef<any>;
  idleState = "";
  timedOut = false;
  dialogRef: any;
  constructor(
    private router: Router,
    private _snackBar: MatSnackBar,
    private PdffilesService: PdfserviceService,
    private authenticationService: AuthenticationService,
    private _overlay: Overlay,
    private _viewContainerRef: ViewContainerRef,
    private datePipe: DatePipe,
    private idle: Idle,
    private keepalive: Keepalive,
    private _msalService: MsalService,
    private broadcastService: BroadcastService,
    private PdfS: PdffilesService,
    public dialog: MatDialog
  ) {
    this.broadcastService.subscribe("msal:acquireTokenSuccess", (payload) => {
      // do something here
      console.log("payload", payload.idToken.rawIdToken);
    });
    // sets an idle timeout of 5 seconds, for testing purposes.
    idle.setIdle(295);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    idle.setTimeout(5);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    // this.idle.onIdleEnd.subscribe(() => this.idleState = 'No longer idle.');
    idle.onTimeout.subscribe(() => {
      this.openSnackBar("Session Expired!");
      this.logout();
    });
    idle.onTimeoutWarning.subscribe((countdown) => {
      this.idleState = "you will be logged out in" + countdown + " seconds!";
      if (!this.timedOut) {
        this.openDialog();
      } else {
        this.dialogRef.componentInstance.data = { idleState: this.idleState };
      }
    });
    // this.idle.onIdleStart.subscribe(() => this.idleState = 'You\'ve gone idle!');
    // this.idle.onTimeoutWarning.subscribe((countdown) => this.idleState = 'You will time out in ' + countdown + ' seconds!');

    // sets the ping interval to 15 seconds
    keepalive.interval(15);

    // keepalive.onPing.subscribe(() => this.lastPing = new Date());
    this.idle.watch();
    this.myDate = this.datePipe.transform(new Date(), "yyyy");
    this.currentUser = [];
    this.subscription = this.authenticationService.currentUser.subscribe(
      (x) => {
        this.currentUser = x;
        // console.log(x);
        var res =
          this.currentUser && this.currentUser.roles.length > 0
            ? "Success"
            : "Failure";
        if (res === "Success") {
          this.isAdmin = true;
        } else {
          this.isAdmin = false;
        }
        // if (x) {
        //   var roleid = this.currentUser.roles[0].roleID;
        //   // console.log(roleid);
        //   if (roleid == 5) {
        //     this.tabh = true;
        //   } else {
        //     this.tabh = false;
        //   }
        // } else {
        //   this.tabh = false;
        // }
      }
    );
    this.PdffilesService.loginstate$.subscribe((value) => {
      if (value === "Success") {
        var loginalert = "logged in successfully";
        setTimeout(() => {
          this.openSnackBar(loginalert);
        }, 1000);
      }
    });
    this.subscription = this.PdffilesService.notification$.subscribe((data) => {
      // this.notifycount();
      if (data) {
        console.log("notify", data);
        this.notifycount();
      }
    });
  }

  ngOnInit() {
    this.broadcastService.subscribe("msal:loginFailure", (payload) => {
      // do something here
      console.log("failure", payload.idToken.rawIdToken);
    });

    this.broadcastService.subscribe("msal:loginSuccess", (payload) => {
      // do something here
      console.log("success", payload.idToken.rawIdToken);
    });
  }
  notifycount() {
    // console.log("notifycount hitting initial");
    let userId = localStorage.getItem("userID");
    this.PdfS.GetNotificationData(userId).subscribe((data: any) => {
      if (data.result && data.result.length) {
        this.count = data.result.length;
      }

      // console.log("Notificationscount", this.count);
    });
  }
  isRoleExist = (roleId) => {
    let userInfo = JSON.parse(localStorage.getItem("userinfo"));
    let roleid = JSON.parse(localStorage.getItem("roleID"));
    let roleList = userInfo.roles;
    // console.log("dashboard",roleId);
    return roleList.find((x) => x.roleID === roleId) != undefined &&
      roleid == roleId
      ? true
      : false;
  };

  openDialog(): void {
    this.timedOut = true;
    let dialogRef = this.dialog.open(IdleComponent, {
      data: { idleState: this.idleState },
      panelClass: "idle",
    });
    this.dialogRef = dialogRef;
    dialogRef.afterClosed().subscribe((result) => {
      this.timedOut = false;
      if (result == "signin") {
        this.reset();
      } else if (result == "signout") {
        this.logout();
      }
    });
  }

  reset() {
    this.idle.watch();
    this.idleState = "Started";
    this.timedOut = false;
  }

  navigation() {
    let userInfo = JSON.parse(localStorage.getItem("userinfo"));
    let roleId = userInfo.roles[0].roleID;
    if (roleId === 1 || roleId === 6) {
      //super admin //Admin
      this.router.navigate(["/Admin"]);
    } else if (roleId === 2) {
      // QC
      this.router.navigate(["/dashboard"]);
    } else if (roleId === 3 || roleId === 4 || roleId === 5) {
      //trainee & live & Datascience
      this.router.navigate(["/datascience"]);
    }
  }

  gotoProfile() {
    this.router.navigate(["/login/profile"]);
  }

  openPanel(): void {
    // Create the overlay
    this._overlayRef = this._overlay.create({
      hasBackdrop: true,
      backdropClass: "",
      scrollStrategy: this._overlay.scrollStrategies.block(),
      positionStrategy: this._overlay
        .position()
        .flexibleConnectedTo(this._themeOrigin._elementRef.nativeElement)
        .withFlexibleDimensions()
        .withViewportMargin(16)
        .withLockedPosition()
        .withPositions([
          {
            originX: "start",
            originY: "bottom",
            overlayX: "start",
            overlayY: "top",
          },
          {
            originX: "start",
            originY: "top",
            overlayX: "start",
            overlayY: "bottom",
          },
          {
            originX: "end",
            originY: "bottom",
            overlayX: "end",
            overlayY: "top",
          },
          {
            originX: "end",
            originY: "top",
            overlayX: "end",
            overlayY: "bottom",
          },
        ]),
    });

    // Create a portal from the template
    const templatePortal = new TemplatePortal(
      this._themePanel,
      this._viewContainerRef
    );

    // Attach the portal to the overlay
    this._overlayRef.attach(templatePortal);

    // Subscribe to the backdrop click
    this._overlayRef.backdropClick().subscribe(() => {
      // If overlay exists and attached...
      if (this._overlayRef && this._overlayRef.hasAttached()) {
        // Detach it
        this._overlayRef.detach();
      }

      // If template portal exists and attached...
      if (templatePortal && templatePortal.isAttached) {
        // Detach it
        templatePortal.detach();
      }
    });
  }

  logout() {
    this.currentUser = [];
    localStorage.clear();
    sessionStorage.clear();
    this._msalService.logout();
    this.authenticationService.logout();
    // this.router.navigate(["/login"]);
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  openSnackBar(message) {
    message = message.charAt(0).toUpperCase() + message.slice(1);
    this._snackBar.open(message, "", {
      panelClass: ["snackBar"],
      duration: 2000,
    });
  }
}
