import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreeeditstructureComponent } from './treeeditstructure.component';

describe('TreeeditstructureComponent', () => {
  let component: TreeeditstructureComponent;
  let fixture: ComponentFixture<TreeeditstructureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreeeditstructureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreeeditstructureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
