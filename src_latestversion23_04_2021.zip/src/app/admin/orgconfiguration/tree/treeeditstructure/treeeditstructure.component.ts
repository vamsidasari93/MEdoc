import {
  Component,
  OnInit,
  AfterViewInit,
  Input,
  Output,
  EventEmitter,
} from "@angular/core";
declare var $: any;
@Component({
  selector: "app-treeeditstructure",
  templateUrl: "./treeeditstructure.component.html",
  styleUrls: ["./treeeditstructure.component.css"],
})
export class TreeeditstructureComponent implements OnInit, AfterViewInit {
  @Input() ChecklistName: string;
  @Input() jsonData: Array<object>;
  @Input() showButtons: boolean;
  @Output() nodeSelected = new EventEmitter();
  @Output() loadedData = new EventEmitter();

  showAddParent = false;
  showCreateChild = false;
  showRemoveNode = false;
  treeData: Array<object> = [];
  selectedTreeData: Array<object> = [];
  lastNodeId = 0;
  curEvent = "";
  treeObject: any;
  RootNode;
  parentIterator = 0;
  childIterator = 0;

  constructor() {
    console.log("dist tree");
  }

  ngOnInit() {
    if (this.jsonData === undefined && this.ChecklistName !== "") {
      this.treeData.push({
        id: "1",
        parent: "#",
        type: "Checklist",
        text: this.ChecklistName,
      });
    } else {
      this.treeData = this.jsonData;
      this.selectedTreeData = this.jsonData;
      this.lastNodeId = this.selectedTreeData.length;
    }
  }

  updategrid(data) {
    if (!!data) {
      this.treeObject.jstree(true).settings.core.data = data;
    } else {
      this.treeObject.jstree(true).settings.core.data = this.jsonData;
    }
    this.treeObject.jstree(true).refresh();
  }

  ngAfterViewInit() {
    var curObj = this;
    curObj.treeObject = $("#trees");
    $(function () {
      $("#trees").tooltip();
      $("#trees")
        .jstree({
          core: {
            check_callback: true,
            data: curObj.selectedTreeData,
          },
          types: {
            default: {
              icon: "fa fa-folder",
            },
            Checklist: {
              icon: "fa fa-folder",
            },
            Others: {
              icon: "fa fa-cube",
            },
            Child: {
              icon: "fa fa-file-text-o",
            },
          },
          plugins: ["types"],
        })
        .bind("loaded.jstree", function (event, data) {
          curObj.treeObject.jstree("open_all");
          curObj.lastNodeId = curObj.getTreeData().length;
          curObj.ShowLoadedData();
        })
        .bind("hover_node.jstree", function (event, data) {
          $("#" + data.node.id).prop("title", data.node.text);
        })
        .bind("refresh.jstree", function (event, data) {
          curObj.treeObject.jstree("open_all");
          if (curObj.curEvent === "AddRootNode") {
            var rootNode = curObj.treeObject.jstree(true).get_node("1");
            curObj.treeObject
              .jstree()
              .edit(rootNode)
              .edit(rootNode, null, function (node, status) {
                curObj.ShowLoadedData();
              });
          }
          curObj.lastNodeId = curObj.getTreeData().length;
          curObj.showCreateChild = false;
          curObj.showAddParent = false;
          curObj.showRemoveNode = false;
        })
        .on("click", ".jstree-anchor", function (e) {
          var selNode = curObj.treeObject.jstree("get_selected");
          var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
          if (selNodeAttr.type === "Checklist") {
            curObj.showCreateChild = true;
            curObj.showAddParent = true;
            curObj.showRemoveNode = false;
          } else if (
            selNodeAttr.type !== "Others" ||
            selNodeAttr.type !== "Child"
          ) {
            curObj.showCreateChild = false;
            curObj.showAddParent = false;
            curObj.showRemoveNode = true;
          }
        });

      curObj.treeObject.off("dblclick").on("dblclick.jstree", function (e) {
        var instance = $.jstree.reference(this),
          node = instance.get_node(e.target);
        // curObj.treeObject.jstree().edit(node);
        curObj.treeObject.jstree().edit(node, null, function (node, status) {
          curObj.lastNodeId = curObj.getTreeData().length;
          curObj.nodeSelected.emit(node);
          curObj.ShowLoadedData();

          console.log("node", node);
        });
      });
      curObj.treeObject.on("select_node.jstree", function (e, data) {
        curObj.nodeSelectedEvent(data.node);
      });
    });
  }

  createChild() {
    var curObj = this;
    var selNode = curObj.treeObject.jstree("get_selected");
    curObj.childIterator = curObj.childIterator + 1;
    var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
    if (selNodeAttr.type === "Checklist") {
      var node = curObj.treeObject.jstree().create_node(
        selNode[0],
        {
          id: String(curObj.lastNodeId + 1),
          text: "Child -" + curObj.childIterator,
          type: "Child",
        },
        "last",
        function () {}
      );
      curObj.showCreateChild = false;
      curObj.showAddParent = false;
      curObj.showRemoveNode = false;
      curObj.treeObject.jstree().edit(node, null, function (node, status) {
        curObj.lastNodeId = curObj.getTreeData().length;
      });
    }
  }

  getTreeData() {
    var gData = this.treeObject.jstree(true).get_json("#", { flat: true });
    return gData;
  }

  getTreeDataBuild(treeObj) {
    this.treeData = treeObj;
    var gData = this.treeObject.jstree(true).get_json("#", { flat: true });
    return gData;
  }

  nodeSelectedEvent(node) {
    this.nodeSelected.emit(node);
  }

  ShowLoadedData() {
    this.loadedData.emit(this.getTreeData());
  }

  AddRootNode() {
    var curObj = this;
    curObj.parentIterator = curObj.parentIterator + 1;
    curObj.curEvent = "AddRootNode";
    this.selectedTreeData = this.getTreeData();
    var newtreeData = [];
    this.selectedTreeData.forEach(function (value: any) {
      var id = String(parseInt(value.id) + 1);
      var parent =
        value.parent === "#" ? "1" : String(parseInt(value.parent) + 1);
      newtreeData.push(
        curObj.generateDataObject(id, parent, value.text, value.type)
      );
    });
    newtreeData.unshift({
      id: "1",
      parent: "#",
      text: "Parent-" + curObj.parentIterator,
      type: "Others",
    });
    curObj.treeObject.jstree(true).settings.core.data = newtreeData;

    curObj.treeObject.jstree(true).refresh();
  }

  RemoveNode() {
    var curObj = this;
    curObj.curEvent = "removeNode";
    var selNode = curObj.treeObject.jstree("get_selected");
    var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
    if (selNodeAttr.type !== "Checklist") {
      if (selNodeAttr.type === "Child") {
        curObj.treeObject.jstree(true).delete_node(selNode);
      } else {
        this.selectedTreeData = this.getTreeData();
        this.selectedTreeData = this.selectedTreeData.filter(function (
          obj: any
        ) {
          return obj.id !== selNodeAttr.id;
        });
        var newtreeData = [];
        this.selectedTreeData.forEach(function (value: any, index: number) {
          var id = "";
          var parent = "";
          if (value.type === "Child") {
            id = String(value.id - 1);
            parent = String(value.parent - 1);
          } else {
            var id = String(index + 1);
            var parent = index === 0 ? "#" : String(index);
          }
          newtreeData.push(
            curObj.generateDataObject(id, parent, value.text, value.type)
          );
        });
        curObj.treeObject.jstree(true).settings.core.data = newtreeData;
        curObj.treeObject.jstree(true).refresh();
      }
    }
  }

  generateDataObject(id: string, parent: string, text: string, type: string) {
    return {
      id: id,
      parent: parent,
      type: type,
      text: text,
    };
  }
}
