import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TreeviewstructureComponent } from './treeviewstructure.component';

describe('TreeviewstructureComponent', () => {
  let component: TreeviewstructureComponent;
  let fixture: ComponentFixture<TreeviewstructureComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TreeviewstructureComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TreeviewstructureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
