import {
  Component,
  OnInit,
  AfterViewInit,
  Input,
  Output,
  EventEmitter,
  OnChanges,
} from "@angular/core";
import { DataService } from "../../treeservices/dataservice";
declare var $: any;
@Component({
  selector: "app-treeviewstructure",
  templateUrl: "./treeviewstructure.component.html",
  styleUrls: ["./treeviewstructure.component.scss"],
})
export class TreeviewstructureComponent
  implements OnInit, AfterViewInit, OnChanges {
  @Input() ChecklistName: string;
  @Input() jsonData: Array<object>;
  @Input() updatetree;
  @Input() scrollType: boolean;
  @Input() treeType: string;
  @Input() showButtons: boolean;
  @Input() EditMode: boolean;
  @Output() nodeSelected = new EventEmitter();
  @Output() loadedData = new EventEmitter();

  showAddParent = false;
  showCreateChild = false;
  showRemoveNode = false;
  treeData: Array<object> = [];
  lastNodeId = 0;
  curEvent = "";
  treeObject: any;
  RootNode;
  parentIterator = 0;
  childIterator = 0;
  removedelete = true;
  header: boolean;

  constructor(private sds: DataService) {}

  ngOnInit() {
    this.sds.displayHeaderBuildTemplate.subscribe((header) => {
      this.header = header;
    });
    this.treedata();
  }
  ngOnChanges() {
    console.log("datain tree", this.jsonData);
    this.treedata();
  }

  treedata() {
    if (this.jsonData === undefined && this.ChecklistName !== "") {
      this.treeData.push({
        id: "1",
        parent: "#",
        type: "Project",
        text: this.ChecklistName,
      });
    } else {
      this.treeData = this.jsonData;
      this.lastNodeId = this.treeData.length;
    }
  }
  updategrid(data) {
    if (!!data) {
      this.treeObject.jstree(true).settings.core.data = data;
    } else {
      this.treeObject.jstree(true).settings.core.data = this.jsonData;
    }
    this.treeObject.jstree(true).refresh();
  }

  ngAfterViewInit() {
    var curObj = this;
    curObj.treeObject = $("#tree1");
    console.log(curObj.treeObject, "treeStructre");
    $(function () {
      $("#tree1").tooltip();
      $("#tree1")
        .jstree({
          core: {
            check_callback: true,
            data: curObj.treeData,
          },
          types: {
            default: {
              icon: "fa fa-folder",
            },
            Project: {
              icon: "fa fa-folder",
            },
            Others: {
              icon: "fa fa-cube",
            },
            Child: {
              icon: "fa fa-file-text-o",
            },
          },
          plugins: ["types", "search", "contextmenu"],
          contextmenu: {
            items: function ($node) {
              var tree = $("#trees").jstree(true);
              return {
                Create: {
                  separator_before: false,
                  separator_after: false,
                  label: "ADD",
                  icon: "fa fa-plus-circle",
                  action: function (obj) {
                    this.create(obj);
                  },
                },
                Rename: {
                  separator_before: false,
                  separator_after: false,
                  label: "Edit",
                  icon: "fa fa-pencil",
                  action: function (obj) {
                    tree.edit($node);
                  },
                },
                Remove: {
                  separator_before: false,
                  separator_after: false,
                  label: "Delete",
                  icon: "fa fa-trash",
                  action: function (obj) {
                    tree.delete_node($node);
                  },
                },
              };
            },
          },
        })
        .bind("loaded.jstree", function (event, data) {
          curObj.treeObject.jstree("open_all");
          curObj.lastNodeId = curObj.getTreeData().length;
        })
        .bind("create.jstree", function (e, data) {
          var curObj = this;
          var jsonNodes = curObj.treeObject
            .jstree(true)
            .get_json("#", { flat: true });
          var selNodeAttr = jsonNodes.find((o) => o.type === "Project");
          //  var selNode = curObj.treeObject.jstree('get_selected');
          curObj.childIterator = curObj.childIterator + 1;
          // var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
          if (selNodeAttr.type === "Project") {
            var node = curObj.treeObject.jstree().create_node(
              selNodeAttr.id,
              {
                id: String(curObj.lastNodeId + 1),
                text: "Child -" + curObj.childIterator,
                type: "Child",
              },
              "last",
              function () {}
            );
            curObj.showCreateChild = false;
            curObj.showAddParent = false;
            curObj.showRemoveNode = false;
            curObj.treeObject
              .jstree()
              .edit(node, null, function (node, status) {
                curObj.lastNodeId = curObj.getTreeData().length;
              });
          }
        })
        .bind("hover_node.jstree", function (event, data) {
          $("#" + data.node.id).prop("title", data.node.text);
        })
        .bind("refresh.jstree", function (event, data) {
          curObj.treeObject.jstree("open_all");
          if (curObj.curEvent === "AddRootNode") {
            var rootNode = curObj.treeObject.jstree(true).get_node("1");
            curObj.treeObject.jstree().edit(rootNode);
          }
          curObj.lastNodeId = curObj.getTreeData().length;
          curObj.showCreateChild = false;
          curObj.showAddParent = false;
          curObj.showRemoveNode = false;
        })
        .on("click", ".jstree-anchor", function (e) {
          var selNode = curObj.treeObject.jstree("get_selected");
          var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
          if (selNodeAttr.type === "Project") {
            curObj.showCreateChild = true;
            curObj.showAddParent = true;
            curObj.showRemoveNode = false;
          } else if (
            selNodeAttr.type !== "Others" ||
            selNodeAttr.type !== "Child"
          ) {
            curObj.showCreateChild = false;
            curObj.showAddParent = false;
            curObj.showRemoveNode = true;
          }
        });

      curObj.treeObject.off("dblclick").on("dblclick.jstree", function (e) {
        var instance = $.jstree.reference(this),
          node = instance.get_node(e.target);
        curObj.treeObject.jstree().edit(node);

        curObj.treeObject.jstree().edit(node, null, function (node, status) {
          curObj.lastNodeId = curObj.getTreeData().length;
          curObj.nodeSelected.emit(node);
          console.log("node", node);
        });
      });
      curObj.treeObject.on("select_node.jstree", function (e, data) {
        curObj.nodeSelectedEvent(data.node);
      });
    });
  }

  createChild() {
    var curObj = this;
    var jsonNodes = curObj.treeObject
      .jstree(true)
      .get_json("#", { flat: true });
    var selNodeAttr = jsonNodes.find((o) => o.type === "Project");
    //  var selNode = curObj.treeObject.jstree('get_selected');
    curObj.childIterator = curObj.childIterator + 1;
    // var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
    if (selNodeAttr.type === "Project") {
      var node = curObj.treeObject.jstree().create_node(
        selNodeAttr.id,
        {
          id: String(curObj.lastNodeId + 1),
          text: "Child -" + curObj.childIterator,
          type: "Child",
        },
        "last",
        function () {}
      );
      curObj.showCreateChild = false;
      curObj.showAddParent = false;
      curObj.showRemoveNode = false;
      curObj.treeObject.jstree().edit(node, null, function (node, status) {
        curObj.lastNodeId = curObj.getTreeData().length;
      });
    }
  }

  getTreeData() {
    var gData = this.treeObject.jstree(true).get_json("#", { flat: true });
    return gData;
  }

  nodeSelectedEvent(node) {
    this.nodeSelected.emit(node);
  }

  ShowLoadedData() {
    this.loadedData.emit(this.getTreeData());
  }

  AddRootNode() {
    var curObj = this;
    curObj.parentIterator = curObj.parentIterator + 1;
    curObj.curEvent = "AddRootNode";
    this.treeData = this.getTreeData();
    var newtreeData = [];
    this.treeData.forEach(function (value: any) {
      var id = String(parseInt(value.id) + 1);
      var parent =
        value.parent === "#" ? "1" : String(parseInt(value.parent) + 1);
      newtreeData.push(
        curObj.generateDataObject(id, parent, value.text, value.type)
      );
    });
    newtreeData.unshift({
      id: "1",
      parent: "#",
      text: "Parent-" + curObj.parentIterator,
      type: "Others",
    });
    curObj.treeObject.jstree(true).settings.core.data = newtreeData;

    curObj.treeObject.jstree(true).refresh();
  }

  RemoveNode() {
    var curObj = this;
    curObj.curEvent = "removeNode";
    var selNode = curObj.treeObject.jstree("get_selected");
    var selNodeAttr = curObj.treeObject.jstree(true).get_node(selNode);
    if (selNode.length !== 0) {
      if (selNodeAttr.type !== "Project") {
        if (selNodeAttr.type === "Child") {
          curObj.treeObject.jstree(true).delete_node(selNode);
        } else {
          this.treeData = this.getTreeData();
          this.treeData = this.treeData.filter(function (obj: any) {
            return obj.id !== selNodeAttr.id;
          });
          var newtreeData = [];
          this.treeData.forEach(function (value: any, index: number) {
            var id = "";
            var parent = "";
            if (value.type === "Child") {
              id = String(value.id - 1);
              parent = String(value.parent - 1);
            } else {
              var id = String(index + 1);
              var parent = index === 0 ? "#" : String(index);
            }
            newtreeData.push(
              curObj.generateDataObject(id, parent, value.text, value.type)
            );
          });
          curObj.treeObject.jstree(true).settings.core.data = newtreeData;
          curObj.treeObject.jstree(true).refresh();
        }
      }
    }
  }

  reportMenu(node) {
    alert("Node id " + node.id);
    // build your menu depending on node id
    return {
      createItem: {
        label: "Create New Branch",
        action: function (obj) {
          this.create(obj);
          alert(obj.text());
        },
        class: "class",
      },
      renameItem: {
        label: "Rename Branch",
        action: function (obj) {
          this.rename(obj);
        },
      },
      deleteItem: {
        label: "Remove Branch",
        action: function (obj) {
          this.remove(obj);
        },
      },
    };
  }

  generateDataObject(id: string, parent: string, text: string, type: string) {
    return {
      id: id,
      parent: parent,
      type: type,
      text: text,
    };
  }
  filterTree(data) {
    if (!!data) {
      this.treeObject.jstree("close_all");
      this.treeObject.jstree(true).search(data);
    } else {
      this.treeObject.jstree("open_all");
    }
  }
}
