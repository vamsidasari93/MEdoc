import { MatSnackBar } from "@angular/material/snack-bar";
import {
  Component,
  OnInit,
  SimpleChanges,
  EventEmitter,
  OnChanges,
  Output,
} from "@angular/core";
import * as _ from "lodash";
import { SharedDataService } from "../treeservices/shareddataservice";
import { BuildProjectTeamsService } from "../treeservices/buildProjTeamsService";
import { AdminService } from "src/app/Services/admin.service";
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  selector: "app-orgstructure",
  templateUrl: "./orgstructure.component.html",
  styleUrls: ["./orgstructure.component.scss"],
})
export class OrgstructureComponent implements OnInit, OnChanges {
  editedOrgData: any;
  organizationTree: any[];
  highestOrgValue: number = 0;
  updatetree = true;
  orgData: any;
  showupdatetree = true;
  createdby: any;
  curretnEditTreeData: any;
  existeddata: any[] = [];
  newnodes = [];
  saveOrgArray: any[];
  modifiedid: any;
  treeresult: any;
  @Output() treeData = new EventEmitter();
  @Output() refreshTable = new EventEmitter();
  existdataTree: boolean = false;
  refreshContainer = true;
  constructor(
    private sds: SharedDataService,
    private adminservice: AdminService,
    private _snackBar: MatSnackBar,
    private spinner: NgxSpinnerService
  ) {
    var userid = JSON.parse(localStorage.getItem("userinfo"));
    this.createdby = userid.userId;
  }

  ngOnInit() {
    const orgSaved = this.sds.getOption()["orgData"];
    this.getOrgStructure();
  }
  ngOnChanges(changes: SimpleChanges) {
    console.log("ngchanges", this.modifiedid);
    const modifiedarray = [];
    let modifiedtreedata = this.modifiedid.map((mid) => {
      this.existeddata.map((exid) => {
        if (
          exid.organizationHierarchyId === mid.organizationHierarchyId &&
          exid.text !== mid.text
        ) {
          modifiedarray.push(mid);
        }
        return exid;
      });
      return mid;
    });
    console.log("kids", modifiedarray);
  }
  /**
   * @event  getOrgStructure()
   * @description existed tree data
   */
  getOrgStructure() {
    const orgId = 1;
    this.organizationTree = [];
    this.refreshContainer = false;
    this.spinner.show();
    this.adminservice.getOrgHierarchy().subscribe((orgStructure: any) => {
      this.existeddata = orgStructure.result;
      this.treeData.emit(this.existeddata);
      if (orgStructure.result.length > 0) {
        this.existdataTree = true;
        this.orgData = orgStructure.result;
        this.orgData.map((eachBuild) => {
          const teamsClass = {
            id: eachBuild.organizationHierarchyId,
            parent:
              eachBuild.parentId === null || eachBuild.parentId === 0
                ? "#"
                : eachBuild.parentId,
            text: eachBuild.name,
            type: eachBuild.orgHierTypName,
          };
          this.organizationTree.push(teamsClass);
        });
      }
      this.editedOrgData = this.organizationTree;
      this.refreshContainer = true;
      this.spinner.hide();
      const orgArr = [];
      this.orgData.map((eachM) => {
        orgArr.push(eachM.organizationHierarchyId);
      });
      this.highestOrgValue = Math.max(...orgArr);
    });
  }
  /**
   * @event  removedTreeIds()
   * @description remove tree
   * @parameter data
   */
  removedTreeIds(data) {
    let deleteArr: any = [];
    if (data.length != 0) {
      data.map((deletedIds) => {
        this.existeddata.map((deleteObj) => {
          if (deleteObj.organizationHierarchyId === deletedIds) {
            deleteObj.state = "REMOVED";
            deleteArr.push(deleteObj);
          }
          return deleteObj;
        });
        return deletedIds;
      });
      this.adminservice.deleteOrganisationHierarchy(deleteArr).subscribe(
        resp => {
          for (const key in resp.result) {
            if (resp.result[key] === 'Successfully Removed') {
              this.openSnackBar('Successfully Removed');
              this.getOrgStructure();
              this.refreshTable.emit();
            } else {
              this.openSnackBar('Failed to delete, Already workspace mapped')
            }
          }
        }
      )
    }

    // this.sds.treeupdatedData(this.existeddata);
    // this.treeData.emit(this.existeddata);
  }
  /**
   * @event  getLoadedOrgData()
   * @description updated tree data
   * @parameter data
   */
  getLoadedOrgData(data) {
    this.saveOrgArray = [];
    this.modifiedid = data.map((eachelement) => {
      if (eachelement && eachelement.id) {
        eachelement.id = Number(eachelement.id);
      }
      return eachelement;
    });
    const modifiedarray = [];
    let modifiedtreedata = this.modifiedid.map((mid) => {
      this.existeddata.map((exid) => {
        if (exid.organizationHierarchyId === mid.id && exid.name !== mid.text) {
          modifiedarray.push(mid);
        }
        return exid;
      });
      return mid;
    });

    if (modifiedarray && modifiedarray.length) {
      this.treesavedforAPI(modifiedarray, "edit");
    }
    this.treeresult = this.modifiedid.filter(
      (o1) =>
        !this.existeddata.some((o2) => o1.id === o2.organizationHierarchyId)
    );

    if (this.treeresult && this.treeresult.length) {
      this.treesavedforAPI(this.treeresult, "add");
    }
  }
  /**
   * @event  treesavedforAPI
   * @description saving tree data
   * @parameter data, type
   */
  treesavedforAPI(data: any, type: any) {
    data.map((eachOrg, index) => {
      if (eachOrg.parent === "#" || eachOrg.parent === "Organisation") {
        eachOrg.levelId = 0;
        eachOrg.orgHierTypeId = 1;
      }
      if (eachOrg.type === "Project") {
        eachOrg.levelId = 2;
        eachOrg.orgHierTypeId = 3;
      }
      if (eachOrg.type === "Others") {
        eachOrg.levelId = 1;
        eachOrg.orgHierTypeId = 2;
      }

      const saveOrgObj = {
        organizationHierarchyId: eachOrg.organizationHierarchyId
          ? eachOrg.organizationHierarchyId
          : eachOrg.id,
        isNewRecord: eachOrg.isNewRecord,
        name: eachOrg.text,
        parentId: eachOrg.parent != "#" ? Number(eachOrg.parent) : 0,
        createdBy: this.createdby,
        updatedBy: this.createdby,
        orgHierTypeId: eachOrg.orgHierTypeId ? eachOrg.orgHierTypeId : 0,
        orgHierTypName:
          eachOrg.type == "default" ? "Organisation" : eachOrg.type,
        levelId: eachOrg.levelId,
        state:
          type === "add" ||
            (eachOrg.type == "default" && eachOrg.text.length < 1)
            ? "ADDED"
            : "MODIFIED",
      };
      this.saveOrgArray.push(saveOrgObj);
      if (this.saveOrgArray && this.saveOrgArray.length > 0) {
        this.saveOrgArray.map((each) => {
          this.existeddata.map((eachE, i) => {
            if (eachE.organizationHierarchyId === each.organizationHierarchyId) {
              each['isNewRecord'] = eachE.isNewRecord;
              this.existeddata.splice(i, 1);
              return eachE;
            }
          });
          this.existeddata.push(each);
          return each;
        });
      }
      this.sds.treeupdatedData(this.existeddata);
      this.treeData.emit(this.existeddata);
    });
  }
  /**
   * @event  currentNodeSelected
   * @description selected node details
   * @parameter currentnodename
   */
  currentNodeSelected(currentnodename) {
    this.curretnEditTreeData = currentnodename;
  }
  openSnackBar(message) {
    this._snackBar.open(message, "", {
      panelClass: ["snackBar"],
      duration: 2000,
    });
  }
}
