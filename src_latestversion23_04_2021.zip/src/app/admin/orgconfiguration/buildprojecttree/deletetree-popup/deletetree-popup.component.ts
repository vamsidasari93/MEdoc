import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: "app-deletetree-popup",
  templateUrl: "./deletetree-popup.component.html",
  styleUrls: ["./deletetree-popup.component.scss"],
})
export class DeletetreePopupComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<DeletetreePopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {}
  onNoClick(): void {
    this.dialogRef.close();
  }
  cancel() {
    this.dialogRef.close();
  }
  /**
   * @event  confirm()
   * @description delete confirmation
   */
  confirm() {
    this.dialogRef.close({ data: "confirmed" });
  }
}
