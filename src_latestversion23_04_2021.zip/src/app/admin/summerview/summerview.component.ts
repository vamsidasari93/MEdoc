import { Component, OnInit } from "@angular/core";
import { MatDialog, MatSnackBar, MatTableDataSource } from "@angular/material";
import { Router } from "@angular/router";
import { NgxSpinnerService } from "ngx-spinner";
import { Subscription } from "rxjs";
import { AdminService } from "src/app/Services/admin.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { AuthenticationService } from "src/app/_services";
import { environment } from "src/environments/environment";
import { DeletetreePopupComponent } from "../orgconfiguration/buildprojecttree/deletetree-popup/deletetree-popup.component";

export interface PeriodicElement {
  companyName: string;
  departmentName: string;
  emailID: string;
  inputOptions: string;
  outputOptions: string;
  attributeOptions: string;
  projectMapped: string;
  roleNames: string;
  subDepartmentName: string;
  useCaseDescription: string;
  useCaseName: string;
  userName: string;
}

@Component({
  selector: "app-summerview",
  templateUrl: "./summerview.component.html",
  styleUrls: ["./summerview.component.scss"],
})
export class SummerviewComponent implements OnInit {
  public displayedColumns: string[] = [
    "companyName",
    "departmentName",
    "subDepartmentName",
    "roleNames",
    "userName",
    "emailID",
    "projectMapped",
    "inputOptions",
    "outputOptions",
    "attributeOptions",
  ];
  public summaryList: Array<any> = [];
  public workspaceList: Array<any> = [];
  public selectedCompany: any;
  public selectedWorkspace = '';
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  createdby: any;
  summaryData: any;
  show: boolean = false;
  userInfo: any;
  private subscription: Subscription = new Subscription();
  public dynamicRouterURL: any;
  constructor(
    private ads: AdminService,
    private _snackBar: MatSnackBar,
    private PdfserviceService: PdfserviceService,
    private spinner: NgxSpinnerService,
    private authenticationService: AuthenticationService,
    private router: Router,
    private dialog: MatDialog
  ) {
    this.userInfo = JSON.parse(localStorage.getItem("userinfo"));
    this.createdby = this.userInfo.userId;
  }

  ngOnInit() {
    this.PdfserviceService.annotation("admin");
    this.getWorkspaceList();
    this.PdfserviceService.getNavigateAdmin.subscribe((resp:any) => {
      this.dynamicRouterURL = resp;
      if (resp && resp.previous == '/Admin/Summaryview') {
        this.router.navigateByUrl(this.dynamicRouterURL.current);
        // this.subscription.unsubscribe();
      }
    })
  }

  getWorkspaceList() {
    this.ads.projectNamelist('').subscribe((resp) => {
      this.workspaceList = resp;
      this.selectedWorkspace = this.workspaceList[0].useCaseID;
      this.getSummarydata();
    });
  }
  /**
   * @event getSummarydata()
   * @description get summary data
   */
  getSummarydata() {
    this.dataSource.data = [];
    this.spinner.show();
    this.ads.GetSummary(this.selectedWorkspace).subscribe((data) => {
      if (data.length > 0) {
        this.show = true;
      }
      this.summaryList = data;
      this.selectedCompany = this.summaryList[0];
      let summaryData = [];
      for (let i = 0; i < data.length; i++) {
        for (let j = 0; j < data[i].departmentData.length; j++) {
          var item = data[i].departmentData[j];
          var summary = {
            companyName: item.companyName,
            departmentName: item.departmentName,
            subDepartmentName: item.subDepartmentName,
            roleNames: item.roleNames,
            userName: item.userName,
            emailID: item.emailID,
            attributeOptions: item.attributeOptions,
            projectMapped: item.projectMapped,
            inputOptions: item.inputOptions,
            outputOptions: item.outputOptions,
          };
          summaryData.push(summary);
        }
      }

      this.dataSource.data.push(...summaryData);
      this.dataSource.data = [...this.dataSource.data];
      this.spinner.hide();
    },
      error => {
        this.spinner.hide();
      });
  };
  selectCompany(item) {
    this.selectedCompany = item;
  }
  downloadFile() {
    const link = document.createElement("a");
    link.setAttribute("href", `${environment.apiUrl}/OrgSetup/DownloadSummaryDetails?userId=${this.userInfo.userId}&usecaseid=${this.selectedWorkspace}`);
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => {
      this.openSnackBar('downloaded successfully');
    }, 3000)
    // window.location.href = `${environment.apiUrl}/OrgSetup/DownloadSummaryDetails?usecaseid=${this.selectedWorkspace}`;
    // window.open(`${environment.apiUrl}/OrgSetup/DownloadSummaryDetails?usecaseid=${this.selectedWorkspace}`);
  }
  getcategory(category) {
    let refCategory = [];
    if (category == '') {
      refCategory = [];
    } else {
      let splittedCategory = category.split(',');
      splittedCategory.forEach(item => {
        let refItem = item.split('&');
        refCategory.push(`${refItem[0]} & ${refItem[1]}`);
      });
    }
    return refCategory ? refCategory : '--';
  }
  getInputConfig(category) {
    let refCategory = [];
    if (category == '') {
      refCategory = [];
    } else {
      refCategory = category.split(',');
    }
    return refCategory ? refCategory : '--';
  }
  /**
   * @event Finalsubmit()
   * @description final submit for admin module
   */
  Finalsubmit() {
    let data = {
      message: 'Are you sure you want to submit'
    }
    this.dialog.open(DeletetreePopupComponent,
      {
        data: data
      })
      .afterClosed()
      .subscribe((result) => {
        if (result.data === "confirmed") {
          this.spinner.show();
          this.ads.FinalSubmit(this.createdby).subscribe(
            (result: any) => {
              this.openSnackBar('Details submitted successfully');
              this.spinner.hide();
              setTimeout(() => {
                this.router.navigate(["/Admin"]);
              }, 1100)
            }, error => {
              this.openSnackBar('Details submitted successfully');
              this.spinner.hide();
              setTimeout(() => {
                this.router.navigate(["/Admin"]);
              }, 1100)
            });
        }
      });
  }
  openSnackBar(message) {
    this._snackBar.open(message, "", {
      duration: 1000,
      panelClass: ["snackBar"],
    });
  }
  ngOnDestroy(){
    this.subscription.unsubscribe();
  }
}
let ELEMENT_DATA = [];
