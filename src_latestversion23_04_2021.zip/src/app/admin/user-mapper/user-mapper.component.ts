import { MatSnackBar } from "@angular/material/snack-bar";
import { Component, OnInit, ViewEncapsulation, ViewChild } from "@angular/core";
import { take } from "rxjs/operators";
import { BuildprojecttreeComponent } from "../orgconfiguration/buildprojecttree/buildprojecttree.component";
import { SharedDataService } from "../orgconfiguration/treeservices/shareddataservice";
import { BuildProjectTeamsService } from "../orgconfiguration/treeservices/buildProjTeamsService";
declare var $: any;

@Component({
  selector: "app-user-mapper",
  templateUrl: "./user-mapper.component.html",
  styleUrls: ["./user-mapper.component.scss"],
  encapsulation: ViewEncapsulation.None,
})
export class UserMapperComponent implements OnInit {
  @ViewChild(BuildprojecttreeComponent, { static: false })
  tvc: BuildprojecttreeComponent;
  orgData: any;
  userRoleData = [];
  userRoleInc = 1;
  roleCount = 0;
  userRoleCount: number;
  formCount = 0;
  summarysection: number;
  selectedstate: any;
  selectedvalue: any;
  userRoleDataid: any;
  selcteddata: any;
  newArray = [];
  finaloutput: any[];
  userRoleMainArray = [];
  userRoleMainArray2 = [];
  shareddata: any;
  userroles;
  filteredarray = [];
  userrolesarray = [];
  usersarray = [];
  userdropdown: any;
  selectedOptions: any;
  selecteddropdown = [];
  filteredarraty: any[];
  rolesById = [];
  selectedid: any;
  currentnodeselections: any[];
  filtereddata = [];
  currentnodefilterdata: any;
  filterselectedarray: any;
  defaultvalue: string;
  increment;
  allUsers: any;
  selectedNode: any;
  rolesArray: any;
  usersArray: any;
  currentNodeName: any;
  mappedRoles: any;
  mappedRoleUserArray: any;
  unmappedRolesArray: any;
  selectedRole: any;
  selectedItems = [];
  dropdownSettings = {};
  requiredField = false;
  disableAdd: boolean;
  selectedUserMapArray: any[];

  constructor(
    private sds: SharedDataService,
    private projectService: BuildProjectTeamsService,
    private snackbar: MatSnackBar
  ) {}

  ngOnInit() {
    this.orgData = this.sds.getOption()["orgData"];
    this.userRoleData.push({ Name: "userRole_1", id: 1 });
    const roleData = this.sds.getOption()["roleData"];
    this.roleCount = roleData === undefined ? 0 : roleData.length;
    const userRoleData = this.sds.getOption()["userRole"];
    this.userRoleCount = userRoleData === undefined ? 0 : userRoleData.length;
    const formData = this.sds.getOption()["form"];
    this.formCount = formData === undefined ? 0 : formData.length;
    this.userRoleData = userRoleData === undefined ? [] : [];
    this.defaultvalue = "test";
    this.selectedItems = [];

    // this.projectService.getAllUsers().subscribe((users) => {
    // if (users && users.data && users.status === "Success") {
    //   this.usersarray = users.data;
    //   this.userdropdown = this.usersarray;
    //   if (this.userdropdown && this.userdropdown.length) {
    //     this.userdropdown.map((eachUser) => {
    //       eachUser.fullName = eachUser.firstName + " " + eachUser.lastName;
    //       return eachUser;
    //     });
    //   }
    //   console.log(this.userdropdown);
    //   // this.userRoleCount = this.userdropdown.length;
    // }
    // });

    this.dropdownSettings = {
      singleSelection: false,
      idField: "userId",
      textField: "fullName",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      itemsShowLimit: 1,
      allowSearchFilter: true,
    };
    this.setStatus();
  }

  setStatus() {
    this.selectedItems.length > 0
      ? (this.requiredField = true)
      : (this.requiredField = false);
  }

  onItemSelect(item: any, role: any) {
    this.selectedUserMapArray = [];
    this.setClass();
    this.selectedItems.push(item);
    this.selectedUserMapArray.push(role);
    console.log(this.selectedItems, this.selectedUserMapArray);
  }
  onSelectAll(items: any) {
    this.setClass();
    this.selectedItems = items;
  }

  setClass() {
    this.setStatus();
    if (this.selectedItems.length > 0) {
      return "validField";
    } else {
      return "invalidField";
    }
  }

  currentNodeSelected(currentnode) {
    if (currentnode.state.selected === true) {
      this.selectedid = currentnode.id;
      this.selectedNode = currentnode;
      this.currentNodeName = currentnode.text;
      this.filterselectedarray = [];
      this.currentnodefilterdata = [];
      // this.projectService
      //   .getUserRoleByOrgHierarchyId(currentnode.id)
      //   .subscribe((mapRoles) => {
      //     if (mapRoles && mapRoles.data && mapRoles.status === "Success") {
      //       this.mappedRoles = mapRoles.data;
      //       this.mappedRoleUserArray = [];
      //       this.unmappedRolesArray = [];
      //       if (this.mappedRoles && this.mappedRoles.length > 0) {
      //         this.mappedRoles.map((eachRole) => {
      //           if (eachRole.orgRolesUser && eachRole.orgRolesUser.length > 0) {
      //             this.mappedRoleUserArray.push(eachRole);
      //           } else {
      //             this.unmappedRolesArray.push(eachRole);
      //           }
      //         });
      //       }
      //       if (this.mappedRoleUserArray && this.mappedRoleUserArray.length) {
      //         this.mappedRoleUserArray.map((eachMapped) => {
      //           if (eachMapped.orgRolesUser && eachMapped.orgRolesUser.length) {
      //             eachMapped.users = [];
      //             eachMapped.orgRolesUser.map((eachRoleUser) => {
      //               eachMapped.users.push(eachRoleUser.user);
      //               eachRoleUser.user.fullName =
      //                 eachRoleUser.user.firstName +
      //                 " " +
      //                 eachRoleUser.user.lastName;
      //               return eachRoleUser;
      //             });
      //           }
      //         });
      //       }
      //       this.disableAdd = this.unmappedRolesArray.length < 1;
      //       console.log(this.mappedRoleUserArray);
      //       this.userRoleCount = this.mappedRoleUserArray
      //         ? this.mappedRoleUserArray.length
      //         : 0;
      //     }
      //   });

      // this.projectService
      //   .getRoleByOrgHierarchy(currentnode.id)
      //   .subscribe((teams) => {
      //     if (teams && teams.data && teams.status === "Success") {
      //       this.rolesArray = teams.data;
      //       this.userrolesarray = this.rolesArray;
      //       this.roleCount = this.userrolesarray
      //         ? this.userrolesarray.length
      //         : 0;
      //     }
      //   });
      this.getUserRoleData(currentnode.id);
    }
  }

  addTable() {
    if (
      this.unmappedRolesArray &&
      (this.unmappedRolesArray.length === 0 ||
        this.unmappedRolesArray.length === 1)
    ) {
      this.disableAdd = true;
    } else {
      this.disableAdd = false;
    }
    this.plusEventSelected(this.selectedNode);
  }

  selectedValue(event: any, value: any, index: number, obj: any, role: any) {
    this.selectedRole = role;
    if (
      this.unmappedRolesArray &&
      (this.unmappedRolesArray.length === 0 ||
        this.unmappedRolesArray.length === 1)
    ) {
      this.disableAdd = true;
    }
    this.selecteddropdown = role.orgRolesUser ? role.orgRolesUser : [];
    if (value === "Role") {
      const roleObj = this.rolesArray.find(
        (eachRoleObj) =>
          eachRoleObj.orghierarchyRolesName === role.orghierarchyRolesName
      );
      role.orghierarchyRolesName = roleObj.orghierarchyRolesName;
      role.orgHierarchyId = roleObj.orgHierarchyId;
      role.orgHierarchyRolesId = roleObj.orgHierarchyRolesId;
      role.orgRolesUser = roleObj.orgRolesUser;
      this.mappedRoleUserArray[index] = role;
    }
  }

  plusEventSelected(node: any) {
    const addRole = {
      orgHierarchyId: 0,
      orgHierarchyRolesId: 0,
      orgRolesUser: [],
      orghierarchyRolesName: "",
      state: "ADDED",
      createdBy: 0,
      updatedBy: 0,
    };
    this.mappedRoleUserArray.push(addRole);
    this.userRoleCount = this.mappedRoleUserArray.length;
    //  this.currentnodeselections = this.filteredarray.filter(item => item.id === node.id);
    if (
      this.filteredarray &&
      this.filteredarray.filter(
        (item) => item.orgHierarchyRolesId === this.selectedid
      ).length
    ) {
      //  this.filterselectedarray = this.userrolesarray;
      this.filteredarray.forEach((element) => {
        if (element.id === this.selectedid) {
          this.currentnodefilterdata = this.filterselectedarray.filter(
            (item) => item.orghierarchyRolesName !== element.value
          );
          this.filterselectedarray = this.currentnodefilterdata;
        }
      });
    } else {
      const addRole = {
        orgHierarchyId: 0,
        orgHierarchyRolesId: 0,
        orgRolesUser: [],
        orghierarchyRolesName: "",
        state: "ADDED",
        createdBy: 0,
        updatedBy: 0,
      };
      this.filteredarray.push(addRole);
    }
    const saveUser = {
      orgHierarchyId: 0,
      orgHierarchyRolesId: 0,
      orgRolesUser: 0,
      orghierarchyRolesName: "",
      state: "ADDED",
      createdBy: 0,
      updatedBy: 0,
    };
    this.userRoleMainArray.push({
      Name: "userRole-" + this.userRoleInc,
      id: node.id,
      userrole:
        this.currentnodefilterdata == undefined
          ? this.userrolesarray
          : this.currentnodefilterdata,
    });
    this.sds.setOption("userRole", this.userRoleMainArray);
    this.getUserRoleData(node.id);
  }

  getUserRoleData(getId: number) {
    this.shareddata = this.sds.getOption()["userRole"];
    this.userRoleMainArray =
      this.shareddata === undefined ? [] : this.shareddata;
    this.sds.setOption("userRole", this.userRoleMainArray);
    if (!!this.shareddata) {
      this.userRoleData = this.userRoleMainArray.filter(
        (item) => item.id === getId
      );
      this.userRoleCount = this.userRoleData.length;
    }
    console.log(" this.userRoleData", this.userRoleData);
  }

  ngAfterViewChecked() {
    $(".bs-ms-user").selectpicker();
  }

  deleteUserRole(event: any, index: number) {
    if (event === 0) {
      this.mappedRoleUserArray.splice(index, 1);
    } else {
    }
    // this.userRoleData.splice(this.userRoleData.findIndex(x => x.id === event), 1);
    // this.userRoleMainArray.splice(this.userRoleMainArray.findIndex(x => x.id === event), 1);
    // this.userRoleCount = this.userRoleData === undefined ? 0 : this.userRoleData.length;
    // this.sds.setOption('userRole', this.userRoleMainArray);
  }

  saveUser() {
    console.log(this.selectedItems, this.mappedRoleUserArray);
    const selectedUsersMap = [];
    if (this.selectedUserMapArray && this.selectedUserMapArray.length > 0) {
      this.selectedUserMapArray.map((eachSeleUser) => {
        eachSeleUser.users.map((eachuser) => {
          const selectedUser = this.usersarray.find(
            (eachu) => eachu.userId === eachuser.userId
          );
          const userSendObj = {
            orgRolesUserId: 0,
            orgRolesId: eachSeleUser.orgHierarchyId,
            userId: selectedUser.userId,
            user: {
              userId: selectedUser.userId,
              firstName: selectedUser.firstName,
              lastName: selectedUser.lastName,
              createdBy: 1,
              updatedBy: 1,
            },
            state: "ADDED",
          };
          selectedUsersMap.push(userSendObj);
        });
        console.log(selectedUsersMap);
      });
      // this.projectService
      //   .saveRoleUserMapping(selectedUsersMap)
      //   .subscribe((successRole) => {
      //     if (successRole && successRole.status === "Success") {
      //       this.snackbar.open(successRole.message, "", {
      //         duration: 3000,
      //         panelClass: ["success-snackbar"],
      //       });
      //     }
      //   });
    }
  }
}
