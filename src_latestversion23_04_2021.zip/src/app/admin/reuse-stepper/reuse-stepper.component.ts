import { Component, OnInit, Input, SimpleChanges } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";

@Component({
  selector: "app-reuse-stepper",
  templateUrl: "./reuse-stepper.component.html",
  styleUrls: ["./reuse-stepper.component.scss"],
})
export class ReuseStepperComponent implements OnInit {
  selectedtab: any;
  previousRoute='';
  activatedRouterName = '/Admin';
  constructor(private activatedRoute : ActivatedRoute,private router : Router,private subjectService : PdfserviceService) {
    this.activatedRoute.url.subscribe(activeUrl =>{
      this.activatedRouterName=window.location.pathname;
    });
  }

  ngOnInit() {
    this.previousRoute = this.router.url;
    // this.activatedRouterName = this.router.url;
    // console.log("inbuilstemplate stepper", this.step4);
  }
  ngOnChanges(changes: SimpleChanges) {
    // console.log("inbuilstemplate stepper", this.step4);
  }

  navigateValidation(url){
    // this.activatedRouterName = url;
    let navigateObj = {
      previous:this.previousRoute,
      current:url
    }
    this.subjectService.setNavigateAdmin(navigateObj);
  }
  /**
   * @event tabclick()
   * @description tab click handler
   * @parameter tabid
   */
  tabclick(tabid) {
    this.selectedtab = tabid;
  }
}
