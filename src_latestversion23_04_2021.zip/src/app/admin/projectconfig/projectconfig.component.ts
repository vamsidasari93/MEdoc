import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { FormControl } from "@angular/forms";
import { MatDialog, MatSnackBar, MatTableDataSource } from "@angular/material";
import { NgxSpinnerService } from "ngx-spinner";
import { AdminService } from "src/app/Services/admin.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { AdminInfoPopupComponent } from "../admin-info-popup/admin-info-popup.component";
import { DeletetreePopupComponent } from "../orgconfiguration/buildprojecttree/deletetree-popup/deletetree-popup.component";
import { ProjectactionComponent } from "./projectaction/projectaction.component";
import * as _ from 'underscore';
import { Router } from "@angular/router";
import { Subscription } from "rxjs";

@Component({
  selector: "app-projectconfig",
  templateUrl: "./projectconfig.component.html",
  styleUrls: ["./projectconfig.component.scss"],
})
export class ProjectconfigComponent implements OnInit {
  @ViewChild("newNode", { static: false }) newNode;
  toppings = new FormControl();
  users = new FormControl();
  selected = -1;
  departmentList: any[] = [];
  savedD: any[] = [];
  public displayedColumns: any[] = [
    "companyname",
    "subdepartname",
    "orgDescription",
    "useCaseType",
    "inputopt",
    "action",
  ];
  Projectmappedlist: any[] = [];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  actions: boolean = false;
  department: any;
  organizationInputOption: any;
  desription: any;
  outputConfig: any;
  orgUseCaseId: any;
  projectmapped: any;
  orghID: any;
  orgInputOption = [];
  orgoutputOption = [];
  orgextractOption = [];
  projectConfig: any[] = [];
  usermapid: any;
  createdby: any;
  existedconfigusecase: any[] = [];
  extractConfig: any;
  private subscription: Subscription = new Subscription();
  dynamicRouterURL: any;

  constructor(
    public dialog: MatDialog,
    private ads: AdminService,
    private _snackBar: MatSnackBar,
    private PdfserviceService: PdfserviceService,
    private spinner: NgxSpinnerService,
    private router: Router
  ) {
    var userid = JSON.parse(localStorage.getItem("userinfo"));
    this.createdby = userid.userId;
  }

  ngOnInit() {
    this.PdfserviceService.annotation("admin");
    this.departmentorgList();
    this.getcofigured();
    this.subscription = this.PdfserviceService.getNavigateAdmin.subscribe((resp: any) => {
      this.dynamicRouterURL = resp;
      if (resp && resp.previous == '/Admin/projectconfig') {
        this.savedData('', 'outside');
      }
    })
  }
  // ngAfterViewInit() {
  //   console.log(this.newNode.nativeElement.focus());
  // }
  /**
   * @event getcofigured()
   * @description getting configured usecase data
   */
  getcofigured() {
    this.dataSource.data = [];
    this.ads.GetConfiguredUseCases().subscribe((data: any) => {
      this.projectConfig = data.result.reverse();
      if (this.projectConfig.length <= 0) {
        this.addrow();
      }
      for (let i = 0; i < this.projectConfig.length; i++) {
        var existedids =
          this.projectConfig[i].orgHierarchyId +
          "," +
          this.projectConfig[i].orgUseCaseName;
        this.existedconfigusecase.push(existedids.trim());
        this.orghID = this.projectConfig[i].orgHierarchyId;
        var obj = {
          companyname: this.departmentList,
          organizationHierarchyId: this.projectConfig[i].orgHierarchyId,
          subdepartname: this.projectConfig[i].orgUseCaseName,
          orgDescription: this.projectConfig[i].orgDescription,
          inputopt: false,
          orgUseCaseId: this.projectConfig[i].orgUseCaseName,
          usecasemapid: this.projectConfig[i].useCaseMappingId,
          isConfirmed: this.projectConfig[i].isConfirmed,
          orgUseCaseType: this.projectConfig[i].orgUseCaseType,
          createdBy: this.createdby,
          modifiedBy: this.createdby,
          state: "exist",

        };
        this.dataSource.data.push(obj);
        this.dataSource.data = [...this.dataSource.data];
        // this.ads
        //   .projectNamelist(this.projectConfig[i].orgHierarchyId)
        //   .subscribe((responselist) => {
        //     this.Projectmappedlist = responselist;
        //   });
      }
    });
  }
  /**
   * @event departmentorgList()
   * @description getting departmentlist in dropdown
   */
  departmentorgList() {
    this.ads.GetOrganizationList().subscribe((Dlist: any) => {
      this.departmentList = _.sortBy(Dlist, 'organizationHierarchyId');
      console.log("departmentlist", this.departmentList);
    });
  }
  /**
   * @event actionpopup()
   * @description popup of input and output options popup
   * @paremeter id, mapid,type
   */
  actionpopup(element, mapid, type) {
    let InputOption = this.projectConfig.filter(
      (x) => x.useCaseMappingId === mapid
    );
    if (InputOption.length > 0) {
      this.orgInputOption = InputOption[0].inputConfig;
      this.orgextractOption = InputOption[0].attributeConfig;
      InputOption[0].outputConfig.forEach((obj) => {
        obj.checkValue = obj.catagoriesName !== "" ? true : false;
      });
      this.orgoutputOption = InputOption[0].outputConfig;
    } else {
      this.orgInputOption = [];
      this.orgextractOption = [];
      this.orgoutputOption = [];
      let refObj = {
        useCaseMappingId: mapid,
        inputConfig: [],
        attributeConfig: [],
        outputConfig: [],
      }
      this.projectConfig.push(refObj);
    }
    if (type === "input") {
      this.dialog
        .open(ProjectactionComponent, {
          position: { top: "15%" },
          data: {
            type: type,
            orginoutput: this.orgInputOption,
          },
          width: '20%',
          disableClose: true,
          panelClass: "custom-dialog-actioninput",
        })
        .afterClosed()
        .subscribe((result) => {
          if (result && result.data) {
            this.orgInputOption = result.data;
            this.organizationInputOption = result.data;
            this.projectConfig.forEach(item => {
              if (item.useCaseMappingId === mapid) {
                item.inputConfig = result.data;
              }
            })
            if (element.usecasemapid === mapid && element.state == "exist" && element.usecasemapid !== 0) {
              element.state = "Modified";
            }
          }
        });
    } else if (type === "outputExtraction") {
      if (element.orgUseCaseType) {
        let refObj = {
          outputData: this.orgoutputOption,
          extractData: this.orgextractOption,
        };
        this.dialog
          .open(ProjectactionComponent, {
            position: { top: "15%" },
            data: {
              type: type,
              category: element.orgUseCaseType,
              orgoutputExtractOption: refObj,
            },
            width: '35%',
            disableClose: true,
            panelClass: "custom-dialog-actionoutput",
          })
          .afterClosed()
          .subscribe((result) => {
            if (result && result) {
              this.orgoutputOption = result.outputData;
              this.orgextractOption = result.extractData;
              this.outputConfig = result.outputData;
              this.extractConfig = result.extractData;
              this.projectConfig.forEach(item => {
                if (item.useCaseMappingId === mapid) {
                  item.outputConfig = result.outputData;
                  item.attributeConfig = result.extractData;
                }
              });
              if (element.usecasemapid === mapid && element.state == "exist" && element.usecasemapid !== 0) {
                element.state = "Modified";
              }
            }
          });
      } else {
        this.openSnackBar('Please select the UsecaseType');
      }
    }
    //  else {
    //   this.dialog
    //     .open(ProjectactionComponent, {
    //       position: { top: "15%" },
    //       data: {
    //         type: type,
    //         orgoutputOption: this.orgextractOption,
    //       },
    //       panelClass: "custom-dialog-actioninput",
    //     })
    //     .afterClosed()
    //     .subscribe((result) => {
    //       this.orgextractOption = result.data;
    //       if (result.data) {
    //         this.extractConfig = result.data;
    //       }
    //     });
    // }
  }
  enableactions(element) {
    for (let i = 0; i < this.dataSource.data.length; i++) {
      if (
        this.dataSource.data[i].usecasemapid === element.usecasemapid &&
        this.dataSource.data[i].organizationHierarchyId ===
        element.organizationHierarchyId
      ) {
        this.dataSource.data[i].inputopt = true;
      } else {
        // this.dataSource.data[i].inputopt = false;
      }
    }
  }

  /**
   * @event checkModifiedExistData()
   * @description existed modified in data
   * @paremeter element
   */
  checkModifiedExistData(element, type) {
    this.existedProjectids(element, type);
    for (let i = 0; i < this.dataSource.data.length; i++) {
      if (
        this.dataSource.data[i].usecasemapid === element.usecasemapid &&
        this.dataSource.data[i].state != "Added" &&
        this.dataSource.data[i].usecasemapid !== 0
      ) {
        this.dataSource.data[i].state = "Modified";
      }
    }
  }
  /**
   * @event existedProjectids()
   * @description existed project validating in data
   * @paremeter element
   */
  existedProjectids(element, type) {
    var selectedids =
      element.organizationHierarchyId + "," + element.subdepartname;
    var md = this.existedconfigusecase.includes(selectedids);
    if (md === true && type === "workspace") {
      element.subdepartname = "";
      this.openSnackBar(
        "Already data is existed. please enter different workspace name"
      );
    }
  }
  /**
   * @event savedData()
   * @description saving project info data
   */
  savedData(type, category) {
    // this.subscription.unsubscribe();
    let savedD = [];
    let refArr = [];
    let validaterow = false;
    var databody = this.dataSource.data.filter(
      (d) => d.state === "Modified" || d.state === "Added"
    );
    refArr = JSON.parse(JSON.stringify(databody))
    databody = databody.map((d) => {
      let InputOption = this.projectConfig.filter(
        (x) => x.useCaseMappingId === d.usecasemapid
      );
      return {
        useCaseMappingId: d.state === "Modified" ? d.usecasemapid : 0,
        orgHierarchyId: d.organizationHierarchyId,
        orgUseCaseName: d.subdepartname,
        orgDescription: d.orgDescription,
        orgUseCaseType: d.orgUseCaseType,
        outputConfig: InputOption.length != 0 ? InputOption[0].outputConfig : [],
        inputConfig: InputOption.length != 0 ? InputOption[0].inputConfig : [],
        attributeConfig: InputOption.length != 0 ? InputOption[0].attributeConfig : [],
        createdBy: this.createdby,
        modifiedBy: this.createdby,
        state: d.state === "Modified" ? 'UPDATE' : 'ADD'
      };
    });
    if (databody && databody.length != 0) {
      databody.map((x) => {
        if (
          x.orgUseCaseName &&
          x.orgDescription &&
          x.orgHierarchyId &&
          x.orgUseCaseType &&
          x.inputConfig.length != 0 &&
          (x.outputConfig.length != 0 ||
            x.attributeConfig.lenght != 0)
        ) {
          savedD.push(x);
        } else {
          // var resultres = "Please fill required work space details";
          // this.openSnackBar(resultres);
        }
      });
    }
    if (refArr.length == savedD.length) {
      validaterow = true;
    } else {
      validaterow = false;
    }
    if (savedD.length > 0 && validaterow) {
      this.spinner.show();
      this.ads.ConfigureUseCases(savedD).subscribe((result) => {
        if (result.status === "Success") {
          var resultres = "Work space details saved successfully";
          this.openSnackBar(resultres);
          this.getcofigured();
          this.spinner.hide();
          setTimeout(() => {
            if (category == 'inside') {
              if (type == 'next') {
                this.router.navigateByUrl('/Admin/UserBM');
              } else {
                this.router.navigateByUrl('/Admin/orgconfig');
              }
            } else if (category == 'outside') {
              this.router.navigateByUrl(this.dynamicRouterURL.current);
            }
          }, 1100)
          // this.getcofigured();
        } else {
          if (category == 'inside') {
            if (type == 'next') {
              this.router.navigateByUrl('/Admin/UserBM');
            } else {
              this.router.navigateByUrl('/Admin/orgconfig');
            }
          }
          this.spinner.hide();
        }
      });
    } else if (!validaterow) {
      this.openSnackBar('Please Fill all the details');
    } else {
      this.spinner.hide();
      if (category == 'inside') {
        if (type == 'next') {
          this.router.navigateByUrl('/Admin/UserBM');
        } else {
          this.router.navigateByUrl('/Admin/orgconfig');
        }
      } else if (category == 'outside') {
        this.router.navigateByUrl(this.dynamicRouterURL.current);
      }
    }
  }
  /**
   * @event addrow()
   * @description Adding new row
   */
  addrow() {
    var obj = {
      id: this.dataSource.data.length + 1,
      companyname: this.departmentList,
      subdepartname: "",
      orgDescription: "",
      inputopt: false,
      state: "Added",
      UseCaseType: "",
      usecasemapid: this.dataSource.data.length + 1
    };
    this.dataSource.data.unshift(obj);
    this.dataSource.data = [...this.dataSource.data];
  }
  /**
   * @event delete()
   * @parameter index, userid
   *@description confiramation delete
   */
  delete(index, user) {
    let data = {
      message: 'Are yous sure you want to remove'
    }
    this.dialog.open(DeletetreePopupComponent,
      {
        data: data
      })
      .afterClosed()
      .subscribe((result) => {
        if (result.data === "confirmed") {
          if (user.state == 'Added') {
            this.dataSource.data.splice(index, 1);
            this.projectConfig.forEach((item, i) => {
              if (user.usecasemapid == item.useCaseMappingId) {
                this.projectConfig.splice(i, 1);
              }
            })
            this.dataSource.data = [...this.dataSource.data];
          } else {
            this.deleterow(index, user);
          }
        }
      });
  }
  /**
   * @event deleterow()
   * @parameter index, userid
   *@description remove entire row in table
   */
  deleterow(index, user) {
    var databody = this.dataSource.data.filter(
      (d) => d.usecasemapid === user.usecasemapid
    );
    let InputOption = this.projectConfig.filter(
      (x) => x.useCaseMappingId === user.usecasemapid
    );
    databody = databody.map((d) => {
      return {
        useCaseMappingId: user.usecasemapid,
        orgHierarchyId: d.organizationHierarchyId,
        orgUseCaseName: d.subdepartname,
        orgDescription: d.orgDescription,
        outputConfig: InputOption[0].outputConfig,
        inputConfig: InputOption[0].inputConfig,
        attributeConfig: InputOption[0].attributeConfig,
        createdBy: this.createdby,
        modifiedBy: this.createdby,
        state: 'REMOVE'
      };
    });
    this.ads.ConfigureUseCases(databody).subscribe((data) => {
      if (data.status === "Success") {
        this.dataSource.data.splice(index, 1);
        this.dataSource.data = [...this.dataSource.data];
        // this.getcofigured();
        var resultres = "Workspace details delete successfully";
        this.openSnackBar(resultres);
        console.log('nwe', this.dataSource.data);
      } else {
        var resultres = "Failed to delete Workspace details";
        this.openSnackBar(resultres);
      }
    });
  }
  /**
   * @event infopopup
   * @description Shows the details of the brandologo information
   */
  infoPopup() {
    this.dialog
      .open(AdminInfoPopupComponent, {
        backdropClass: "popupBackdropClass",
        width: "349px",
        height: "320px",
        data: {
          type: "Project-config",
        },
        panelClass: "Admin-info-popup",
      })
      .afterClosed()
      .subscribe((result) => { });
  }
  openSnackBar(message) {
    this._snackBar.open(message, "", {
      panelClass: ["snackBar"],
      duration: 1000,
    });
  }
  ngOnDestroy(){
    this.subscription.unsubscribe();
  }
}

export interface PeriodicElement {
  id: number;
  companyname: [];
  subdepartname: string;
  orgDescription: string;
  inputopt: boolean;
  orgUseCaseId: number;
  action: string;
}

let ELEMENT_DATA: any[] = [];
