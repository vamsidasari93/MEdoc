import { Component, Inject, OnInit } from "@angular/core";
import {
  MatDialogRef,
  MatSnackBar,
  MatTableDataSource,
  MAT_DIALOG_DATA,
} from "@angular/material";
import { ColorPickerService } from "ngx-color-picker";
import { Subject } from "rxjs";
import { debounceTime, distinctUntilChanged } from "rxjs/operators";
import { AdminService } from "src/app/Services/admin.service";
let ELEMENT_DATA = [];
@Component({
  selector: "app-projectaction",
  templateUrl: "./projectaction.component.html",
  styleUrls: ["./projectaction.component.scss"],
})
export class ProjectactionComponent implements OnInit {
  actiondata: any;
  displayedColumns: string[] = [
    "categories",
    "attributeName",
    "abbreviations",
    "colorcode",
    "action",
  ];
  public displayedinputColumns: any[] = ["inputOptionId", "inputOptionName"];
  inputlist: any[] = [];
  inputoptions: any[] = [];
  refInputOptions = [];
  public color9: string = "#278ce2";
  employees: Employee[];
  extractionData: any = [];
  employeeRemove = [];
  extrationRemove = [];
  category: any;
  abb: any;
  colorCode: any;
  outputData: { catagoriesName: any; abbrevations: any; colorCode: any };
  dataoutput: any[] = [];
  checkid: any[] = [];
  inputcheckids: any;
  commonArray = [];
  isReadonly = true;
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  // userQuestionUpdate = new Subject<string>();
  // abbUpdate = new Subject<string>();
  constructor(
    private _snackBar: MatSnackBar,
    private ads: AdminService,
    public dialogRef: MatDialogRef<ProjectactionComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.employees = [];
    this.extractionData = [];
    this.employeeRemove = [];
    this.extrationRemove = [];
    this.commonArray = [];
    if (this.data.type === "input") {
      this.inputoptions = this.data.orginoutput;
      this.refInputOptions = JSON.parse(JSON.stringify(this.inputoptions));
      this.Inputdata();
    }
    this.actiondata = this.data.type;
    if (this.data && this.data.orgoutputExtractOption) {
      if (
        this.data.orgoutputExtractOption.outputData &&
        this.data.orgoutputExtractOption.outputData.length != 0
      ) {
        this.employees = this.data.orgoutputExtractOption.outputData;
        this.employees.forEach(key => {
          key['checkValue'] = true;
        })
      } else {
        this.addrow();
      }
      if (
        this.data.orgoutputExtractOption.extractData &&
        this.data.orgoutputExtractOption.extractData.length != 0
      ) {
        this.extractionData = this.data.orgoutputExtractOption.extractData;
        this.extractionData.forEach(key => {
          key['checkValue'] = true;
        })
      } else {
        this.addExtractRow();
      }
    }
  }

  ngOnInit() {
  }
  /**
   * @event editvalues()
   * @description edit existing values
   */
  editvalues(value) {
    this.employees.forEach((obj) => {
      if (obj.catagoriesName === value) obj.checkValue = false;
    });
  }
  editExtract(value) {
    this.extractionData.forEach((obj) => {
      if (obj.attributeName === value) obj.checkValue = false;
    });
  }
  /**
   * @event checkedbox()
   * @description checkbox existing values
   */
  checkedbox(event, id, name, object) {
    if (event.checked) {
      if (this.refInputOptions.length != 0) {
        if (this.refInputOptions.indexOf(object) < 0) {
          var obj = {
            inputOptionId: id,
            inputOptionName: name,
            state: 'ADD'
          };
          this.refInputOptions.push(obj);
        } else {
          this.refInputOptions.forEach(item => {
            if (item.inputOptionId == id && item.state == 'REMOVE') {
              item.state = 'REMOVE';
            }
          })
        }
      } else {
        var obj = {
          inputOptionId: id,
          inputOptionName: name,
          state: 'ADD'
        };
        this.refInputOptions.push(obj);
      }
    } else {
      this.refInputOptions.forEach(item => {
        if (item.inputOptionId == id) {
          item.state = 'REMOVE';
        }
      })
    }
    console.log('lll', this.refInputOptions);
  }
  /**
   * @event Inputdata()
   * @description getting organisation table data
   */
  Inputdata() {
    this.ads.GetOrganizationInputOptions().subscribe((inputDlist: any) => {
      this.inputlist = inputDlist;
      this.dataSource.data = [...this.inputlist];
      if (this.actiondata == "input") {
        if (this.data.orginoutput && this.data.orginoutput.length > 0) {
          this.inputlist.forEach((a1Obj) => {
            this.data.orginoutput.some((a2Obj) => {
              if (a2Obj.inputOptionId === a1Obj.inputOptionId) {
                this.commonArray.push(a1Obj);
              }
            });
          });
        }
      }
    });
  }
  /**
   * @event isCommonEl()
   * @description validate input option id
   */
  isCommonElt(id: any): boolean {
    return this.commonArray.some((elt) => elt.inputOptionId === id);
  }
  /**
   * @event saveinputs()
   * @description sending to parent organisation table data
   */
  saveinputs() {
    if (this.inputoptions.length == 0 && this.refInputOptions.length == 0) {
      this.openSnackBar("Please Fill Input Config Details");
    } else if (this.inputoptions.length == 0 && this.refInputOptions.length != 0) {
      this.dialogRef.close({ data: this.refInputOptions });
    }
    else {
      this.inputoptions.forEach(item => {
        this.refInputOptions.forEach(key => {
          if (item.inputOptionId == key.inputOptionId) {
            item.state = key.state;
          } else if (item.inputOptionId != key.inputOptionId && key.state == 'ADD') {
            this.inputoptions.push(key)
          }
        })
      })
      this.dialogRef.close({ data: this.inputoptions });
    }
  }
  /**
   * @event addrow()
   * @description Adding new row
   */
  addrow() {
    if (this.employees.length == 0) {
      var obj = {
        id: this.employees.length + 1,
        catagoriesName: "",
        attributeName: "",
        colorCode: "",
        action: "",
        abbrevations: "",
        checkValue: false,
        state: 'Add',
        catagoryId: 0
      };
      this.employees.push(obj);
      this.employees = [...this.employees];
    } else {
      let lastObj = this.employees[this.employees.length - 1];
      if (
        lastObj.catagoriesName != "" &&
        lastObj.abbrevations != "" &&
        lastObj.colorCode != ""
      ) {
        var obj = {
          id: this.employees.length + 1,
          catagoriesName: "",
          attributeName: "",
          colorCode: "",
          action: "",
          abbrevations: "",
          state: 'Add',
          checkValue: false,
          catagoryId: 0
        };
        this.employees.push(obj);
        this.employees = [...this.employees];
      } else {
        this.openSnackBar("Please Fill the Last Row Details");
      }
    }
  }

  addExtractRow() {
    if (this.extractionData.length == 0) {
      var obj = {
        id: this.extractionData.length + 1,
        catagoriesName: "",
        attributeName: "",
        colorCode: "",
        action: "",
        abbrevations: "",
        state: 'Add',
        checkValue: false,
        attributeID: 0
      };
      this.extractionData.push(obj);
      this.extractionData = [...this.extractionData];
    } else {
      let lastObj = this.extractionData[this.extractionData.length - 1];
      if (
        lastObj.attributeName != "" &&
        lastObj.abbrevations != "" &&
        lastObj.colorCode != ""
      ) {
        var obj = {
          id: this.extractionData.length + 1,
          catagoriesName: "",
          attributeName: "",
          colorCode: "",
          action: "",
          abbrevations: "",
          state: 'Add',
          checkValue: false,
          attributeID: 0
        };
        this.extractionData.push(obj);
        this.extractionData = [...this.extractionData];
      } else {
        this.openSnackBar("Please Fill the Last Row Details");
      }
    }
  }

  /**
   * @event saveoutputs()
   * @description saving output options data
   */
  saveoutputs() {
    this.employeeRemove.forEach(item => {
      this.employees.push(item);
    })
    this.extrationRemove.forEach(item => {
      this.extractionData.push(item);
    })
    this.employees.forEach((item, i) => {
      delete item.checkValue;
      this.employees[i].abbrevations = item.abbrevations === "" ? item.catagoriesName.substring(0, 3) : item.abbrevations;
      this.employees[i].colorCode = item.colorCode == "" ? 'blue' : item.colorCode;
    });
    this.extractionData.forEach((item, i) => {
      delete item.checkValue;
      this.extractionData[i].abbrevations = item.abbrevations === "" ? item.catagoriesName.substring(0, 3) : item.abbrevations;
      this.extractionData[i].colorCode = item.colorCode == "" ? 'blue' : item.colorCode;
    });
    let refOutputData = this.employees
      .filter((obj) => {
        return (
          obj.catagoriesName !== "" &&
          obj.abbrevations !== "" &&
          obj.colorCode !== ""
        );
      })
      .map((obj) => {
        return {
          catagoryId: obj.catagoryId,
          catagoriesName: obj.catagoriesName,
          abbrevations: obj.abbrevations,
          colorCode: obj.colorCode,
          state: obj.state == 'Add' ? 'ADD' : obj.state == 'REMOVE' ? 'REMOVE' : 'UPDATE'
        };
      });
    let refExtractData = this.extractionData
      .filter((obj) => {
        return (
          obj.attributeName !== "" &&
          obj.abbrevations !== "" &&
          obj.colorCode !== ""
        );
      })
      .map((obj) => {
        return {
          attributeID: obj.attributeID,
          attributeName: obj.attributeName,
          abbrevations: obj.abbrevations,
          colorCode: obj.colorCode,
          state: obj.state == 'Add' ? 'ADD' : obj.state == 'REMOVE' ? 'REMOVE' : 'UPDATE'
        };
      });
    if (this.data.category == 'classic') {
      if (refOutputData.length != 0) {
        this.dialogRef.close({
          outputData: refOutputData,
          extractData: refExtractData,
        });
      } else {
        this.openSnackBar("Please Fill any Output or Extract Details");
      }
    } else if (this.data.category == 'extraction') {
      if (refExtractData.length != 0) {
        this.dialogRef.close({
          outputData: refOutputData,
          extractData: refExtractData,
        });
      } else {
        this.openSnackBar("Please Fill any Output or Extract Details");
      }
    } else if (this.data.category == 'both') {
      if (refOutputData.length != 0 || refExtractData.length != 0) {
        this.dialogRef.close({
          outputData: refOutputData,
          extractData: refExtractData,
        });
      } else {
        this.openSnackBar("Please Fill any Output or Extract Details");
      }
    }

  }

  validateAbbr(type, i, clasues) {
    if (type == 'classic') {
      this.employees.forEach((item, index) => {
        if (clasues.abbrevations == item.abbrevations && index != i) {
          this.employees[index].abbrevations = '';
          this.openSnackBar('Abbrevation should be unique');
        }
      })
    } else if (type == 'extraction') {
      this.extractionData.forEach((item, index) => {
        if (clasues.abbrevations == item.abbrevations && index != i) {
          this.extractionData[index].abbrevations = '';
          this.openSnackBar('Abbrevation should be unique');
        }
      })
    }
  }

  close() {
    this.dialogRef.close(false);
  }
  classificationValidation(i, item) {
    // if (item.catagoriesName != '') {
    //   this.employees[i].abbrevations = item.abbrevations === "" ? item.catagoriesName.substring(0, 3) : item.abbrevations;
    //   this.employees[i].colorCode = item.colorCode == "" ? 'blue' : item.colorCode;
    // }
  }

  extractionValidation(i, item) {
    // if (item.attributeName != '') {
    //   this.extractionData[i].abbrevations = item.abbrevations === "" ? item.attributeName.substring(0, 3) : item.abbrevations;
    //   this.extractionData[i].colorCode = item.colorCode == "" ? 'blue' : item.colorCode;
    // }
  }
  /**
   * @event deleteRow()
   * @description delete entire row
   * @parameter index
   */
  deleteRow(index, type, state) {
    if (type == "output") {
      if (state != 'Add') {
        this.employees.forEach((item, i) => {
          if (i == index) {
            item['state'] = "REMOVE";
            this.employeeRemove.push(item);
          }
        })
      }
      this.employees.splice(index, 1);
    } else {
      if (state != 'Add') {
        this.extractionData.forEach((item, i) => {
          item['state'] = "REMOVE";
          if (i == index) {
            this.extrationRemove.push(item);
          }
        })
      }
      this.extractionData.splice(index, 1);
    }
  }
  changeTabs(event) { }

  openSnackBar(message) {
    this._snackBar.open(message, "", {
      duration: 3000,
      panelClass: ["snackBar"],
    });
  }
}

export class Employee {
  catagoriesName: string;
  attributeName: string;
  abbrevations: string;
  colorCode: string;
  action: string;
  id: number;
  checkValue: boolean;
  state: string;
  catagoryId: number;
}
