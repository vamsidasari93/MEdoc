import {ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from "@angular/router";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";

@Component({
  selector: 'app-datascience',
  templateUrl: './datascience.component.html',
  styleUrls: ['./datascience.component.scss']
})
export class DatascienceComponent implements OnInit {

  isExtraction: boolean = false;
  constructor(
    private PdfserviceService: PdfserviceService,
    private dataScienceService: DatascienceService,
    private changeDetectorRef: ChangeDetectorRef,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { 

  }

  ngOnInit() {
    this.changeDetectorRef.detectChanges();
    this.PdfserviceService.annotation("History");
    let usecaseType = localStorage.getItem("useCaseType");
    if(usecaseType == 'extraction')
    {
      this.isExtraction = true
    }
    console.log(usecaseType);
    console.log(JSON.parse(this.activatedRoute.snapshot.params["datasets"]), this.activatedRoute.snapshot.params["id"])
  }

}
