import { ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { MatPaginator, MatTableDataSource, MatDialog } from "@angular/material";
import { Router } from "@angular/router";
import { Observable } from "rxjs";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";
import { DatascienceHelpPopupComponent } from "../datascience-help-popup/datascience-help-popup.component";
// import { AdminInfoPopupComponent} from "../../admin/admin-info-popup/admin-info-popup.component";

export interface UseCase {
  useCaseId: number;
  useCaseName: string;
  useCaseDescription: string;
  createBy: string;
  createdOn: Date;
  userId: string;
}
@Component({
  selector: "app-usecase",
  templateUrl: "./usecase.component.html",
  styleUrls: ["./usecase.component.scss"],
})
export class UsecaseComponent implements OnInit {
  hide: boolean = false;
  searchValue: any;
  pageEvent: any;
  startNo: number = 0;
  endNo: number = 10;
  useCase: UseCase[] = [];
  useCases: UseCase[] = [];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  obs: Observable<any>;
  dataSource: MatTableDataSource<UseCase> = new MatTableDataSource<UseCase>(
    this.useCase
  );
  rolename: any;
  constructor(
    private router: Router,
    private PdfserviceService: PdfserviceService,
    private dataScienceService: DatascienceService,
    private changeDetectorRef: ChangeDetectorRef,
    public dialog: MatDialog
  ) {}

  ngOnInit() {
    this.changeDetectorRef.detectChanges();
    this.dataSource.paginator = this.paginator;
    this.obs = this.dataSource.connect();
    this.PdfserviceService.annotation("useCases");
    this.PdfserviceService.searchValue$.subscribe((val) => {
      this.search(val);
    });
    this.getUseCasesList();
  }
  /**
   * get use case list
   */
  getUseCasesList() {
    let id = JSON.parse(localStorage.getItem("userinfo"));
    let userid = id.userId;
    this.dataScienceService.getUseCases(userid).subscribe(
      (res: any) => {
        if (res.statusCode == 200) {
          this.useCase = res.useCaseList;
          this.useCases = [...res.useCaseList];
          this.dataSource.data = this.useCase;
        } else {
          this.useCase = [];
        }
      },
      (err) => {}
    );
  }
  ngOnDestroy() {
    if (this.dataSource) {
      this.dataSource.disconnect();
    }
  }
  /**
   * Navigate the dateset screen
   * @param useCaseId
   */
  projectnav(useCaseId, useCaseName, usecaseType) {
    console.log(useCaseId, useCaseName);
    localStorage.setItem("useCaseId", useCaseId);
    localStorage.setItem("useCaseType", usecaseType);
    localStorage.setItem("useCaseName", useCaseName);
    var role = JSON.parse(localStorage.getItem("usersrole"));
    // let rolename = role[0].tab_label;
    for (let i = 0; i < role.length; i++) {
      var croleid = JSON.parse(localStorage.getItem("roleID"));
      if (croleid == role[i].role_id) {
        this.rolename = role[i].tab_label;
      }
    }
    console.log("checking with cycle", this.rolename);
    let usecaseid = btoa(useCaseId);
    if (this.rolename === "Training Module") {
      this.router.navigate(["/Documentslist/Documents", usecaseid]);
    } else if (this.rolename === "Live Module") {
      this.router.navigate(["/Documentslist/Documentslistlive", usecaseid]);
    } else if (this.rolename === "DataScience Module") {
      this.router.navigate(["/datascience/dataset", { id: usecaseid }]);
    }
  }

  /**
   * Not used
   * @param value
   */
  search(value) {
    value = value.toLowerCase();
    if (value) {
      this.useCase = this.useCases.filter((o) => {
        return (
          o.useCaseName.toLowerCase().startsWith(value) ||
          o.useCaseDescription.toLowerCase().startsWith(value)
        );
      });
      this.dataSource.data = this.useCase;
    } else {
      this.useCase = this.useCases;
      this.dataSource.data = this.useCase;
    }
  }

  keyPressAlphaNumeric(event) {
    var inp = String.fromCharCode(event.keyCode);
    if (/[a-zA-Z0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  /**
   * Page changed time it will be trigger
   * @param event
   */
  onPaginateChange(event) {
    this.startNo = event.pageIndex * event.pageSize;
    this.endNo = event.pageIndex * event.pageSize + event.pageSize;
  }

  /**
   * @event infopopup
   * @description Shows the details of the brandologo information
   */
  infoPopup() {
    this.dialog
      .open(DatascienceHelpPopupComponent, {
        backdropClass: "popupBackdropClass",
        width: "349px",
        height: "320px",
        data: {
          type: "workspace-training",
        },
        panelClass: "Admin-info-popup",
      })
      .afterClosed()
      .subscribe((result) => {});
  }
}
