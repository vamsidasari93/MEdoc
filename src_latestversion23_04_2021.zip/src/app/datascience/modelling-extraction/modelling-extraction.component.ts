import {
  Component,
  OnInit,
  OnDestroy,
  ViewChild,
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
} from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { DatascienceService } from "src/app/Services/datascience.service";
import {
  MatInput,
  MatDatepicker,
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from "@angular/material";
import {
  PanZoomConfig,
  PanZoomAPI,
  PanZoomModel,
  PanZoomConfigOptions,
} from "ngx-panzoom";
import { Subscription } from "rxjs";
import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: "app-modelling-extraction",
  templateUrl: "./modelling-extraction.component.html",
  styleUrls: ["./modelling-extraction.component.scss"],
})
export class ModellingExtractionComponent implements OnInit {
  isPretrained: boolean = false;
  isSize: boolean = false;
  isModelName: boolean = false;
  isNoOfIter: boolean = false;
  isText: boolean = false;
  modelTypeId: string = "en_core_web_sm";
  useCase: any;
  datasetNameList: string[];
  datasetNames: string = "";
  noOfIterators: string = "";
  size: string = "";
  modelName: string = "";
  lrNewTrain: any = {};
  isLrNewTrainMatrix: boolean = true;
  lrOutPut: string = "";
  version: string = "";
  text: string = "";
  textVal: SafeHtml;
  modelTypes = [
    { id: "en_core_web_sm", name: "en_core_web_sm" },
    { id: "en_core_web_md", name: "en_core_web_md" },
    { id: "en_core_web_lg", name: "en_core_web_lg" },
  ];
  isActive: boolean = true;
  isMessage: boolean = false;
  isTest: boolean = false;

  constructor(
    private Pdfservice: PdfserviceService,
    private PdffilesService: PdffilesService,
    private router: Router,
    private _sanitizer: DomSanitizer,
    private datascienceService: DatascienceService,
    private activatedRoute: ActivatedRoute,
    private cdRef: ChangeDetectorRef,
    private _snackBar: MatSnackBar,
    private spinner: NgxSpinnerService
  ) {
    this.useCase = atob(this.activatedRoute.snapshot.params["id"]);
    this.datasetNameList = JSON.parse(
      this.activatedRoute.snapshot.params["datasets"]
    );
    this.datasetNames = this.datasetNameList.join(",");
  }

  ngOnInit() {}

  /**
   * validate the forms
   * @param type
   */
  validateForm = (type) => {
    if (type == "Pretrained") {
      return false;
    } else {
      if (
        this.size != null &&
        this.size != "" &&
        this.modelName != "" &&
        this.modelName != undefined &&
        this.modelName != null &&
        this.noOfIterators != null &&
        this.noOfIterators != ""
      ) {
        this.isModelName = false;
        this.isSize = false;
        this.isNoOfIter = false;
        return true;
      } else {
        if (this.size != null && this.size != "") {
          this.isSize = false;
        } else {
          this.isSize = true;
        }
        if (this.noOfIterators != null && this.noOfIterators != "") {
          this.isNoOfIter = false;
        } else {
          this.isNoOfIter = true;
        }
        if (
          this.modelName == "" ||
          this.modelName == undefined ||
          this.modelName == null
        ) {
          this.isModelName = true;
        } else {
          this.isModelName = false;
        }
        return false;
      }
    }
  };

  /**
   * Save Model
   * @param body
   */

  saveModal = (type) => {
    if (this.validateForm(type)) {
      this.isMessage = false;
      this.spinner.show();
      let body = {
        useCaseId: this.useCase,
        datasetNames: this.datasetNameList,
        size: this.size,
        modelName: this.modelName,
        type: this.modelTypeId,
      };
      let isNew = type == "Pretrained" ? false : true;
      this.datascienceService.saveModel(body, isNew).subscribe(
        (res) => {
          if (res.statusCode == 200) {
            this.getTrained(res);
          } else if (res.statusCode == 299) {
            this.isMessage = true;
            this.spinner.hide();
          }
        },
        (error) => {
          this.spinner.hide();
          console.log(error);
        }
      );
    }
  };

  /**
   * Get Trained
   */

  getTrained = (res) => {
    this.isLrNewTrainMatrix = true;
    this.version = res.version;
    let body = {
      usecase_id: this.useCase,
      dataset_markers: JSON.stringify(this.datasetNameList),
      model_name: this.modelName,
      size: this.size,
      version: res.version,
      no_of_itr: this.noOfIterators,
    };
    let url = "en_core_web_sm";
    if (this.modelTypeId == "en_core_web_sm") {
      url = "en_core_web_sm";
    } else if (this.modelTypeId == "en_core_web_md") {
      url = "en_core_web_md";
    } else if (this.modelTypeId == "en_core_web_lg") {
      url = "en_core_web_lg";
    }

    this.datascienceService.getTrainedNewModelLogistic(body, url).subscribe(
      (res) => {
        this.spinner.hide();
        if (res.status == "success") {
          this.openSnackBar(res.output);
          this.isActive = false;
        }
      },
      (err) => {
        this.spinner.hide();
        console.log(err);
      }
    );
    this.isLrNewTrainMatrix = false;
  };
  /**
   * test
   */
  test = () => {
    if (this.text != null && this.text.trim() != "" && this.text != undefined) {
      this.isText = false;
      let data = {
        usecase_id: this.useCase,
        text: this.text,
        model_name: this.modelName,
        version: this.version,
      };
      this.datascienceService.testModel(data).subscribe(
        (res: any) => {
          this.isTest = true;
          this.textVal = this._sanitizer.bypassSecurityTrustHtml(res.output);
        },
        (error) => {
          this.spinner.hide();
          console.log(error);
        }
      );
    } else {
      this.isText = true;
      return false;
    }
  };

  onKeypress(event: any) {
    const keyChar = event.key;
    let allowCharacter: boolean;
    if (keyChar === "-" && event.target.selectionStart !== 0) {
      allowCharacter = false;
    } else if (keyChar === "-") {
      return false;
    } else if (keyChar === "0" && event.target.value.trim() === "") {
      return false;
    } else if (
      keyChar === "Tab" ||
      keyChar === "Enter" ||
      keyChar === "Backspace" ||
      keyChar === "ArrowLeft" ||
      keyChar === "ArrowRight" ||
      keyChar === "Delete"
    ) {
      allowCharacter = true;
    } else {
      allowCharacter = keyChar >= "0" && keyChar <= "9";
    }

    if (!allowCharacter) {
      event.preventDefault();
    }
  }

  /**
   *
   */
  changeOutput = (event: Event) => {
    console.log(this.lrOutPut);
  };

  changeModel = (event: Event) => {
    this.size = null;
    this.modelName = null;
    this.noOfIterators = null;
    this.isActive = true;
    this.isText = false;
    this.isSize = false;
    this.isMessage = false;
    this.isModelName = false;
    this.isTest = false;
    this.text = null;
  };

  /**
   * @event - openSnackBar
   * @param data
   */
  openSnackBar(data) {
    this._snackBar.open(data, "", {
      panelClass: ["snackBar"],
      duration: 2 * 1000, //,
      // horizontalPosition: this.horizontalPosition,
      // verticalPosition: this.verticalPosition
    });
  }
}
