import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: 'app-datascience-help-popup',
  templateUrl: './datascience-help-popup.component.html',
  styleUrls: ['./datascience-help-popup.component.scss']
})
export class DatascienceHelpPopupComponent implements OnInit {

  infoType: any;

  constructor(
    public dialogRef: MatDialogRef<DatascienceHelpPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.infoType = data.type;
  }
  ngOnInit() {}


}
