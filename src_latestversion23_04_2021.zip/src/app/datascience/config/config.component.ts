import { Component, OnInit } from '@angular/core';
import { PdfserviceService } from "src/app/Services/pdfservice.service";
@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.scss']
})
export class ConfigComponent implements OnInit {

  constructor(
    private PdfserviceService: PdfserviceService,
  ) {
    
   }

  ngOnInit() {
    this.PdfserviceService.annotation("datascience");
  }

}
