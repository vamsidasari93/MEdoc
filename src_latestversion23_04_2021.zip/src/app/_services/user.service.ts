﻿import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

import { environment } from "../../environments/environment";
import { User } from "../_models";
import { map } from "rxjs/operators";
import { Observable } from "rxjs";

@Injectable({ providedIn: "root" })
export class UserService {
  role: any;
  constructor(private http: HttpClient) {}
  /**
   * Login validations
   */
  getAll() {
    return this.http.post<User[]>(`${environment.apiUrl}/users`, {
      responseType: "json",
    });
  }

  getById(id: number) {
    return this.http.post<User>(`${environment.apiUrl}/users/${id}`, {
      responseType: "json",
    });
  }
  /**
   * Based on role high level module should highlight
   */
  getroleobj() {
    this.role = JSON.parse(localStorage.getItem("usersrole"));
    let maxValue = [];
    if (this.role && this.role.length) {
      this.role.map((x) => {
        maxValue.push(x.role_id);
      });
      let xMax = Math.max(...maxValue);
      let item = this.role.find((x) => x.role_id == xMax);
      return item;
    }
  }

  Updatepassword(updatecresentails): Observable<boolean> {
    const url = `${environment.apiUrl}/Login/ResetPassword`;
    var data = updatecresentails;
    return this.http
      .post(url, updatecresentails, { responseType: "json" })
      .pipe(
        map((response: any) => {
          return response;
        })
      );
  }

  ChangePassword(body: any) {
    let url = `${environment.apiUrl}/Login/ChangePassword`;
    // url = "https://localhost:44338/api/Login/ChangePassword";
    return this.http.put(url, body, { responseType: "json" }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
  SaveProfile(body: any) {
    console.log(body);
    let url = `${environment.apiUrl}/Login/updateProfile`;
    //url ="https://localhost:44338/api/Login/updateProfile";
    return this.http.put(url, body, { responseType: "json" }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  GetProfile(userId: number) {
    let url = `${environment.apiUrl}/Login/getUserInfo?userId=${userId}`;
    //url =`https://localhost:44338/api/Login/getUserInfo?userId=${userId}`;
    return this.http.post(url, { responseType: "json" }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }
}
