import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";

@Component({
  selector: "app-editreview-dialog",
  templateUrl: "./editreview-dialog.component.html",
  styleUrls: ["./editreview-dialog.component.scss"],
})
export class EditreviewDialogComponent implements OnInit {
  selected = -1;
  categoryName: any;
  searchSegment: any;
  showdialog: boolean;
  reassigndialog: boolean;
  deleteconfirm: boolean;
  afterchangeSegmenttext: any;
  itemchecked: any;
  checkedvalue: number;
  show = false;
  apiResponse: any;
  constructor(
    private PdffilesService: PdffilesService,
    private PdfserviceService: PdfserviceService,
    public dialogRef: MatDialogRef<EditreviewDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.categoryName = this.data.categoryName;
  }

  ngOnInit() {
    console.log("data", this.data);
    this.categoryName = this.data.name;
    this.dialogshow();
  }
  segmenttextChange(val) {
    this.afterchangeSegmenttext = val.replace(/&nbsp;/g, " ");
  }
  onSave() {
    if (this.afterchangeSegmenttext) {
      this.data.segmenttext = this.afterchangeSegmenttext;
      console.log("save data", this.data);
      var obj = {
        documentId: this.data.documentId,
        pageNo: parseInt(this.data.pageNo),
        segementId: this.data.segmentid,
        labelId: this.data.labelId,
        labelName: this.data.name,
        segementText: this.data.segmenttext,
        actionType: "Update",
      };
      console.log(obj);
      this.PdffilesService.UpdateReassignvalue(obj).subscribe((response) => {
        this.apiResponse = response;
        // this.show = true;
        var data = {
          response: response,
        };
        this.PdfserviceService.reviewannatation(data);
        console.log(this.apiResponse);
      });
    }
    this.dialogRef.close();
  }

  reassignsegment(checkedclasuses, categoriesId, categoriesname, i) {
    this.selected = i;
    this.itemchecked = checkedclasuses;
    // var Reassigndata = [];
    var obj = {
      documentId: this.data.documentId,
      pageNo: parseInt(this.data.pageNo),
      segementId: this.data.segmentid,
      labelId: categoriesId,
      labelName: categoriesname,
      segementText: this.data.segmenttext,
      actionType: "Reassign",
    };
    // Reassigndata.push(obj);
    this.PdffilesService.UpdateReassignvalue(obj).subscribe((response: any) => {
      this.apiResponse = response;
      if (response === "Data Reassigned Successfully") {
        var reassignres = "Segment reassigned successfully";
        this.PdfserviceService.annatationCount(reassignres);
        this.PdfserviceService.reviewannatation(reassignres);
        this.dialogRef.close();
      }
    });
  }
  closeresponse() {
    this.show = false;
  }
  dialogshow() {
    if (this.data.edit === "editpopup") {
      this.showdialog = true;
      this.deleteconfirm = false;
      this.reassigndialog = false;
    } else if (this.data.delete === "deletepopup") {
      this.deleteconfirm = true;
      this.reassigndialog = false;
      this.showdialog = false;
    } else {
      this.reassigndialog = true;
      this.deleteconfirm = false;
      this.showdialog = false;
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
  cancel() {
    this.dialogRef.close();
  }
  confirm() {
    this.dialogRef.close({ data: "confirmed" });
  }
}
