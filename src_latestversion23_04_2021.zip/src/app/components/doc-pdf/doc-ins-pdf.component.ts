import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  Renderer,
  HostListener,
  SimpleChanges,
  OnChanges,
  AfterViewInit,
} from "@angular/core";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { ActivatedRoute, Params } from "@angular/router";
import { MatDialog } from "@angular/material/dialog";
import { EditreviewDialogComponent } from "./review-annotation/editreview-dialog/editreview-dialog.component";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { HttpClient } from "@angular/common/http";
// import { Observable } from "rxjs";
// import { debounce, map } from "rxjs/operators";
import { Location } from "@angular/common";
import { Observable, Subject } from "rxjs";
import {
  debounceTime,
  distinctUntilChanged,
  map,
  reduce,
} from "rxjs/operators";
import {
  DomSanitizer,
  SafeResourceUrl,
  SafeUrl,
} from "@angular/platform-browser";
import { NgxSpinnerService } from "ngx-spinner";
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from "@angular/material";
import { SilderComponentComponent } from "./silder-component/silder-component.component";
import { environment } from "src/environments/environment";
import { EditExtractionComponent } from "./review-annotation/edit-extraction/edit-extraction.component";
import { SharedHelpPopupComponent } from "src/app/SharedComponents/shared-help-popup/shared-help-popup.component";

@Component({
  selector: "app-doc-ins-pdf",
  templateUrl: "./doc-ins-pdf.component.html",
  styleUrls: ["./doc-ins-pdf.component.scss"],
})
export class DocInsPdfComponent implements OnInit, OnChanges, AfterViewInit {
  @ViewChild("viewer", { static: true }) public bigPdfViewer;
  @ViewChild("pdfViewerOnDemand", { static: true }) pdfViewerOnDemand;
  @ViewChild("pdfViewerAutoLoad", { static: true }) pdfViewerAutoLoad;
  // @ViewChild('iframe', {static: false}) iframe: ElementRef;
  pdfMaterial: any;
  spliturl: any;
  Rid: any;
  pdfsearchValue: any;
  searchSegment: any;
  indexsearchSegment: any;
  pagelive = 1;
  segmentShow = true;
  totalPages: any;
  panelOpenState = false;
  icon: boolean = false;
  totalCount = 0;
  DocumentbarShow = false;
  // DocumentbarRightShow = false;
  annontationchecked = false;
  show: boolean = true;
  linkactive: boolean;
  pdfName: any;
  documentId: any;
  getTraningData: any;
  segmentlive: any;
  completed = false;
  navigationList = [];
  options = [];
  segments: any;
  downloadurl: any;
  dataurl: any;
  addurl: any;
  trustedDashboardUrl: SafeUrl;
  userQuestionUpdate = new Subject<string>();
  result: any;
  apiresponse: string;
  livemodule: boolean = false;
  categories = [];
  existedcoordinates = [];
  // liveAnnonationcount = [];
  module: any;
  usercondenseScore: number = 0;
  croppedChecked: any;
  csvUrl: any;
  horizontalPosition: MatSnackBarHorizontalPosition = "right";
  verticalPosition: MatSnackBarVerticalPosition = "bottom";
  checked: any;
  searchdata: string;
  sliderClick: boolean = false;
  role: any;
  navShow: boolean;
  atrributeList: any;
  UseCaseId: string;
  categorieList: any;
  classificationsCount = 0;
  attributesCount = 0;
  classPageNo: any;
  classlabelId: any;
  // atrributeSegments: any;
  extractionAtrrList: [];
  insideExtraction: [];
  ExtractCount = 0;
  TotalattributesCount: any;
  useCaseType: string;
  classicCount = 0;
  extractionCountArray: any;
  classificationCountArray: any;
  extractionFilter: boolean = false;
  extractionCountlists = 0;
  searchPlacholder: string;
  pageNo = 0;
  listLabelnames: boolean = false;
  selectedText: string = "";
  extractionShow: boolean = true;
  categoriesColors: any;
  indexPagetext: any;
  indexPageno: any;
  notification: any;
  constructor(
    private el: ElementRef,
    private renderer: Renderer,
    public PdfserviceService: PdfserviceService,
    private PdffilesService: PdffilesService,
    private activatedRoute: ActivatedRoute,
    private SpinnerService: NgxSpinnerService,
    private sanitizer: DomSanitizer,
    public dialog: MatDialog,
    private http: HttpClient,
    private _snackBar: MatSnackBar,
    private location: Location
  ) {
    // this.PdfserviceService.subj$.subscribe((val) => {
    //   this.checked = val;
    // });
    // this.PdfserviceService.annotation("pdfDocumentlist");
    this.Rid = atob(this.activatedRoute.snapshot.params["id"]);
    // console.log(this.Rid);
    localStorage.setItem("documentId", this.Rid);
    this.PdfserviceService.annotation("AnnotationDocument");
    this.PdfserviceService.reviewannatation$.subscribe((val: any) => {
      var data = val;
      this.notification = val;
      if (data.response && val !== "notification") {
        if (data.response) {
          this.deletedsegment(data);
          this.reduce();
          this.openSnackBar(data.response);
        } else {
          this.openSnackBar(val);
        }
      }
    });
    this.PdfserviceService.condensedscores$.subscribe((data: any) => {
      var scorevalue = parseInt(data);
      this.gettingTrainingdata(scorevalue);
    });
    this.module = localStorage.getItem("rolname");
    this.PdfserviceService.countannatation$.subscribe((val: any) => {
      this.reduce();
      this.AnnotationopenSnackBar(val);
    });

    this.PdfserviceService.displayCards.next(false);

    this.activatedRoute.params.subscribe((params: Params) => {
      // console.log("params", this.Rid);
      // this.Rid = params["id"];
      if (this.module === "Live Module") {
        this.livemodule = true;
      }
      this.userQuestionUpdate
        .pipe(debounceTime(1000), distinctUntilChanged())
        .subscribe((value) => {
          this.pdfsearch(value);
          this.searchdata = value;
        });
    });

    this.UseCaseId = localStorage.getItem("useCaseId");
    console.log("UseCaseId: ", this.UseCaseId);
    this.useCaseType = localStorage.getItem("useCaseType");
    if (this.UseCaseId !== null && this.UseCaseId !== undefined) {
      this.PdffilesService.getDoumentslist(this.UseCaseId).subscribe((data) => {
        const Documentdata = data;
        for (var i in data) {
          if (this.Rid == Documentdata[i].documentId) {
            this.documentId = Documentdata[i].documentId;
            this.role = JSON.parse(localStorage.getItem("usersrole"));
            var roleid = this.role[0].role_id;
            if (this.module === "Live Module" || roleid === 4) {
              this.dataurl = Documentdata[i].segmentedPDFURL;
              // this.dataurl = Documentdata[i].blobURL;
              this.livemodule = true;
              if (
                this.useCaseType === "both" ||
                this.useCaseType === "extraction"
              ) {
                if (this.livemodule) {
                  this.extractionShow = true;
                }
              }
            } else {
              this.dataurl = Documentdata[i].blobURL;
            }
            this.csvUrl = Documentdata[i].csvURL;
            this.pdfName = Documentdata[i].documentname;
          }
        }
        let url = this.dataurl;
        this.downloadFile(url).subscribe((res) => {
          this.pdfViewerAutoLoad.pdfSrc = res; // pdfSrc can be Blob or Uint8Array
          this.pdfViewerAutoLoad.refresh(); // Ask pdf viewer to load/refresh pdf
        });
        this.reduce();
      });
    }
    if (this.useCaseType === "classic") {
      this.extractionFilter = true;
      this.extractionShow = false;
      this.searchPlacholder = "categories";
    } else if (this.useCaseType === "extraction") {
      this.extractionFilter = false;
      // this.extractionShow = false;
      this.extractionShow = true;
      this.searchPlacholder = "attributes";
    } else if (this.useCaseType === "both") {
      this.extractionFilter = true;
      this.extractionShow = true;
      // if (this.livemodule) {
      //   this.extractionShow = false;
      // }
      this.searchPlacholder = "categories or attributes ";
    }
    this.croppedChecked = localStorage.getItem("predefindseg");
    if (this.croppedChecked === "true") {
      this.getNavigationLables();
    } else {
      this.navigationList = [];
      this.result = "";
    }
  }

  private downloadFile(url: string): any {
    this.addurl = environment.urldata;
    return this.http.get(url + this.addurl, { responseType: "blob" }).pipe(
      map((result: any) => {
        // console.log("getttt", result);
        return result;
      })
    );
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(EditreviewDialogComponent, {
      width: "250px",
      data: {},
    });
    dialogRef.afterClosed().subscribe((result) => {
      // console.log("The dialog was closed");
    });
  }
  @HostListener("window:downloadSuccess", ["$event.detail"])
  downloadSuccess(detail) {
    setTimeout(() => {
      this.openSnackBar(detail.successMsg);
    }, 1000);
  }
  @HostListener("window:annnotationSuccess", ["$event.detail"])
  annnotationSuccess(detail) {
    this.pageNo = detail.pageNo;
    console.log(detail);
    this.reduce();
    setTimeout(() => {
      this.apiresponse = detail.successMsg;
      this.openSnackBar(this.apiresponse);
    }, 2000);
  }
  @HostListener("window:searchallpages", ["$event.detail"])
  searchallpages(detail) {
    this.result = detail.searchdata;
  }
  ngOnInit() {
    // this.PdfserviceService.annotation("pdfDocumentlist");
    this.getNavigationLables();
    // this.getAttributes();
    this.linkActivited();

    // setTimeout(() => {
    //   if (this.bigPdfViewer.PDFViewerApplication.page) {
    //     this.bigPdfViewer.PDFViewerApplication.page;
    //   }
    // }, 5000);
  }
  ngOnDestroy() {
    localStorage.removeItem("documentId");
  }
  downloadcsv() {
    var downloadurl = `${environment.apiUrl}/Live/DownloadAnatationDetails?documentId=${this.Rid}`;
    const link = document.createElement("a");
    link.setAttribute("href", downloadurl);
    document.body.appendChild(link);
    link.click();
    link.remove();
    let val = "Document downloaded successfully";
    setTimeout(() => {
      this.openSnackBar(val);
    }, 1500);
  }

  getNavigationLables() {
    this.PdffilesService.getNavigtionlist(this.Rid).subscribe((data) => {
      // console.log(data);
      if (data) {
        data.map((each) => {
          each.segmentHeading.map((heads) => {
            if (heads !== "NULL") {
              var nullData = {
                pageName: heads,
                pageNo: parseInt(each.pageNo),
              };
              this.navigationList.push(nullData);
            }
          });
          return each;
        });
      }
    });
  }
  ngOnChanges(changes: SimpleChanges) {}
  linkActivited() {
    var url = window.location.pathname;
    this.spliturl = url.split(";");
    if (this.spliturl[0] == "/AnnotationDocument") {
      this.linkactive = true;
      this.PdfserviceService.sendlink(this.linkactive);
    } else {
      this.linkactive = false;
      this.PdfserviceService.sendlink(this.linkactive);
    }
  }
  // hide() {
  //   this.DocumentbarRightShow = false;
  // }
  keyPressAlphaNumeric(event) {
    var inp = String.fromCharCode(event.keyCode);
    if (/[a-zA-Z0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  // annotationBar() {
  //   this.DocumentbarShow = !this.DocumentbarShow;
  // }

  // annotationBarRight() {
  //   this.DocumentbarRightShow = true;
  //   this.show = false;
  //   this.indexsearchSegment = "";
  // }
  // annotationBarhide() {
  //   this.DocumentbarRightShow = false;
  //   this.show = true;
  //   this.indexsearchSegment = "";
  //   this.result = "";
  //   var value = "";
  //   this.pdfsearch(value);
  // }
  annotationBar() {
    this.DocumentbarShow = !this.DocumentbarShow;
  }
  annotationBarRight() {
    // this.DocumentbarRightShow = true;
    this.show = false;
    this.selectedText = "";
    // this.indexsearchSegment = "";
  }
  showResult() {
    // this.DocumentbarRightShow = true;
    this.show = false;
    // this.selectedText = '';
  }
  annotationBarhide() {
    // this.DocumentbarRightShow = false;
    this.show = true;
    this.indexsearchSegment = "";
    this.result = "";
    var value = "";
    this.selectedText = "";
    this.pdfsearch(value);
  }
  click() {
    this.icon = !this.icon;
  }
  sliderShow(event: any): void {
    this.sliderClick = !this.sliderClick;
    event.stopPropagation();
  }
  closeSlider(event: any) {
    if (this.sliderClick == true) {
      this.sliderClick = false;
    }
  }
  reduce() {
    var score = this.usercondenseScore ? this.usercondenseScore : 0;
    this.atrributeList = [];
    this.existedcoordinates = [];
    this.getAttributes();
    if (score !== null && score !== undefined) {
      this.gettingTrainingdata(value);
    } else {
      var value = 0;
      this.gettingTrainingdata(value);
    }
    setTimeout(() => {
      this.existedviaPage(this.pageNo);
    }, 1000);
  }
  /**
   * @event  getAttributes()
   * @param usecaseID
   */
  attributeLabellist: any = [];
  getAttributes() {
    if (this.useCaseType == "both" || this.useCaseType == "extraction") {
      if (this.attributeLabellist.length > 0) {
        this.getExtraction(this.attributeLabellist);
      } else {
        this.PdffilesService.getAttributes(this.UseCaseId).subscribe(
          (data: any) => {
            // this.atrributeList = [];
            if (data && data.listAttributes.length > 0) {
              this.listLabelnames = false;
            } else {
              this.listLabelnames = true;
            }
            this.attributeLabellist = data.listAttributes;
            this.getExtraction(data.listAttributes);
            // console.log(data);
          }
        );
      }
    }
  }
  /**
   * @event  getCategories()
   * @param usecaseID
   */
  // getCategories() {
  //   if (this.useCaseType == "both" || this.useCaseType == "classic") {
  //     this.PdffilesService.getCategories(this.UseCaseId).subscribe(
  //       (data: any) => {
  //         this.categorieList = data.listCategories;
  //       }
  //     );
  //   }
  // }
  /**
   * @event  getExtraction()
   * @param usecaseID
   */
  getExtraction(list) {
    // console.log("getExtraction");
    if (this.useCaseType == "both" || this.useCaseType == "extraction") {
      // let Rid = this.activatedRoute.snapshot.params["id"];
      this.PdffilesService.getAttributeExtraction(this.Rid).subscribe(
        (res: any) => {
          var extraction = list.map((data: any) => {
            var d = res.attributes.filter((x) => x.labelId == data.attributeId);
            return {
              ...data,
              segment: d !== null ? d : [],
              count: d !== null ? d.length : 0,
              isExtraction: true,
            };
          });

          this.extractionAtrrList = extraction.length > 0 ? extraction : [];
          this.extractionCountlist(this.extractionAtrrList);
        }
      );
    }
  }
  extractionCountlist(list) {
    if (list && list.length) {
      this.extractionCountlists = list.reduce((acc, crt) => {
        this.existedcoordinates.push(...crt.segment);
        return acc + crt.count;
      }, 0);
    }
    // this.existedviaPage(this.pageNo);
    // console.log(this.extractionCountlists);
  }
  gettingTrainingdata(scorevalue) {
    // console.log("gettingTrainingdata");
    var scorevalue = scorevalue ? scorevalue : 0;
    this.existedcoordinates = [];
    var insideExtraction = [];
    if (this.useCaseType == "both" || this.useCaseType == "classic") {
      this.PdffilesService.getAnnotationDetails(
        this.documentId,
        scorevalue
      ).subscribe((annotationdata) => {
        this.getTraningData = annotationdata;
        this.classificationsCount = this.getTraningData.reduce((acc, crt) => {
          // console.log(this.existedcoordinates);
          this.existedcoordinates.push(...crt.trainingSegments);
          // console.log(this.existedcoordinates);
          // insideExtraction.push(...crt.trainingSegments);
          return acc + crt.trainingSegments.length;
        }, 0);
        //  this.existedviaPage(this.pageNo);
        this.PdffilesService.getCategories(this.UseCaseId).subscribe(
          (labels: any) => {
            this.categoriesColors = labels.listCategories;
            if (labels.listCategories && labels.listCategories.length > 0) {
              this.listLabelnames = false;
            } else {
              this.listLabelnames = true;
            }
            this.options = labels.listCategories;
            if (this.getTraningData) {
              this.options.forEach((opt) => {
                opt.isExtraction = false;
                opt.segment = [];
                opt.count = 0;
                this.getTraningData.forEach((seg) => {
                  if (opt.categoryId === seg.labelId) {
                    (opt.segment = seg.trainingSegments),
                      (opt.count = seg.trainingSegments.length);
                  }
                });
              });
              this.options = this.options.map((opt) => {
                opt.segment = Array.isArray(opt.segment)
                  ? opt.segment.sort((a, b) => b.segmentId - a.segmentId)
                  : [];
                return opt;
              });
            }
            // console.log("data", this.options);
          }
        );
        // this.getTraningData.map((d1) => {
        //   d1.trainingSegments.map((d2) => {
        //     this.attributesCount =
        //       this.attributesCount + d2.attributeList.length;
        //   });
        // });
        // console.log(" this.insideExtraction", insideExtraction);
        // this.attributesCount = insideExtraction.reduce((acc, crt) => {
        //   return acc + crt.attributeList.length;
        // }, 0);
        // console.log("this.attribute", this.attributesCount);
        this.totalCount = this.classificationsCount;
      });
    }
  }
  // myStyles(): any {
  //   this.categoriesColors.map((category) => {
  //     category.colorCode;
  //     return {
  //       "background-color": category.colorCode ? category.colorCode : "red",
  //       // border: category.colorCode? "1px solid Red" : "",
  //     };
  //   });

  // }
  passingCoordinates(segCoordinates) {
    segCoordinates.map((x) => {
      if (x.segment) {
        x.segment.map((s) => {
          this.existedcoordinates.push(s);
        });
      }
    });
    console.log(this.existedcoordinates);
  }

  confidenceScore() {
    var score = localStorage.getItem("confidenceScore");
    console.log(score);
  }
  navToggle() {
    this.navShow = !this.navShow;
    var page = 1;
    setTimeout(() => {
      this.existedviaPage(page);
    }, 3000);
  }
  sidenavs() {
    this.segmentShow = false;
    this.annontationchecked = true;
  }
  pdfsearch(value) {
    this.pdfsearchValue = value;
    if (this.pdfsearchValue.length > 0) {
      var obj = {
        documentId: this.documentId,
        searchValues: this.pdfsearchValue.split(",").map((s) => s.trim()),
      };
      this.bigPdfViewer.PDFViewerApplication.Obj = value;
      this.searchevent(value);
    } else {
      this.bigPdfViewer.PDFViewerApplication.Obj = value;
      this.searchevent(value);
      this.result = [];
    }
  }
  enterKey() {
    var vewerId = document.getElementById("Changepdf");
    var irame: any = vewerId.children[0].children[0];
    var contentWindow = irame.contentWindow.document;
    contentWindow.enterkeyupevent();
  }

  searchResult() {
    console.log(this.indexsearchSegment);
    if (this.indexsearchSegment) {
      this.show = false;
      this.bigPdfViewer.PDFViewerApplication.Obj = this.searchdata;
    } else {
      this.show = true;
    }
  }
  searchevent(value) {
    var vewerId = document.getElementById("Changepdf");
    var irame: any = vewerId.children[0].children[0];
    var contentWindow = irame.contentWindow.document;
    contentWindow.searchevent(value);
  }
  // searchtextpdf(pageNo, segcorrdinates) {
  //   var pageno = parseInt(pageNo);
  //   this.bigPdfViewer.PDFViewerApplication.Obj = segcorrdinates;
  //   this.bigPdfViewer.PDFViewerApplication.page = pageno;
  //   setTimeout(() => {
  //     this.intergatedpdfjs();
  //   }, 0);
  // }
  searchtextpdf(pageNo, item) {
    this.selectedText = item.segmenttext;
    var pageno = parseInt(pageNo);
    // this.bigPdfViewer.PDFViewerApplication.Obj = segcorrdinates;
    this.bigPdfViewer.PDFViewerApplication.page = pageno;
    setTimeout(() => {
      this.intergatedpdfjs();
    }, 0);
  }
  public testBeforePrint() {
    this.bigPdfViewer.page = 3;
  }

  public testAfterPrint() {
    // console.log("testAfterPrint() successfully called");
  }
  deletedsegment(currentPageSegments) {
    var vewerId = document.getElementById("Changepdf");
    var irame: any = vewerId.children[0].children[0];
    var contentWindow = irame.contentWindow.document;
    contentWindow.deletedCoordinatesevent(currentPageSegments);
  }
  public testPagesLoaded(count: number) {
    this.totalPages = +count;
    this.textchangecolor();
  }

  public testPageChange(pageNumber: number) {
    this.pagelive = +pageNumber;
    this.existedviaPage(this.pagelive);
    this.textchangecolor();
  }
  textchangecolor() {
    var vewerId = document.getElementById("Changepdf");
    var irame: any = vewerId.children[0].children[0];
    var contentWindow = irame.contentWindow.document;
    contentWindow.textpagecolorevent();
  }
  existedviaPage(pagelive) {
    // console.log("1", this.existedcoordinates);
    let currentPageSegments = this.existedcoordinates.filter(
      (obj) => obj.pageNo.toString() === pagelive.toString()
    );
    // console.log("2", currentPageSegments);
    this.existedSeg(currentPageSegments);
  }
  existedSeg(currentPageSegments) {
    if (currentPageSegments.length > 0) {
      var vewerId = document.getElementById("Changepdf");
      var irame: any = vewerId.children[0].children[0];
      var contentWindow = irame.contentWindow.document;
      contentWindow.existedCoordinatesevent(currentPageSegments);
    }
  }
  annotationCount() {
    this.show = true;
    this.bigPdfViewer.PDFViewerApplication.page = 1;
    this.annontationchecked = false;
    setTimeout(() => {
      this.segmentShow = true;
    }, 10);
    var vewerId = document.getElementById("Changepdf");
    var irame: any = vewerId.children[0].children[0];
    var contentWindow = irame.contentWindow.document;
    contentWindow.enableinreview();
    this.searchSegment = "";
    this.indexsearchSegment = "";
    this.result = "";
    this.navToggle();
    var value = "";
    this.pdfsearch(value);
  }
  reviewAnntation() {
    this.annontationchecked = true;
    this.navShow = true;
    this.indexsearchSegment = "";
    setTimeout(() => {
      this.segmentShow = false;
    }, 0);
    var vewerId = document.getElementById("Changepdf");
    var irame: any = vewerId.children[0].children[0];
    var contentWindow = irame.contentWindow.document;
    contentWindow.disableinreview();
    let page = 1;
    setTimeout(() => {
      this.bigPdfViewer.PDFViewerApplication.page = 1;
      this.existedviaPage(page);
    }, 1000);
    var value = "";
    this.pdfsearch(value);
  }

  navpages(event) {
    var desiredPage = event.pages;
    var navpage = parseInt(desiredPage);
    this.bigPdfViewer.PDFViewerApplication.Obj = event.coords;
    this.bigPdfViewer.PDFViewerApplication.page = navpage;
    setTimeout(() => {
      this.intergatedpdfjs();
    }, 0);
  }
  indexText(pageno, pagetext) {
    this.indexPageno = pageno;
    this.indexPagetext = pagetext;
  }
  goToPage(desiredPage, segcorrdinates, segmentID) {
    var numPages = this.bigPdfViewer.PDFViewerApplication.pagesCount;
    if (this.module == "Live Module") {
      var navpage = parseInt(desiredPage);
      this.bigPdfViewer.PDFViewerApplication.page = navpage;
    } else {
      localStorage.setItem("Mousewheel", "navigation");
      localStorage.setItem("segmentId", segmentID);
      var navpage = parseInt(desiredPage);
      this.bigPdfViewer.PDFViewerApplication.page = navpage;
      this.bigPdfViewer.PDFViewerApplication.Obj = segcorrdinates;
      setTimeout(() => {
        this.intergatedpdfjs();
      }, 0);
    }
  }
  intergatedpdfjs() {
    var vewerId = document.getElementById("Changepdf");
    var irame: any = vewerId.children[0].children[0];
    var contentWindow = irame.contentWindow.document;
    contentWindow.testevent();
  }

  openliveDialog(clasuses, card, i, type): void {
    this.categories = [];
    for (let i = 0; i < this.options.length; i++) {
      var obj = {
        categoriesname: this.options[i].isExtraction
          ? this.options[i].attributeName
          : this.options[i].categoryName,
        categoriesId: this.options[i].isExtraction
          ? this.options[i].attributeId
          : this.options[i].categoryId,
      };
      this.categories.push(obj);
    }
    if (type === "reassignpopup") {
      this.dialog
        .open(EditreviewDialogComponent, {
          backdropClass: "popuplivemoduleClass",
          position: { top: "15%" },
          data: {
            name: this.categories,
            clasuse: clasuses,
            documentId: this.documentId,
            segmentid: card.segmentId,
            pageNo: card.pageNo,
            pageindex: i,
            reassign: type,
            segmenttext: card.segmentTextURL,
          },
          panelClass: "custom-livepopup-container",
        })
        .afterClosed()
        .subscribe((result) => {
          // console.log(result);
          // console.log("The dialog was closed");
        });
    }
  }
  openExtraction(clasuses, card, type, category): void {
    console.log("tablereassign", clasuses, card, category);
    if (type === "reassign") {
      this.dialog
        .open(EditExtractionComponent, {
          backdropClass: "popuplivemoduleClass",
          position: { top: "15%" },
          data: {
            category: category,
            docId: this.documentId,
            pageNo: category == "inside" ? clasuses.pageNo : card.pageNo,
            methodType: "UPDATE",
            segmentId:
              category == "inside" ? clasuses.segmentId : card.segmentId,
            type: type,
            name: category == "inside" ? clasuses.labelName : card.label,
            attribute: {
              id: category == "inside" ? card.id : card.attributeId,
              attributeText: card.attributeText,
              attributeLabel:
                category == "inside" ? card.attributeLabel : card.label,
              attributeLabelId: card.labelId,
              attributeCoordinates: card.attributeCoordinates,
              attributeCode: card.attributeCode,
            },
          },
          panelClass: "custom-livepopup-container",
        })
        .afterClosed()
        .subscribe((result) => {
          console.log("The dialog was closed");
        });
    } else {
      this.dialog
        .open(EditExtractionComponent, {
          backdropClass: "popupBackdropClass",
          position: { top: "15%" },
          panelClass: "custom-dialog-container-Adeletepopup",
          data: {
            typedelete: "livemodule",
            category: category,
            docId: this.documentId,
            pageNo: category == "inside" ? clasuses.pageNo : card.pageNo,
            methodType: "DELETE",
            segmentId:
              category == "inside" ? clasuses.segmentId : card.segmentId,
            type: type,
            name: category == "inside" ? clasuses.labelName : card.label,
            attribute: {
              id: category == "inside" ? card.id : card.attributeId,
              attributeText: card.attributeText,
              attributeLabel:
                category == "inside" ? card.attributeLabel : card.label,
              attributeLabelId: card.labelId,
              attributeCoordinates: card.attributeCoordinates,
              attributeCode: card.attributeCode,
            },
          },
        })
        .afterClosed()
        .subscribe((result) => {
          console.log("The dialog was closed");
        });
    }
  }
  segmentDelete(clasues, card, i, type) {
    console.log(card, i, type);
    var deletedata = [];
    var obj = {
      documentId: this.documentId,
      pageNo: parseInt(card.pageNo),
      segementId: card.segmentId,
      labelId: card.labelId,
      labelName: card.labelName,
      segementText: card.segmentTextURL,
      actionType: "Delete",
    };
    deletedata.push(obj);
    // console.log(deletedata);
    if (type === "deletepopup") {
      const dialogRef = this.dialog.open(EditreviewDialogComponent, {
        // width: "350px",
        backdropClass: "popupBackdropClass",
        position: { top: "15%" },
        data: { delete: "deletepopup" },
        panelClass: "custom-dialog-container-Adeletepopup",
      });
      dialogRef.afterClosed().subscribe((result) => {
        // console.log(result);
        if (result.data === "confirmed") {
          this.PdffilesService.UpdateReassignvalue(obj).subscribe(
            (response) => {
              var apiResponse = response;
              // console.log(apiResponse);
              this.reduce();
              this.AnnotationopenSnackBar(response);
            }
          );
        }
      });
    }
  }
  ngAfterViewInit() {
    var pageno = 1;
    setTimeout(() => {
      this.existedviaPage(pageno);
    }, 3000);
  }
  prevoiuspage() {
    this.bigPdfViewer.PDFViewerApplication.page -= 1;
  }
  nextpage() {
    this.bigPdfViewer.PDFViewerApplication.page += 1;
  }
  Paragraph(e) {
    console.log("click", e.target.value);
  }
  previousclick() {
    // this.PdfserviceService.send(this.checked);
    this.location.back();
  }
  openSnackBar(message) {
    message = message.charAt(0).toUpperCase() + message.slice(1);
    this._snackBar.open(message, "", {
      panelClass: ["snackBar"],
      duration: 6000,
    });
  }
  AnnotationopenSnackBar(message) {
    message = message.charAt(0).toUpperCase() + message.slice(1);
    this._snackBar.open(message, "", {
      panelClass: ["snackBar"],
      duration: 4000,
      // horizontalPosition: this.horizontalPosition,
      // verticalPosition: this.verticalPosition,
    });
  }

  // /**
  //  * @event infopopup
  //  * @description Shows the details of the brandologo information
  //  */
  // infoPopup() {
  //   let roleId = localStorage.getItem("roleID");
  //   if (roleId === "4") {
  //     this.dialog
  //       .open(SharedHelpPopupComponent, {
  //         backdropClass: "popupBackdropClass",
  //         width: "349px",
  //         height: "320px",
  //         data: {
  //           type: "documents-live",
  //         },
  //         panelClass: "Admin-info-popup",
  //       })
  //       .afterClosed()
  //       .subscribe((result) => {});
  //   } else {
  //     this.dialog
  //       .open(SharedHelpPopupComponent, {
  //         backdropClass: "popupBackdropClass",
  //         width: "349px",
  //         height: "320px",
  //         data: {
  //           type: "documents-training",
  //         },
  //         panelClass: "Admin-info-popup",
  //       })
  //       .afterClosed()
  //       .subscribe((result) => {});
  //   }
  // }
}
