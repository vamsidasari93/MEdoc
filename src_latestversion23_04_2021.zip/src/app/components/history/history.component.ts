import { Component, OnInit, ViewChild } from "@angular/core";
import { MatPaginator, MatTableDataSource } from "@angular/material";
import { Router } from "@angular/router";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { PdfserviceService } from "src/app/Services/pdfservice.service";

let TABLE_DATA: [];
@Component({
  selector: "app-history",
  templateUrl: "./history.component.html",
  styleUrls: ["./history.component.scss"],
})
export class HistoryComponent implements OnInit {
  pdfFiles: any;
  pdfData: any;
  public displayedColumns: string[] = [
    "Sno",
    "Document Name hyperlink",
    "Segmant Text 3 lines",
    "Page no",
    "Category Name",
    "Updated by",
    "Updated On",
    "Action",
  ];
  dataSource = new MatTableDataSource(TABLE_DATA);
  @ViewChild(MatPaginator, { static: false }) set content(
    paginator: MatPaginator
  ) {
    this.dataSource.paginator = paginator;
  }
  constructor(
    private PdfserviceService: PdfserviceService,
    private PdffilesService: PdffilesService,
    private router: Router
  ) {}

  ngOnInit() {
    this.pdffile();
    this.PdfserviceService.annotation("History");
  }
  pdffile() {
    this.PdffilesService.getMaterialPdf().subscribe((tabledata) => {
      this.pdfFiles = tabledata;
      this.pdfData = this.pdfFiles.pdfFiles;
      TABLE_DATA = this.pdfData;
      this.dataSource = new MatTableDataSource(TABLE_DATA);
    });
  }

  DocumentClick(e, filename) {
    this.PdfserviceService.activetabs.next(true);
    this.router.navigate(["Documentslist/AnnotationDocument"]);
  }
}
