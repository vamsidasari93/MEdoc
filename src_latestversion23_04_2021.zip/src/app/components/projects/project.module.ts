import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ProjectComponent } from "./project.component";
import { RouterModule, Routes } from "@angular/router";
import { MatCardModule, MatPaginatorModule } from "@angular/material";
import { FlexLayoutModule } from "@angular/flex-layout";
import { Ng2SearchPipeModule } from "ng2-search-filter";

const routes: Routes = [
  {
    path: "",
    component: ProjectComponent,
  },
];

@NgModule({
  declarations: [ProjectComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MatCardModule,
    FlexLayoutModule,
    MatPaginatorModule,
    Ng2SearchPipeModule,
  ],
  providers: [],
  exports: [],
})
export class ProjectModule {}
