import { ChangeDetectorRef, Component, OnInit, ViewChild } from "@angular/core";
import { MatPaginator, MatTableDataSource } from "@angular/material";
import { Router } from "@angular/router";
import { Observable } from "rxjs";
import { PdfserviceService } from "src/app/Services/pdfservice.service";

export interface project {
  id: number;
  name: string;
}
@Component({
  selector: "app-project",
  templateUrl: "./project.component.html",
  styleUrls: ["./project.component.scss"],
})
export class ProjectComponent implements OnInit {
  hide: boolean = false;
  searchValue: any;
  pageEvent: any;
  project = [
    { id: 1, name: "UseCase1" },
    { id: 2, name: "UseCase2" },
    { id: 3, name: "UseCase3" },
    { id: 4, name: "UseCase4" },
    { id: 5, name: "UseCase5" },
    { id: 6, name: "UseCase6" },
    { id: 7, name: "UseCase7" },
    { id: 8, name: "UseCase8" },
    { id: 9, name: "UseCase9" },
    { id: 10, name: "UseCase10" },
    { id: 11, name: "UseCase11" },
    { id: 12, name: "UseCase12" },
    { id: 13, name: "UseCase13" },
    { id: 14, name: "UseCase14" },
    { id: 15, name: "UseCase15" },
    { id: 16, name: "UseCase16" },
    { id: 17, name: "UseCase17" },
    { id: 18, name: "UseCase18" },
    { id: 19, name: "UseCase19" },
    { id: 20, name: "UseCase20" },
  ];

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  obs: Observable<any>;
  dataSource: MatTableDataSource<project> = new MatTableDataSource<project>(
    this.project
  );
  constructor(
    private router: Router,
    private PdfserviceService: PdfserviceService,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.changeDetectorRef.detectChanges();
    this.dataSource.paginator = this.paginator;
    this.obs = this.dataSource.connect();
    this.PdfserviceService.annotation("projects");
    this.PdfserviceService.searchValue$.subscribe((val) => {
      this.searchValue = val;
    });
  }
  ngOnDestroy() {
    if (this.dataSource) {
      this.dataSource.disconnect();
    }
  }
  projectnav(id) {
    let role = JSON.parse(localStorage.getItem("usersrole"));
    localStorage.setItem("usecaseId", id);
    let rolename = role[0].tab_label;
    localStorage.setItem("selectedUseCaseId", id);
    if (rolename === "Training Module") {
      this.router.navigate(["/Documentslist/Documents", id]);
    } else if (rolename === "Live Module") {
      this.router.navigate(["/Documentslist/Documentslistlive", id]);
    }
  }
}
