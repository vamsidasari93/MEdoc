﻿import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { first } from "rxjs/operators";
import { AuthenticationService, UserService } from "../_services";
import { PdfserviceService } from "../Services/pdfservice.service";
import { MatSnackBar } from "@angular/material";
import { NgxSpinnerService } from "ngx-spinner";

@Component({
  templateUrl: "login.component.html",
  styleUrls: ["./login.component.scss"],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  logindata = [];
  error = "";
  messageres: any;
  errmsg = false;
  hide: boolean;
  selected: any = "None";
  role: any;
  user: any;
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private userservice: UserService,
    private router: Router,
    private PdfserviceService: PdfserviceService,
    private authenticationService: AuthenticationService,
    private _snackBar: MatSnackBar,
    private spinner: NgxSpinnerService
  ) {
    // redirect to home if already logged in
    if (this.authenticationService.currentUserValue) {
      this.router.navigate(["/workspace"]);
    }
    var data = this.authenticationService.currentUserValue;
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ["", [Validators.required]],
      password: ["", [Validators.required]],
      rememberMe: ["", false],
    });
    this.hide = true;

    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams["returnUrl"] || "/";
    this.onSubmit();
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.loginForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    // if (this.loginForm.invalid) {
    //   setTimeout(() => {
    //     this.submitted = false;
    //   }, 3000);
    //   return;
    // }
    this.loading = true;
    this.spinner.show();
    this.authenticationService.login().subscribe(
      (data: any) => {
        if (data === "Success") {
          let info = JSON.parse(localStorage.getItem("userinfo"));
          console.log(info.userId);
          localStorage.setItem("userID", info.userId);
          this.role = JSON.parse(localStorage.getItem("usersrole"));
          var roleid = this.role[0].role_id;
          localStorage.setItem("roleID", roleid);
          if (info.isADActive) {
            var currentUser = data;
            localStorage.setItem("data", data);
            this.PdfserviceService.setgrid(false);
            this.PdfserviceService.loginalert(data);
            this.navigation();
          } else {
            this.router.navigate(["/login/passwordChange"], {
              queryParams: { email: info.emailId },
            });
          }
        } else {
          this.errmsg = true;
          this.error = "Invalid username or Password";
          this.openSnackBar(this.error);
          setTimeout(() => (this.errmsg = false), 3000);
        }
        this.spinner.hide();
      },
      (error) => {
        this.spinner.hide();
        this.error = "Invalid username or Password";
        this.openSnackBar(this.error);
      }
    );
  }

  navigation() {
    let userInfo = JSON.parse(localStorage.getItem("userinfo"));
    let roleId = userInfo.roles[0].roleID;
    if (roleId === 6) {
      //super admin //Admin
      this.router.navigate(["/Admin"]);
    } else if (roleId === 2) {
      // QC
      this.router.navigate(["/dashboard"]);
    } else if (roleId === 3 || roleId === 4 || roleId === 5) {
      //trainee & live & Datascience
      this.router.navigate(["/workspace"]);
    }
  }
  openSnackBar(message) {
    message = message.charAt(0).toUpperCase() + message.slice(1);
    this._snackBar.open(message, "", {
      duration: 3000,
      panelClass: ["snackBar"],
    });
  }
}
