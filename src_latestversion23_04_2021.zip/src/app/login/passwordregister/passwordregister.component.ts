import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { first } from "rxjs/operators";
import { AuthenticationService } from "src/app/_services";
import { PdffilesService } from "src/app/Services/pdffiles.service";
import { NgxSpinnerService } from "ngx-spinner";
import {
  MatInput,
  MatDatepicker,
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from "@angular/material";
@Component({
  selector: "app-passwordregister",
  templateUrl: "./passwordregister.component.html",
  styleUrls: ["./passwordregister.component.scss"],
})
export class PasswordregisterComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error = "";
  errormsg = false;
  inavlidmail = "";
  submitclick: boolean = false;
  horizontalPosition: MatSnackBarHorizontalPosition = "center";
  verticalPosition: MatSnackBarVerticalPosition = "top";
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private pdflogins: PdffilesService,
    private _snackBar: MatSnackBar,
    private authenticationService: AuthenticationService,
    private spinner: NgxSpinnerService
  ) {
    // redirect to home if already logged in
    if (this.authenticationService.currentUserValue) {
      this.router.navigate(["/Documents"]);
    }
  }

  ngOnInit() {
    // this.loginForm = this.formBuilder.group({
    //   username: [
    //     "",
    //     Validators.required,
    //     Validators.pattern("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$"),
    //   ],
    // });
    this.loginForm = this.formBuilder.group({
      email: [
        "",
        [
          Validators.required,
          Validators.pattern("^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$"),
          Validators.email,
        ],
      ],
    });
  }

  get f() {
    return this.loginForm.controls;
  }
  onSubmitclick() {
    // stop here if form is invalid

    if (this.loginForm.invalid) {
      return;
    }
    this.loading = true;
    var emailid = this.f.email.value;
    this.submitted = true;
    this.spinner.show();

    this.pdflogins.Forgetpassword(emailid).subscribe(
      (response: any) => {
        this.spinner.hide();
        if (response.message === "Success") {
          this.router.navigate(["/login/passwordresult"], {
            queryParams: { email: emailid },
          });
          this.submitted = false;
        } else {
          this.submitted = false;
          this.inavlidmail = response.message;
          this.errormsg = true;
          setTimeout(() => (this.errormsg = false), 3000);
        }
      },
      (err: any) => {
        this.spinner.hide();
      }
    );
  }
  onReset() {
    this.submitted = false;
    this.loginForm.reset();
  }

  /**
   * @event - openSnackBar
   * @param data
   */
  openSnackBar(message) {
    message = message.charAt(0).toUpperCase() + message.slice(1);
    this._snackBar.open(message, "", {
      duration: 2 * 1000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });
  }
}
