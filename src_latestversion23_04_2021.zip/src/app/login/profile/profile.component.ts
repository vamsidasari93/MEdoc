import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators,
} from "@angular/forms";
import {
  MatInput,
  MatDatepicker,
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from "@angular/material";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { ProfilePicComponent } from "src/app/login/profile-pic/profile-pic.component";
import { MatDrawer, MatSidenav } from "@angular/material/sidenav";
import { AuthenticationService, UserService } from "src/app/_services";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { environment } from "src/environments/environment";

@Component({
  selector: "app-profile",
  templateUrl: "./profile.component.html",
  styleUrls: ["./profile.component.scss"],
})
export class ProfileComponent implements OnInit {
  @ViewChild("sidenav", { static: false }) sidenav: MatSidenav;
  @ViewChild("autofocus", { static: false }) autofocus: ElementRef;
  @ViewChild("drawer", { static: true }) drawer: MatDrawer;
  changePassword: FormGroup;
  opened: boolean = true;
  activeTab: string = "basicdetails";
  isBasic: boolean = true;
  isChange: boolean = false;
  isContactEdit: boolean = false;
  contact: string = "";
  hide: boolean = true;
  hideOld: boolean = true;
  confirmHide: boolean = true;
  submitted = false;
  email: string = "";
  profileDetails: any = {};
  isEmailValid: boolean = false;
  alternatEmail: string = "";
  horizontalPosition: MatSnackBarHorizontalPosition = "center";
  verticalPosition: MatSnackBarVerticalPosition = "top";
  profile: string =
    "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/wgALCAKAAoABAREA/8QAHAABAAEFAQEAAAAAAAAAAAAAAAcDBAUGCAEC/9oACAEBAAAAAZUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADx6AAAAAAAAAAAD41jVddw2OoK+RzOxbVs/wBgAAAAAAAAADERzomO89Vrhb0XnuR3uR8sAAAAAAAAADHRVoFL72fb9mzl968scHrOoax8Vd/lbIAAAAAAAAAEfxFZXUiyLlgAYmOY7tb2Xt/AAAAAAAABShyPvZBlfIAADHxTHvkhTFVAAAAAAAALeDNQv5q3EBicP7l8sA06FbDb5zuAAAAAAAAKUE6hnJ2zAPNAjPBePc7Ju/egxEEYPb52qgAAAAAAAhePc5PuRBRhLSAG8TZWBj4BwchTQAAAAAAAEfwtf9CZYCEdDAG+TcBiee7Cat/AAAAAAAMdznaTtuQGlwSACdt0A06CLvo3IAAAAAAAIZjuRJmAQFqQANtn0BDMdyLMoAAAAAAGI5xq9IZACjzBSABV6frAWHN1Lo7LgAAAAAAiKMpOlwBiObAAHSeXARHGMmy6AAAAAAHxzTY9I5YBjOaAAHS+TAYnm6+6W+wAAAAABq/Pu09AgHzzFaAAu+nfoA5+1boLaAAAAAABFcUyxKQAhPQQAb9NgAi6JpWlQAAAAAAQTpk+7YAMHzvRAFbojOADU4C3OdgAAAAABzhhemr8AI4h3wB7MUjgBYcy5ro8AAAAAAcv0+o/QAR3ENuC4l6RAAecuVOoAAAAAADzlm86bAAYuNtPw7MbhJOUAAcyWfU3oAAAAADzlm86bABTwWwgNeztQAHMln1N6AAAAAAcv0+o/QCjHMa4zYd72bJsZrGi69k5KkasAecuVOoAAAAAABzhhemr8Bq8L4UPfHvgZqaNoAWHMua6PAAAAAAEE6ZPu2AR3D1IAAVZhkQDU4C3OdgAAAAABFcUyzKII3h7wAAHswyQCLomlaVAAAAAABq3P21dABpkGUwAAFSdNyDn/VegtoAAAAAAHxzTY9I5YsOdccAAAMj0XfGJ5uvulvsAAAAAAIijKUJaIcjgAAAEjzGRLF8my6AAAAAADEc41ukL/G820QAAAVukslYc30ejsuAAAAAABDMdyJM0XxKAAAAlqUIZjuRJmAAAAAAAY/nK0niK9ZAAAAbNKkD3fRmRAAAAAAANAhW/tKQAAACrd2E0yAAAAAAAAEMR4AAAACQpoAAAAAAABSgnUAAAABt87VQAAAAAAALeDNQAAAAbfOdwAAAAAAAAUodjwAAAEhTHVAAAAAAAABoEQ2QAAC9l2QAAAAAAAAADHxVH9IAAVZAlTIgAAAAAAAAAxMcaHj/AB7kN8kfLAAAAAAAAAAD41nVddwuOoK+RzWw7Xs32AAAAAAAAAAADx6AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH//xAAqEAABAwMDBAMAAgMBAAAAAAAEAgMFAAEGFDBQERITIBAxQCEiMmCgNP/aAAgBAQABBQL/AKYVKsmxM6APT+V09kcg5Tkoc5Sn3V11vXW9JfdRTcoc3TOSSDdD5XQs6ARSVWVb/QDZAYKxuUOKoowgq/oltaqsITeriE2pTa0+ophAtwcpcTQUgMbbnDDGA25LJHnqUq61Va3W4kGcTQ+KJpiAj2qbDGa9XAxnafgI92iMUTRcGcNV7dL0lV0KjckeZoMxgxvmZjIGxqJIdKdphlx9yPxdaqDjxQ7bhkeKZY/F1pp9lxhyhiHRXYfIWyeXcWlpE5PKJ+LVFY46/QgjAbf4CxGDG5XHHWKv8Qc8oWm1pcRyb7qGGpuYckF0IK6W9DQjINth+RDYurIY21IyGNvTEiG/szMIydYsV0R6oSYcj1suofa5FxaWkTssqQdqMj3pB+OAZAY95PI2B6MlCy7+gcoWJeLyNgjYkQGT2JSPej36gpZUe62tLiOQyaW1LlRce7IkgiNBD+zriWW5uccNVsQk44EppxLzfscI0aPKR7seTWMy2lc4/KZPTM0GM4WRGAtgDe+Syuse2saldG97yQLZ4xgzghFYtJ6lnjTykBiFPrKIrHYzQi++UH6QHcxc7Vg++RxeuFoV9YpABSDBOMy4/wAxVYpHecjYyUnUSu5jJWmldjK47TkViR/hK4uULsECpV1qHaU+8CMgMX3dX42lqutW4hV0LZX5Gvc4ZBgpDSmHkquhUWXY0HisyL7nqw0Puc2Je/bF70Rfui9jMg+1ysML7XuJVeyUnkXKMtbreLF0YGxJp743ejE9kbsSousAvbpcAi4pib2UniMlI08RWODamW2VW62KauwRuCtXfITbpbZyMbTS1Y0RqIjiM2e+MKZ6J2suF8R+5iIvlO2s1Y/pWEvcTlrvfMVjDXihtqYBseCtCm17SEKcXDg2AB2snZ8sNWJOdkzxEyvyStAo8QW3k8R59vGYjwbh6PKFUMvxyvEEq7yGk9zm7OQFiKdaWyv2aaW8uDgLD7zqe1wZXYRw9/pX+QP/ALd40Ac5BuLOJp+KOYpSFJpKFKpiKOfoPFnL0EAOEjeO/g233b64a/1f7B/g3cUqyEpmAFP7CpgBL6VWWncO/k233b64clPYQ0rtc2nXENIkcnQmjDiDFUBLlhULlTd6ZnY5ykyAaqVIBps7OxzdE5U3aj5cw34DOIDVHZOhVNOIdRtOq7nBk95HETKPHK0CvyhbEvMMR9pCQIOc3o+QIBXEzDEhbYPX4gqhkeSV4jLW+yZrGHvLDe8/O2HparrV+BCroVAzuo2Mnd8UNWJNd8xxGbM/GFP/ANPbJJrw/lxua83vmr3RFYSzxOSj6iIrHCdNLeuRSmgHvfrf8lr9L47Ka8f1yMnUy1Y0Pp4jiFWspJ49xTLX6XiytYB8mEoEGNJWYT+YIlYZIZKCxvmUK0YF79bgD3KMTayU8TmYna9WGmdrnzlx/lI/RiB/iI+cyM7nKwwTue4qUEsaCpN0KHdUO+CSgsWpAmwYbi1OOfobWptyPJsYFRxKBBSHVEPpTdaosSwQPF5cB4SqxOR8BFZoT0R+rCyuqKyuR879YiB5iuMPFQYIUwsYj6rHZPXi5C/55b9WPP8Aglsik9CN90KwskgAVAYvG5TGalmgiXAyFqutX6kKuhRpLhhFYvGaZnj8midM5+7GYnUucg4hLiJ6JVHu/sgolUg62hLSOReaQ+1Nw7kev9UJELkFsNIYa5NxCXETkCob9MJAqJptCW0ctMY+2VRI7orv5Bh3SnYfH2xeaMDYMbk8beZpSVIV+BKVLVG4289QYbAbfOGx4xtjsWcTRQZAt9wUMgq4WLuKoKPGCt/oCk2VYqCAIojFKexuQbpyLObpTDqK6XrpeksOrpuLOcpnG5BymMUoWCAHpKbJt/0w/wD/xABAEAACAQECCgYIBAUFAQAAAAABAgMABBEQEiEiMDFBUVJxIyQyQlBhEyBAcoGRobEUYmPBMzRzktFTYIKg4ZP/2gAIAQEABj8C/wCzDexAG81lm9Id0eWur2f4uazXSP3V/wA1nWqb4NdWdK55tWutdZsrjk1Ztqm+LX1nOknvLXWLP8UNZJvRndJkq9SCPL/YPWJQp4dtEWOPEHE+U1faJXfmfVzVY8hWSzy/2Gstnl/sNZysOY9W+zyunI0BbI8ccSZDXV5Qx4dvjuPaJAo+9FLGPQpxd6izEljtODJV4hxF3yZK6zaCfJBX8DHP5zfXRwRJyQer0kETc0FfwcQ/kN1dWtBHk4q8w46748tZcAZSQw2iglsHpk4u9WPZ5Aw+3jRisl0k2/YtGSdy77zgCQozvuFBra+KOBNfzrq8KqeLb89L1iFWPFt+dFrE+OOB9fzopMjI+44BJA5R94oRWu6ObfsbxcvIQqjKSaMNkJSHa21sIktd8UfD3j/isSzxhB9/YcS0Rhx9qMlkvlj4e8P84RDayXh2NtWg8ZDKcoI8UaSVsVF1k1iJm2cal388AigTGY0HkultHFu5aHpbTEp3Y1fxyeSGv45HNDV0VpiY7r9CZEujtHFv50Yp0xWGDEbOs51ru5UskTYyNqPiTO5xVXKTWKmSzrqG/wA8GJEM0dptgr0cI5ttOgKWUemk390V00xxeEZB6vQzHF4TlFBLUPQyb+6dB6OYcm2isSUZvdbYcGK+WztrG7zpXjIZWygjxE2aA9CpzjxHAI48i95twoRQC5R9fXZ5CFRcpJoxQEpZ/q3PQiKe97N9V5UskbBkbUR65inF6n6UY5Mq91t4wCzTnoWOaeE+IfhoT00gy/lGBIYRe7UIo/8Ak286D0ELdXQ/3HR+gmbq7n+06AxSf8W3GnhmFzrg/DTHpo9X5h4dJPJqUat9PNKb3c34MeQdYk7Xl5aD0aHpZcg8ht0vo3PSxZD5jZoMeMdYj7Pn5YEmiNzob6jnj1MPl4aLMhzIu172D8TKOjj7Pm2hlu7MeYNLFwyZh0P4mIdHJ2vJsBsshzJez73hks+0DN50WY3k5TSRR9pzcKjgj1KPnoHc90X0WOs5dKGGsG+kcd4X6CSCTUw+VPFJ2kNxoMpuIyiopxrIy8/C47KpyLntzwPa3GRc1Oe3Q2sj/Sb7aeyH9JftoUtaDI2a/PZgksrHI2cvPwok6hlqaY99r6uFQw7VGXnobUu+Jvtp7Ku6JftoZodrDJzq41DMO419ArqPhM13afMHxwQg9lM8/DREHbUsR1oxXSxRDW7BaAGzRTAdl88fHBDf2kzD8PCbPCPNzgtE/JBoxOOzN9xpTOezD99HZ5+aHBaYeTjwl14FC/vgg3ve+jeLv61PnTI4IYZCNGqICWOQCki7+tz56Ofelz4EXjUr+/hNrb9QjBBHwoB9NIbVZl6QdtRt0YtVpXpD2FOzSTpxIR9MFlb9QDwmVt7E0i7zdpjPY7ll2psaikqlXGw+uEiUs52ChPbLml2JsXTMu43VE25gfCTVn/qL99PdaIw247RV9klDDhfIa6SzScwL/tWcpFZqk10dmk5kXfer7XKFHCmU1dZ4wu87Tp7R/Ub70PCTVn/qL99KWYgAbTXoRaUxvp89D6I2lMb6fOgykEHaNLaP6jfeh4TKu5iKVtxv0ZeRgqDWTRSxLjnjbVV9olZ/LZgAilJTgbKKutUDDzTLX8wF94XVktUH/wBBWW1wf3iv5gN7ovrq0DN5vkoiWUhOBcgwX2eVk8tlBLamIeNdVB42DKdRGjZt5vqJd7AeE2tf1CcEEnEgP00OL25tiD96vnfJsUahp8aB8m1TqNYvYn2of20M8nChP0wWRf1AfCXbjUN+2CDel6aBrPYzfL3n4aLOSWOsn2EMhIYaiKFnthul7r8Wgn3vcmBG4FLft4TZpuaHBaIOTj1zZbK3Sd9h3fZRZbW3SdxuL17PBvvc4LTNyQeEzXdpM8fDBCT2XzD8fWxIj1iTV5DfV51+y3jXWJKesJr/ADDf6013ZTMHwwQ39p88/Hwkg6jU0J7jXVeKhm2sMvP1Hml7KinmlOc309nSaLtL9aSaLssPUmm2qMnOrzUMI77XUAMgHhUdqUZGzW54HsjnI2cnPb6gskZzI8rc/aTZJDmSZV5+olkQ5Fzm/bBJamGRcxefhcsB1kZOdFWFxGQ0kseRkN4qOaPUw+WCWdu6PrTO5vZjeT7SrobmU3g1FOvfH1wSTyalHzp5ZMrObzQVReTkFRQbQM7n4YLUgzJe172D8LKejk7Pk2CGzDbnt7XNZm2Z64PwsR6OPtebYPxTjMi7PveGyQSamHyp4ZRc6G7BiyHrEfa8/OpzsU4g+HtcB2McQ/GsWM9PJ2fLzwJDEL3c3VHBHqUfPw78TCOmjGX8wwLNCbmWix1nL7WGGsZaaaY3s2D8TMOmkGT8o8QNpgHQt2hwn28WmcdCpzRxHxFkkAZWFxBrGTLZ21Hd5e24z5LOvaO/yoJGAqrkAHiTRyrjI2sVjrnWc6m3c/a8d82zjW2/lSxxLiouoDxQpIoZTrBozWQF4dq7V9pE1rBSHYu1qCRgKo1AeLmWy3RzbtjUY50KONh9lEcCF3OwUJbXdJNu2L41iWiMOPtRex9MnD3v/aIYEMNh9hAUEsdgoPbOhTh73/lYlnjCj7+O9YiDHi20TY5MccL5DV1oidOY0t1nid+Qq+2SYg4UymurxBTxbf8AYNzC8Vlh9G2+PJXV7R8HFZqJJ7rf5rOsk3wW+s6JxzWtVaqzYnPJazbJN8VurORI/eb/ABXWLR8EFZIcdt8mWrlFw8v+zF//xAAsEAABAgMGBQUBAQEAAAAAAAABABEhMUEQMFFhofBQcYGR0SBAscHh8WCg/9oACAEBAAE/If8AoXcYpxj/AIknFcyME/AOCfOSp7XQLRi/Jafi/Ba9YUTTLugKRd1r1gWn4vyTEwZf0yo7XQpkAcE+ckLmmRJx/gX7QoRPomxdkCS5DLAHISHp1nUqaHZgpIdmC1nUenkMsA8xIpgXZAkn7WhQDpx3CeePIKp+DFTeEeGjkjk9bCAAOTIJiK3VpoQPyB6lakC/hCO3T6QAAhaQ4ihHf59LVoXRJGB+YPUJ2KFuiaIQAxExYeGjgjEdU/BgpPKxnmK8wpxqGxQO85Rwsqbaw+cUXK7gcdSdNEOfVenXIhu0u0GHRIh5xRY2DCypt1GYoDebi47JuTABUejI8YsAksJp7s2gxx60+YzPsTinrz5DMLG60AEFjOyjcZnnCH5NycEcUCGAegRm4dmZ7BvXbDMmizVgEOV93La5wD2CKw2TREWOyaI66EoJ7G5ydUEOV9o3rtjmDWwTdO81BxgHBxIdcJzIBPPJ/PYrIb0QsndELRdabn6yQA5gjowEI9SqPg5/zR6R4Mf80ooEJj/ggQQ4j6zaLpTcQorxSZNjzyfz2BD4lMARxHC3xuYWQAyLcFVBoNSxPrFHChAKUobS8LK5MpJNPwskOkDyRHroTQaliFGTI07LGXxuY8Qk5iI2ubH0g7DEoH7mdTGuDkrgR3uWF2cNMie9yxuBWsZ1MYJ9IO4xFk/IIzthw6ohhiUCjyAeEASQBNDlMd1NPK4kCdxqi9miZe6i4BKY+TVCCCQZqHIB4WIghiqOG/YNPxY7RvAdkLlvF9fPW9YRP38tblsjeAbI2fUBP1wwyGggNSkjWi3DMmqH44glTIz4qm4FIRT6BHPc5I53px2GA5hAkIY9RcUyM+KhQ/GMEjWi3BMGiaYghFAnwuU49RLSz7WGTdrmqz7F+UtsC5+lhk3ayQQ9JPThRR2E44BTEyAMqDsiCA5MghBW1tE63JxEwNV+chMDRcg8LaI1RDAYiYUxMBDKo7IqTicHEcJcZSfmaPY0hy/W1a6DLQMVMbB0N7IbB1KDLQMLppDE+5q9jjL+M0bhO7CgsfSp+Qbs4nCj2jenG4UOeAu3gRI/IFk52GPCdmcPKzmgOphpdwkgOWFGAu4mCJ3ZgLsJkmShJJQlTu+QA6GOlmDGneHCcEG3QtZ/MnvBQdhZDiM7s4MwshxOd5VOxmEWuLcJ2BhWVnqQAAAFL0uIXGVyMCoV3CNiPXCu4BuSi4ocZ3MxN6WIYyWZ3qWwMPCJiJyZoHFj8C/enBk8gosd7gZIyYPJ+6EmLZghEmJZB0ZEHk/dDY3sBkntg5vMN+DLD5ChNmpHB5ihFmidYfAvZ8NiMAhAtj2BAvaQ80A0rSWRANGuLQo0NgRwet6TrH5CjFmpHCNiYVkd6kGIcSugutctgE0nyPoFVkTxGDkJWMSHb06JkIcVnYoDA7AyBHP2YpyC7sVOTsDI+gxjs7BODnb162Zk8Bi5iSaS5n1Ciiu/LcG6JABJoszvUtiYeE4IaovYP9b7kRlHEVLmoo6gmm5Yv4bRmu54QmBaER8q3P8AFvsYIaIvwnBjTvCzmAOhhpcMoS6GQZovFHIck+xLxRyGIKG2ZdDKcDcQ5QOpjpZgZp3lwmEHYcWPEmR+AfXyNdEGfteRiXQc/W2NXwBZCLsOeEsMP6zR7HgMT6mvqHJ1vNEY5SSLkmvtTDKQBcEUQ5Odxr6ngTk+5rYxwbwzRuEjTcTEZKoGAcqaIgiMREIUP7GEDr6DfM+zJoOqfqHdqBQD2572K7UCoKN877kcPQKE9zKA1RDEcmJVAMI5V0Q02TAYDhUgh6aWlm0ggej5wR/PuSaID+/R9pB0WSDHqp6cLaYijNAkjWi2DMGqPIyqqp5sVRZjWYGNA7ooAgZUmfuSgAAlCJKlIkjCod3sqo5sVAjyOqjWi2BMmiEhoohUp8M+iKfqx0iWI7I2O7n6QgPduKn70DY2xLENkLHD5U/HDcBDHFQqPoB5QJIEFigyMAZNPJb+oHu9/UBAlybJQkkSS5UPQDyqDGJxVPDpuYCNsLHbC6EYFTjUlz92U2KA5p2wugGAsl5gJ2ueIT9+BuY+/wAbfG5hxGfxIAITDyfz2L3rXif4ZDulIABxIcYBiIzdO8X3YfcOzMqBDANQcUD4NgHBCLzozPKPc1+jI8YQfJsEwA4uceqJ3mW8PBn7XeHgyRxpojec8awnjjyGiLEHFSIYOjEDEdPYmDowA5PRPwOCmTGeePMa8dbtChAOqYF2QZLmMsA8jK95jLAHMyTYLsgyTdqQon1/wJOIWYIcFORCSp8ZIM9rqE5MWX4LV4X4I93sCIpl2QNIuyPd7CtXhfkmJqy/JDntdSmIhxj4yQOIGQBgP8SwwTAUH/Qx/9oACAEBAAAAEP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AH//AP8A/wD/AP8A/wD/AP8Av+3/AP8A/wD/AP8A/wD/AP8APbx//wD/AP8A/wD/AP8A/ofhX/8A/wD/AP8A/wD/AP8AP/3v/wD/AP8A/wD/AP8A3v8A/wAz/wD/AP8A/wD/AP8Au/0/3f8A/wD/AP8A/wD/AC/5h+b/AP8A/wD/AP8A/wDf3/Pz/wD/AP8A/wD/AP8Av9/7+X//AP8A/wD/AP8A/wD/AP8A/b//AP8A/wD/AP8Af/8A/wD+v/8A/wD/AP8A/P8AP/z+P/8A/wD/AP8A+/8Af/8A/wDf/wD/AP8A/wD0/wB//v8Ar/8A/wD/AP8A9f8Af/7/AK//AP8A/wD/AP8A/wD/AP8A/wC//wD/AP8A/wD/AP8An/n/AP8A/wD/AP8A/wDv/wD/AP8A/wD3/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AOn/APWP/wC//wD/AP8A/wD9/wD2b/8Av/8A/wD/AP8A/wD/AKIH/wD/AP8A/wD/AP8A7/8Af/7/APf/AP8A/wD/AP8A/f8A/wC//wD/AP8A/wD/AP3/AP8A/wD/AL//AP8A/wD/AP37/wD/AM+v/wD/AP8A/wD99/8A/wDnv/8A/wD/AP8A++//AP8A/wDf/wD/AP8A/wD8X/8A/wD+P/8A/wD/AP8A/wDf/wD/AP8A/wD/AP8A/wD/APyf/wD/APt//wD/AP8A/wD+3/8A/wD7f/8A/wD/AP8A/wB//wD/AP8A/wD/AP8A/wD/AP8Af/8A/wD8/wD/AP8A/wD/AP8Av/8A/wD9/wD/AP8A/wD/AP8A7/8A/wD7/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD5/wD/AL//AP8A/wD/AP8A/wD+f/5//wD/AP8A/wD/AP8A/wCH6f8A/wD/AP8A/wD/AP8A/wD+/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/wD/AP8A/8QALBABAAECAwcEAwADAQAAAAAAAREAITFBYRAwUFFxgaGRscHwIEDRYOHxoP/aAAgBAQABPxD/ANCs7ErIOrQ9gukmyf8ABybDJAHNVAqIQkLfi86KXQfS+ang1y91QAjxyR6QpCW/vytLSt5qpaRvMVIS39+EoADhkj0lUAPZA81BJo/pfNSWkib9vWgXLIiHMRT/AAGRaEo7Uy0/ZlEPVDZ5qZ9GRb0mPxPqqHIaBkrRvagMlal70+qocw/GZ9WVZ1maE7vZh6q7vFQY0mw+rvx1/ktbtyK6prCBIPw1Smhcjmq67GzOACVdAo9D3kj6r/ShSIumH30ocVf8vSeFACEzZ8UgAAyCxUdajrQQCTMb0gJXNjzSTR/eRfCkSBuEH30oK48pH0R402ZyIQjqOwKaFyOYLjT+ECQPhqdFsKzOTXXGl1T0uWqxKT4IyAwBkGzBaK/rMYGtAi4zF0MA80NIHCu6SO9GIHAIXSBrLfEU6Vhd4rFaK/rE4muzApPijMTAOY0m+Ilw3z4u414gLNWl3vb/AOxsRYKkAKkEKAkfHQDmmMpza5+jepaRhHMrlMqkyZJ9re7SlYIFEdiVoq5BSO34pLMTii8evQD+6UxE6w0y2V6NUFhzwAObQ5Yy/wBNtwkpgYYwH1kaiKXP5VRCJz+BUHkia+k1JuCRfcj6RY4aqvRqhuOWADzNjOzvEVn/ACovPX7J/dOJOTqqAiVVpezGU7JOEiD9U83lSCGoT9cjwfm6UASqxakBJLEui/bQ6MF1IonbNLoyXViiwKwxLq376NKBBEZt+doGFPfZj7UuJNTpzRyeZsPkxnNSDUrwlcSOIr0jzHZEFYsTzTzXIoZpJW+fbNfzW6VSBUKysp9RuQ8nIfWKAQGuSr8zO3gwZVskokLkgnNHJMzY/QPNeIStOBfdfbYWOcGQV1sgKzATCM0txgXFgTxxXG7YcwYFcMVluGV3QTCgosc4cxrjZibFx+L7j82Hpw6LORIBwR1WpRgvkchyAsUbKpAC6tW1BZjH+XcEa76GPpTvvVO76ufqHbcXF1wY4vymtGygURsjUIwXyea5iWafu0VRTxNR4azOvMMG/j52T6pwFv5fzuXmV7Xr+e9SB2uev47m2ssBb+XvnY8QuMsr+fY4ZMTdgVsach25IZTqtdXvpLF9KIWzUIcRdV3EfHbZGk9czJMu90NQMklQ8dpgdwdt6Iy4g6jeur30hi2lGQ7YgMo1GowJsGtj68LfAHMY2D2l67Bm3EuRY1IHfco6gR9y3+OWzvQNzbtwLkXNWR22Pg/tMLB7w9OFHnaXgBKugVJEKzKcdiFNQWAXVwAovgBZnefU7m+OKNd/EtCo1NzJ8JC3K8+gpqC0SyOCNSRIsznHclRnSj4ICJonCbFgdXZ4diLtTpXerdQciwnMSGpaSWOaG9lpYY5gUGAELkBBurVfdO70bJJkB8Ty8JWOmfb5thj4XbofObuNDNRgAeCN6bFkyzF8E7spAXZyT43ZY0Ke/wAXCYOZC/Jsm1AbuP2Dd27VL6Ts4PWmJLPhSA6juyJLPlSAarXv6Ap2MDpu5uAt2P7jsu1EL6QcItRYr2Iw9thnAW7UJ3i1JY1zyszu36WbXfKye8F8BH6qDZLbEl0me9HB35plcVu7a/7aQKtAAgN7z7RZc6Ds1lKuj+bs1lKuhUXio0rnk3qUhKIa/wCVkimFxG7Fo+eDuFzBpEMVPmjZwB60HzvihFQPRlysiSrZoG7xRgM4q84Uj5BOea0GW68UYLeCvGFY6tt80XZ5puVQT1Rd3z80YOBPShomII9aUo4wcHChmjRVMRe9Gjgz0oPneBzaTic1YApGdLTZvIj76ASMmyKAQBNaAQANKjYAlYKNuV5qeRJf3o+XQsXMFk3j80YODPWgomKI9aEBocHfmnRxS7Mr/lZBphSUSbqJuAJNVpvA3C+6+FYjTMB0WBUtB2dT0AG9B+A+KncPeuqh3PUiu120o0nr+KG8pTfwRRGT8PkPegcQG4aIXolrEaZkOqyqdwJwPuvlRFmgI9E3VoAErX/ayTTg4hdyUfPB2osIhujH32GpGW6gu5WkloN5HIVLtJKd+CXiQU0A+Ugbfm5Dci0hDdUjZNhMt0J+1HCLNRK+kmzF1Fu5/cNwoLZxmL1KpMU0SZVW6v6ITFNAmREuJSzVhEHgPd3EJQdYx+y7JOJV+DhP0pnb5thSAm3knxn5tb7F64zbKqqqsr+mKIjCU1+kH7i16b+/8zQwizkHzuyDrM7/ABcJSdAO8ny7F3tpcIs9n8gQVHNlPxouxSUqbqri/qjsUlCi4iYNOCRrugH21dfyCP2hwiz3dip4HzPDwkL9p2ChEqRpXzOcrvCmMLELIjI0EVFCaJ9D+F9eUmMEOqtU04ewNEH6/XyqC2iSrY8pMuEvUbfg10NC6J9VMYWo3VWVqRoTzKcrtKhPhHwAgDhT476HC43rL02BHmLGQsdvb8GlhbGHL7Pf9mNS7JhHc7Pb8JHHBzOXO3vsfFME43GdIevC4QLsGvn605DtiAwHUannoNRmHRwaZq3vE4C6jJsjiR3Z1u8isZe8ipT1f2cZe8ipR0ajjAHwwu0NhlIfzsAdVip56DVZg0MCjIduSGAarUxM2BXz4Ytw+IZX8fOy3MVZZvj3RshblwPozP7bXgKTlY+sbCnBqy2F6bL3pYlnfx8cNPm4BBTwNRqdOI5MYBzEuU5IERLI1nOcuj3cNVRSjKjCP7T+2zqEqcI/tFWn2Q45rpySKq3VqNOI5E4pyAu0LMgggrddV4c8DUB3H3cWzBPoN1YlmNKNLTzTL+3EcaeQZKxR6BYWBZBscrNB3X24gN0j7X9+XoHmPEZOpDhKyNL2Yzn92TZoZCqTMlGAiAOJN56fZP7rROxvEVl/b9s4I1hJnUPHp0A/uvFHWfPJZJVzfz/7X7K3b+//AGKT+6NBWADI4vdnyFDdM/Ssagw4mSOA5J+rhUGHAzVwHNasRNCluNUF0xtmcwuqxZJiD4aTl0OXyVc/RnLocvkC7T2MmIfhoHzWl2M0uuOxPwgnbm9J2cRD0Q3eKmXZgWdJu3sy7MK3rNlL3+zD0V2eakepAO9d/wDASE7AwOSJFXVQXGeifGpDq/pfFMQ1mbxROMAxEesqgjf35CloO6qloe6KoI39+BqMYDgI9YUxJWavFBI1f0vilBUSM83xokewYDkAQH+DxsWbleaFDJCeYGyP/Qt//9k=";
  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    private PdfserviceService: PdfserviceService,
    private authenticationService: AuthenticationService
  ) {}

  ngOnInit() {
    this.PdfserviceService.annotation("useCases");
    let userId = JSON.parse(localStorage.getItem("userinfo")).userId;
    this.getProfile(userId);
    this.changePassword = this.formBuilder.group(
      {
        // username: [
        //   this.profileDetails.email,
        //   Validators.compose([Validators.required, Validators.email]),
        // ],
        oldPassword: ["", Validators.compose([Validators.required])],
        password: [
          "",
          [
            Validators.required,
            Validators.pattern(
              /^(?=\D*\d)(?=[^a-z]*[a-z])(?=[^A-Z]*[A-Z]).{8,28}$/
            ),
          ],
        ],
        confirmPassword: ["", [Validators.required]],
      },
      { validator: this.passwordConfirming }
    );
  }

  // convenience getter for easy access to form fields
  get f() {
    return this.changePassword.controls;
  }

  passwordConfirming(f: AbstractControl): { invalid: boolean } {
    if (f.get("password").value !== f.get("confirmPassword").value) {
      return { invalid: true };
    }
  }

  selectTab(val: string) {
    this.activeTab = val;
  }
  editContact() {
    this.isContactEdit = true;
  }
  closedOpened() {
    console.log(this.drawer.opened);
  }
  /**
   * GetProfile - Get Profile information
   * @param userId
   */
  // getProfile(userId: number) {
  //   this.userService.GetProfile(userId).subscribe(
  //     (res: any) => {
  //       if (res.statusCode == 200) {
  //         this.profileDetails = res.userInfos;
  //         this.profile =
  //           res.userInfos.profileUrl != null || res.userInfos.profileUrl != ""
  //             ? res.userInfos.profileUrl
  //             : this.profile;
  //       }
  //     },
  //     (err) => {
  //       console.log(err);
  //     }
  //   );
  // }
  getProfile(userId: number) {
    var addurl = environment.urldata;

    console.log(addurl);
    this.userService.GetProfile(userId).subscribe(
      (res: any) => {
        if (res.statusCode == 200) {
          this.alternatEmail = res.userInfos.alternateEmail;
          this.profileDetails = res.userInfos;
          // this.profileDetails.alternateEmail =
          //   this.profileDetails.alternateEmail != ""
          //     ? this.profileDetails.alternateEmail
          //     : this.user.emailId;
          this.profile =
            res.userInfos.profileUrl != null || res.userInfos.profileUrl != ""
              ? res.userInfos.profileUrl + addurl
              : this.profile;
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }
  /**
   * Email validation
   * @param inputText
   */
  validateEmail(email) {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }
  /**
   * saveProfileContact
   */
  saveProfileContact() {
    let body = {
      userId: JSON.parse(localStorage.getItem("userinfo")).userId,
      alternateEmail: this.profileDetails.alternateEmail,
      contactNumber: this.profileDetails.contactNumber,
      changeType: "contact",
    };
    if (
      body.alternateEmail != null &&
      body.alternateEmail != "" &&
      !this.validateEmail(body.alternateEmail)
    ) {
      this.isEmailValid = true;
      // alert(1);
      return;
    } else if (body.alternateEmail == "" || body.alternateEmail == null) {
      this.isEmailValid = true;
      return;
    } else if (body.alternateEmail === this.alternatEmail) {
      return;
    }
    this.userService.SaveProfile(body).subscribe(
      (res: any) => {
        console.log(res);
        this.isEmailValid = false;
        if (res.statusCode == 200) {
          this.openSnackBar(res.statusMsg);
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }
  /**
   * onSubmit()
   */
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.changePassword.invalid) {
      return;
    }
    var obj = {
      emailId: this.profileDetails.email,
      password: this.f.confirmPassword.value,
      oldPassword: this.f.oldPassword.value,
      isAdActive: true,
    };
    console.log(obj);
    this.userService.ChangePassword(obj).subscribe(
      (data: any) => {
        if (data.message == "Success.") {
          this.openSnackBar("Password updated successfully.");
        }
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  /**
   * Open the model When select all time
   
   */
  openDialog(): void {
    const dialogRef = this.dialog.open(ProfilePicComponent, {
      width: "700px",
      height: "450px",
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((res) => {
      if (res != null) {
        let src = res.src.split(",")[1];
        this.saveProfile(src, res.fileType);
      }
    });
  }

  /**
   * saveProfile()
   * @param data
   * @param type
   */
  saveProfile(data: string, type: string) {
    let body = {
      userId: JSON.parse(localStorage.getItem("userinfo")).userId,
      profilePic: data,
      fileType: type,
      changeType: "profilePic",
    };
    this.userService.SaveProfile(body).subscribe(
      (result) => {
        if (result.statusCode == 200) {
          let userId = JSON.parse(localStorage.getItem("userinfo")).userId;
          this.getProfile(userId);
          this.openSnackBar(result.statusMsg);
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  /**
   * @event - openSnackBar
   * @param data
   */
  openSnackBar(data) {
    this._snackBar.open(data, "", {
      duration: 2 * 1000,
      panelClass: ["snackBar"],
      // horizontalPosition: this.horizontalPosition,
      // verticalPosition: this.verticalPosition,
    });
  }
}
