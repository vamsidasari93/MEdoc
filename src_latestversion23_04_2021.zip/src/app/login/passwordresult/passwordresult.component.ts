import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-passwordresult',
  templateUrl: './passwordresult.component.html',
  styleUrls: ['./passwordresult.component.scss']
})
export class PasswordresultComponent implements OnInit {
  email : string = "";
  constructor(
    private route: ActivatedRoute
  ) { 
      route.queryParams.subscribe(params => {
        console.log(params);
        this.email = params['email'];
        console.log(this.email);
      })

  }

  ngOnInit() {
  }

}
