import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "searchPipe",
  // pure: false,
})
export class SearchPipePipe implements PipeTransform {
  transform(value: any, ...args: any): any {
    console.log(value, ...args);
    if (!value) return null;
    if (!args[0]) return value;
    let propname = args[1];
    args = args[0].toLowerCase();
    return value.filter(function (item) {
      // return item[propname].toLowerCase().includes(args);
      return item[propname].toLowerCase().startsWith(args);
    });
  }
}
