import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'insight-card',
  templateUrl: './insight-card.component.html',
  styleUrls: ['./insight-card.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class InsightCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
