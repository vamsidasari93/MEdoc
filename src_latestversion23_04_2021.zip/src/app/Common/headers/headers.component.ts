import { ChangeDetectorRef, Component, OnDestroy, OnInit } from "@angular/core";
// import { ActivatedRoute, Router } from "@angular/router";
import { PdfserviceService } from "src/app/Services/pdfservice.service";
import { MatDialog } from "@angular/material/dialog";
import { AdddocumentsdialogComponent } from "./adddocumentsdialog/adddocumentsdialog.component";
import { Subscription } from "rxjs";
import { Router } from "@angular/router";
import { HelpPopupComponent } from "./help-popup/help-popup.component";
@Component({
  selector: "headers",
  templateUrl: "./headers.component.html",
  styleUrls: ["./headers.component.scss"],
})
export class HeadersComponent implements OnInit, OnDestroy {
  page: number;
  searchValue: string;
  itemChecked: boolean = false;
  reannotation: boolean = true;
  checkmodule: boolean = false;
  annontationchecked = false;
  linkactive: boolean;
  addDocument: boolean;
  activetabSubcribe: Subscription;
  uploadspinner = false;
  saveResponse: string;
  show: boolean = false;
  uploadfilename: any;
  itemCheck: any;
  admin: boolean;
  workspace: boolean = false;
  //Data science varaibles
  useCaseName: string = "";
  datascienceTabs: boolean = false;
  datascienceSearch: boolean = false;
  activeUseCase: Subscription;
  role: any;
  tabh: boolean = false;
  userName: any;
  history: boolean = false;
  isWorkspace: boolean = false;
  documenturl: string;
  usecaseID: string;
  predefindseg: boolean = false;
  isHistory: boolean = false;
  isDashboard = false;
  pdfview: boolean;
  roleid: any;
  isProfile: boolean;
  helpInfotype: string;
  useCaseType: string;
  isExtraction: boolean = false;
  constructor(
    private pdfService: PdfserviceService,
    private cdref: ChangeDetectorRef,
    public dialog: MatDialog,
    private router: Router
  ) {
    // var checkmodulename = localStorage.getItem("rolname");
    var userName = JSON.parse(localStorage.getItem("userinfo"));
    this.userName = userName.userName;
    this.pdfService.checkmodules$.subscribe((moduleval: any) => {
      console.log("checkmodulues", moduleval);
      if (moduleval === "Training Module" || moduleval === "Live Module") {
        this.checkmodule = true;
      } else {
        this.checkmodule = false;
      }
    });
    var predefineddata = localStorage.getItem("predefindseg");
    if (predefineddata === "true") {
      this.itemCheck = true;
    } else {
      this.itemCheck = false;
    }

    this.pdfService.errors$.subscribe((val: any) => {
      var apiResponse = val;
      if (apiResponse) {
        this.show = false;
        this.uploadspinner = false;
      }
    });
  }
  searchComponent(search) {
    this.searchValue = search;
  }
  ngOnInit() {
    this.useCaseName = localStorage.getItem("useCaseName");
    this.activeUseCase = this.pdfService.useCaseName$.subscribe((val: any) => {
      this.useCaseName = val ? val : "";
      this.cdref.detectChanges();
    });
    let usecaseType = localStorage.getItem("useCaseType");
    if (usecaseType == "extraction") {
      this.isExtraction = true;
    } else {
      this.isExtraction = false;
    }

    this.activetabSubcribe = this.pdfService.annatation$.subscribe((val) => {
      console.log("testinroles", val);
      if (val === "Documentlist") {
        this.reannotation = true;
        this.addDocument = true;
        this.linkactive = false;
        this.admin = false;
        this.isWorkspace = false;
        this.isDashboard = false;
        this.isProfile = false;
      } else if (val === "AnnotationDocument") {
        this.pdfview = true;
        this.linkactive = true;
        this.addDocument = true;
        this.reannotation = false;
        this.isWorkspace = false;
        this.isDashboard = false;
        this.isProfile = false;
      } else if (val === "History") {
        this.reannotation = false;
        this.linkactive = true;
        this.addDocument = true;
        this.history = true;
        this.isWorkspace = false;
        this.isDashboard = false;
        this.pdfview = false;
        this.isProfile = false;
      } else if (val === "Dashboard") {
        this.reannotation = false;
        this.linkactive = true;
        this.addDocument = true;
        this.history = true;
        this.isWorkspace = false;
        this.isDashboard = true;
        this.pdfview = false;
        this.isProfile = false;
        this.useCaseName = localStorage.getItem("useCaseName");
      } else if (val === "projects") {
        this.reannotation = true;
        this.addDocument = false;
        this.isWorkspace = true;
        this.isDashboard = false;
        this.isProfile = false;
      } else if (val === "admin") {
        this.admin = true;
        this.reannotation = false;
        this.addDocument = false;
        this.isWorkspace = false;
        this.isDashboard = false;
        this.isProfile = false;
      } else if (val == "useCases") {
        this.usecaseID = localStorage.getItem("useCaseId");
        this.isProfile = true;
        this.reannotation = false;
        this.addDocument = false;
        this.datascienceSearch = true;
        this.isWorkspace = false;
        this.isDashboard = false;
      }
      // else if (val == "pdfDocumentlist") {
      //   // var docId = localStorage.getItem("documentId");
      //   this.pdfview = true;
      //   // this.documenturl = "/Documentslist/AnnotationDocument;id=" + docId;
      // }
      else {
        this.history = false;
        this.isWorkspace = false;
        this.isDashboard = false;
      }

      this.role = JSON.parse(localStorage.getItem("usersrole"));
      console.log("roles", this.role);
      for (let i = 0; i < this.role.length; i++) {
        var croleid = JSON.parse(localStorage.getItem("roleID"));
        if (croleid == this.role[i].role_id) {
          this.roleid = this.role[i].role_id;
        }
      }
      // var roleid = this.role[0].role_id;
      var roleid = this.roleid;
      console.log("roleid", roleid);
      var docId = localStorage.getItem("documentId");
      if (this.role.length) {
        if (roleid == 3) {
          this.checkmodule = true;
          this.itemChecked = false;
          this.pdfService.send(this.itemChecked);
          this.usecaseID = btoa(localStorage.getItem("useCaseId"));
          if (val == "pdfDocumentlist") {
            this.documenturl = "/Documentslist/AnnotationDocument;id=" + docId;
          }
          this.documenturl = "/Documentslist/Documents/" + this.usecaseID;
          if (val === "Documentlist") {
            this.helpInfotype = "documents-training";
          } else if (val === "Dashboard") {
            this.helpInfotype = "dashboard-training";
          } else if (val === "History") {
            this.helpInfotype = "history-training";
          } else {
            this.helpInfotype = "documentsView-training";
          }

          //  this.documenturl = "/Documentslist/AnnotationDocument;id=" + docId;
          this.tabh = false;
          this.isHistory = true;
          this.workspace = false;
          this.useCaseType = localStorage.getItem("useCaseType");
          if (this.useCaseType == "classic") {
            this.predefindseg = true;
          } else {
            this.predefindseg = false;
          }
        } else if (roleid == 4) {
          this.usecaseID = btoa(localStorage.getItem("useCaseId"));
          this.checkmodule = true;
          this.itemChecked = false;
          this.pdfService.send(this.itemChecked);
          this.isHistory = false;
          this.tabh = false;
          this.predefindseg = false;
          this.documenturl =
            "/Documentslist/Documentslistlive/" + this.usecaseID;
          if (val === "Documentlist") {
            this.helpInfotype = "documents-live";
          } else if (val === "Dashboard") {
            this.helpInfotype = "dashboard-live";
          } else if (val === "History") {
            this.helpInfotype = "history-live";
          } else {
            this.helpInfotype = "documentsView-live";
          }

          // this.documenturl = "/Documentslist/AnnotationDocument;id=" + docId;
        } else if (roleid == 5) {
          this.predefindseg = false;
          this.tabh = true;
          this.isHistory = true;
          this.workspace = false;
        } else if (roleid == 6) {
          this.tabh = true;
          this.workspace = true;
        } else {
          this.checkmodule = false;
          this.workspace = false;
        }
      } else {
        this.tabh = false;
        this.checkmodule = false;
        this.workspace = false;
      }
      this.cdref.detectChanges();
    });
  }
  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.activetabSubcribe.unsubscribe();
  }
  addDocuments() {
    const dialogRef = this.dialog.open(AdddocumentsdialogComponent, {});
    dialogRef.afterClosed().subscribe((val) => {});
  }
  croppedStopFn($event) {
    // console.log("cropped stopped", this.itemCheck);
    this.useCaseType = localStorage.getItem("useCaseType");
    if (this.useCaseType == "classic") {
      localStorage.setItem("predefindseg", this.itemCheck);
    } else {
      this.itemCheck = false;
      localStorage.setItem("predefindseg", this.itemCheck);
    }
  }
  onKey(e) {
    let searchvalue = e.target.value;
    this.pdfService.searchvalue(searchvalue);
  }
  modelChangeFn(event) {
    var checkValue = this.itemChecked;
    this.pdfService.send(checkValue);
    this.pdfService.setgrid(checkValue);
  }
  isRoleExist = (roleId) => {
    // 3 - train, 4 - live ,
    let userInfo = JSON.parse(localStorage.getItem("userinfo"));
    let roleList = userInfo.roles;
    return roleList.find((x) => x.roleID === roleId) != undefined
      ? true
      : false;
  };
  /**
   * isExtractionVal()
   * @returns boolean
   */
  isExtractionVal = () => {
    let usecaseType = localStorage.getItem("useCaseType");
    // console.log(usecaseType);
    if (usecaseType == "extraction") {
      this.isExtraction = true;
      return true;
    } else {
      this.isExtraction = false;
      return false;
    }
  };
  /**
   * @event infopopup
   * @description Shows the details of the brandologo information
   */
  infoPopup() {
    console.log(this.helpInfotype);
    let roleId = localStorage.getItem("roleID");
    if (roleId === "4") {
      this.dialog
        .open(HelpPopupComponent, {
          backdropClass: "popupBackdropClass",
          width: "349px",
          height: "320px",
          data: {
            type: this.helpInfotype,
          },
          panelClass: "Admin-info-popup",
        })
        .afterClosed()
        .subscribe((result) => {});
    } else {
      this.dialog
        .open(HelpPopupComponent, {
          backdropClass: "popupBackdropClass",
          width: "349px",
          height: "320px",
          data: {
            type: this.helpInfotype,
          },
          panelClass: "Admin-info-popup",
        })
        .afterClosed()
        .subscribe((result) => {});
    }
  }
}
