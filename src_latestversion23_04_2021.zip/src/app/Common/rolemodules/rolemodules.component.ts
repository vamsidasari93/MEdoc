import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { PdfserviceService } from "src/app/Services/pdfservice.service";

@Component({
  selector: "app-rolemodules",
  templateUrl: "./rolemodules.component.html",
  styleUrls: ["./rolemodules.component.scss"],
})
export class RolemodulesComponent implements OnInit {
  tabshowT: boolean = false;
  tabshowL: boolean = false;
  tabh: boolean = true;
  role: any;
  public demo1TabIndex = 0;
  superUser: boolean = false;
  usecaseID: string;
  constructor(
    private router: Router,
    private PdfserviceService: PdfserviceService
  ) {}

  ngOnInit() {
    this.role = JSON.parse(localStorage.getItem("usersrole"));

    let roleid = localStorage.getItem("roleID");
    // var roleid = this.role[0].role_id;
    console.log(roleid);
    if (roleid == "3") {
      this.demo1TabIndex = 0;
    } else if (roleid == "4") {
      this.demo1TabIndex = 1;
    } else if (roleid == "5") {
      this.demo1TabIndex = 2;
    } else if (roleid == "6") {
      this.demo1TabIndex = 3;
    }
  }
  onclick(event) {
    console.log(event);
  }
  tabClick(event) {
    var moduletab = event.tab.textLabel;
    this.PdfserviceService.checkedmodules(moduletab);
    console.log("highclasstesting", moduletab);
    if (moduletab === "Live Module") {
      localStorage.setItem("roleID", "4");
      localStorage.setItem("rolname", "Live Module");
      this.usecaseID = localStorage.getItem("useCaseId");
      this.router.navigate(["/workspace"]);
      // this.router.navigate([
      //   "/Documentslist/Documentslistlive" + this.usecaseID,
      // ]);
    } else if (moduletab === "Training Module") {
      localStorage.setItem("roleID", "3");
      localStorage.setItem("rolname", "Training Module");
      this.router.navigate(["/workspace"]);
      // this.router.navigate(["/Documentslist/Documents" + this.usecaseID]);
    } else if (moduletab === "Admin Module") {
      localStorage.setItem("roleID", "6");
      // localStorage.setItem("rolname", "Admin Module");
      this.router.navigate(["/Admin"]);
    } else if (moduletab === "DataScience Module") {
      localStorage.setItem("roleID", "5");
      localStorage.setItem("rolname", "DataScience Module");
      this.router.navigate(["/workspace"]);
    }
  }
}
