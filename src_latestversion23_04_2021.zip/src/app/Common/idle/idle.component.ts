import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { DialogData } from 'src/app/datascience/dialog-data-set/dialog-data-set.component';

@Component({
  selector: 'app-idle',
  templateUrl: './idle.component.html',
  styleUrls: ['./idle.component.scss']
})
export class IdleComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<IdleComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  signIn(): void {
    this.dialogRef.close('signin');
  }

  signOut(): void {
    this.dialogRef.close('signout');
  }

  ngOnInit() {

  }

}
